/*
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY,  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED PRODUCTS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated Products
 * shall not be used except as stated in the Maxim Integrated Products
 * Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products retains all ownership rights.
 *
 ***************************************************************************/
/*
 * 
 * Created: 16 Feb 2016
 * By: Alex Ticer
 * Modified: 16 Feb 2016
 * By: Alex Ticer
 * Version: 0.1.0
 *
 ***************************************************************************/

#include "PioGpioExp.h"
#include <PioSpi.h>

PioGpioExp::PioGpioExp() {
}

PioGpioExp::~PioGpioExp() {
}

void PioGpioExp::init() {

	uint8_t messageBuffer[6] = { 0,0,0,0,0,0 };
	PioSpi* spi = new PioSpi();
	spi->init();

	messageBuffer[0] = 0x8E;
	messageBuffer[1] = 0x00;
	messageBuffer[2] = 0x0A;
	messageBuffer[3] = 0x01;
	messageBuffer[4] = 0x0A;
	messageBuffer[5] = 0x01;
	spi->transfer(messageBuffer, 0, 6, SPI_IOEXP);

	messageBuffer[0] = 0x8F;
	messageBuffer[1] = 0x00;
	messageBuffer[2] = 0x20;
	messageBuffer[3] = 0x00;
	messageBuffer[4] = 0x20;
	messageBuffer[5] = 0x00;
	spi->transfer(messageBuffer, 0, 6, SPI_IOEXP);

	delete spi;
}

uint8_t PioGpioExp::read(gpioExp_t port) {

	uint8_t messageBuffer[6] = { 0x20,0x00,0x20,0x00,0x20,0x00 };
	uint8_t responseBuffer[6] = { 0,0,0,0,0,0 };
	uint8_t value = 0;
	PioSpi* spi = new PioSpi();
	spi->init();

	if( port <8){
		messageBuffer[4] = port;
		messageBuffer[4] |= 0x80;
		spi->transfer(messageBuffer, 0, 6, SPI_IOEXP);
		spi->transfer(messageBuffer, responseBuffer, 6, SPI_IOEXP);
		value = responseBuffer[5];// 0 or 1
	}
	else if( port <16) {
		messageBuffer[2] = port-8;
		messageBuffer[2] |= 0x80;
		spi->transfer(messageBuffer, 0, 6, SPI_IOEXP);
		spi->transfer(messageBuffer, responseBuffer, 6, SPI_IOEXP);
		value = responseBuffer[3];// 0 or 1
	}
	else if( port <26) {
		messageBuffer[0] = port-16;
		messageBuffer[0] |= 0x80;
		spi->transfer(messageBuffer, 0, 6, SPI_IOEXP);
		spi->transfer(messageBuffer, responseBuffer, 6, SPI_IOEXP);
		value = responseBuffer[1];// 0 or 1
	}

	delete spi;

	return value;
}

void PioGpioExp::write(gpioExp_t port, uint8_t data) {

	uint8_t messageBuffer[6] = { 0x20,0x00,0x20,0x00,0x20,0x00 };
	PioSpi* spi = new PioSpi();
	spi->init();

	if(data > 1){ data = 1; }

	if( port <8){
		messageBuffer[4] = port;
		messageBuffer[4] |= 0x00;
		messageBuffer[5] = data;
		spi->transfer(messageBuffer, 0, 6, SPI_IOEXP);
	}
	else if( port <16) {
		messageBuffer[2] = port-8;
		messageBuffer[2] |= 0x00;
		messageBuffer[3] = data;
		spi->transfer(messageBuffer, 0, 6, SPI_IOEXP);
	}

	delete spi;
}

uint32_t PioGpioExp::readAll() {

	uint8_t messageBuffer[6] = { 0x8E,0x00,0x8E,0x00,0x8E,0x00 };
	uint8_t responseBuffer[6] = { 0,0,0,0,0,0 };
	uint32_t value = 0;
	PioSpi* spi = new PioSpi();
	spi->init();

	spi->transfer(messageBuffer, 0, 6, SPI_IOEXP);//send read for all 3 P7-P0

	messageBuffer[0] = 0x8F;
	messageBuffer[1] = 0x00;
	messageBuffer[2] = 0x20;
	messageBuffer[3] = 0x00;
	messageBuffer[4] = 0x20;
	messageBuffer[5] = 0x00;
	spi->transfer(messageBuffer, responseBuffer, 6, SPI_IOEXP);//send read P9-P8 for EXP3, get all 3 P7-P0

	//response
	value |= responseBuffer[5];//EXP1 P7-P0
	value |= (responseBuffer[3]<<8);//EXP2 P7-P0
	value |= (responseBuffer[1]<<16);//EXP3 P7-P0

	messageBuffer[0] = 0x20;
	spi->transfer(messageBuffer, responseBuffer, 6, SPI_IOEXP);//get P9-P8 for EXP3

	delete spi;

	value |= (responseBuffer[1]<<24);//EXP3 P9-P8

	return value;
}


