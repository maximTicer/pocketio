/*
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY,  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED PRODUCTS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated Products
 * shall not be used except as stated in the Maxim Integrated Products
 * Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products retains all ownership rights.
 *
 ***************************************************************************/
/*
 * 
 * Created: 17 Feb 2016
 * By: Alex Ticer
 * Modified: 17 Feb 2016
 * By: Alex Ticer
 * Version: 0.1.0
 *
 ***************************************************************************/

#include "MAX3109.h"
#include <PioSpi.h>

MAX3109::MAX3109() {
}

MAX3109::~MAX3109() {
}

bool MAX3109::isIrq(uint8_t port) {

	uint8_t response = 0x00;
	uint8_t messageBuffer[2] = { 0x00, 0x00};
	uint8_t responseBuffer[2] = { 0x00, 0x00};

	PioSpi* spi = new PioSpi();
	spi->init();

	messageBuffer[0] = MAX3109R_LSR & 0x7F;//arb reg with no COR

	if(port>0){
		messageBuffer[0] |= MAX3109_PORT1_MASK;

		spi->transfer(messageBuffer, responseBuffer, 2, SPI_COM);

		delete spi;

		response = (responseBuffer[0] & 0x02)>>1;

		return response;
	}
	else{
		messageBuffer[0] &= MAX3109_PORT0_MASK;

		spi->transfer(messageBuffer, responseBuffer, 2, SPI_COM);

		delete spi;

		response = (responseBuffer[0] & 0x01);

		return response;
	}
}

uint8_t MAX3109::read(uint8_t port, uint8_t reg) {

	uint8_t messageBuffer[2] = { 0x00, 0x00};
	uint8_t responseBuffer[2] = { 0x00, 0x00};

	PioSpi* spi = new PioSpi();
	spi->init();

	messageBuffer[0] = reg & 0x7F;

	if(port>0){ messageBuffer[0] |= MAX3109_PORT1_MASK; }
	else{ messageBuffer[0] &= MAX3109_PORT0_MASK; }

	spi->transfer(messageBuffer, responseBuffer, 2, SPI_COM);

	delete spi;

	return responseBuffer[1];
}

void MAX3109::write(uint8_t port, uint8_t reg, uint8_t data) {

	uint8_t messageBuffer[2] = { 0x00, 0x00};
	PioSpi* spi = new PioSpi();
	spi->init();

	messageBuffer[0] = reg | 0x80;
	if(port>0){ messageBuffer[0] |= MAX3109_PORT1_MASK; }
	else{ messageBuffer[0] &= MAX3109_PORT0_MASK; }

	messageBuffer[1] = data;

	spi->transfer(messageBuffer, 0, 2, SPI_COM);

	delete spi;
}

void MAX3109::gets(uint8_t port, uint8_t reg, uint8_t len, uint8_t* dataBuffer) {

	uint8_t messageBuffer[len+1];
	uint8_t responseBuffer[len+1];
	PioSpi* spi = new PioSpi();
	spi->init();

	messageBuffer[0] = reg & 0x7F;
	if(port>0){ messageBuffer[0] |= MAX3109_PORT1_MASK; }
	else{ messageBuffer[0] &= MAX3109_PORT0_MASK; }

	spi->transfer(messageBuffer, responseBuffer, len+1, SPI_COM);

	delete spi;

	for(int x=0; x<len; x++)
	{
		dataBuffer[x] = responseBuffer[x+1];
	}
}

void MAX3109::puts(uint8_t port, uint8_t reg, uint8_t len, uint8_t* dataBuffer) {

	uint8_t messageBuffer[len+1];
	PioSpi* spi = new PioSpi();
	spi->init();

	messageBuffer[0] = reg | 0x80;
	if(port>0){ messageBuffer[0] |= MAX3109_PORT1_MASK; }
	else{ messageBuffer[0] &= MAX3109_PORT0_MASK; }

	for(int x=0; x<len; x++)
	{
		messageBuffer[x+1] = dataBuffer[x];
	}

	spi->transfer(messageBuffer, 0, len+1, SPI_COM);

	delete spi;
}



