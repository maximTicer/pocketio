/*
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY,  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED PRODUCTS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated Products
 * shall not be used except as stated in the Maxim Integrated Products
 * Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products retains all ownership rights.
 *
 ***************************************************************************/
/*
 * 
 * Created: 16 Feb 2016
 * By: Alex Ticer
 * Modified: 16 Feb 2016
 * By: Alex Ticer
 * Version: 0.1.0
 *
 ***************************************************************************/

#ifndef PIOGPIOEXP_H_
#define PIOGPIOEXP_H_

#include <Arduino.h>

typedef enum {
	GPIO_M1_DIR,
	GPIO_M2_DIR,
	GPIO_M3_DIR,
	GPIO_M4_DIR,
	GPIO_M1_NEN,
	GPIO_M2_NEN,
	GPIO_M3_NEN,
	GPIO_M4_NEN,
	GPIO_AI_NRST,
	GPIO_DI_DB0,
	GPIO_DI_DB1,
	GPIO_AO_NCLR,
	GPIO_ENC1_NR120,
	GPIO_ENC2_R120,
	GPIO_ENC3_NR120,
	GPIO_ENC4_R120,
	GPIO_DO_NFLT,
	GPIO_M1_NFLT,
	GPIO_M2_NFLT,
	GPIO_M3_NFLT,
	GPIO_M4_NFLT,
	GPIO_ENC1_NIRQ,
	GPIO_ENC2_NIRQ,
	GPIO_ENC3_NIRQ,
	GPIO_ENC4_NIRQ,
	GPIO_UART_NIRQ
}gpioExp_t;

class PioGpioExp {
public:
	PioGpioExp();
	virtual ~PioGpioExp();

	void init();

	uint8_t read(gpioExp_t port );
	void write(gpioExp_t port, uint8_t data);

	uint32_t readAll();
};

#endif /* PIOGPIOEXP_H_ */