/*
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY,  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED PRODUCTS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated Products
 * shall not be used except as stated in the Maxim Integrated Products
 * Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products retains all ownership rights.
 *
 ***************************************************************************/
/*
 * 
 * Created: 16 Feb 2016
 * By: Alex Ticer
 * Modified: 1 Mar 2016
 * By: Alex Ticer
 * Version: 0.1.1
 *
 ***************************************************************************/

#include "PioMtr.h"
#include "PioGpioExp.h"

#define ED_M1_PWM_PIN				0
#define ED_M2_PWM_PIN				1
#define ED_M3_PWM_PIN				38
#define ED_M4_PWM_PIN				39

static uint8_t speedPwm1 =0;
static uint8_t speedPwm2 =0;
static uint8_t speedPwm3 =0;
static uint8_t speedPwm4 =0;

PioMtr::PioMtr() {
	
	speedPwm1 = 0;
	speedPwm2 = 0;
	speedPwm3 = 0;
	speedPwm4 = 0;
	
}

PioMtr::~PioMtr() {
}

void PioMtr::init(){
	pinMode(ED_M1_PWM_PIN, OUTPUT);
	pinMode(ED_M2_PWM_PIN, OUTPUT);
	pinMode(ED_M3_PWM_PIN, OUTPUT);
	pinMode(ED_M4_PWM_PIN, OUTPUT);
	
	writeEnable(M1, 0);
	writeEnable(M2, 0);
	writeEnable(M3, 0);
	writeEnable(M4, 0);
	
}

uint8_t PioMtr::readEnable(uint8_t motor) {

	uint8_t response = 0;
	uint8_t port = 3+motor;

	PioGpioExp* exp = new PioGpioExp();

	if( motor<1 || motor>4) {
		return 0;
	}

	response = exp->read((gpioExp_t)port);

	delete exp;

	return response?0:1;
}

uint8_t PioMtr::writeEnable(uint8_t motor, uint8_t enable) {

	uint8_t response = 0;
	uint8_t port = 3+motor;

	PioGpioExp* exp = new PioGpioExp();

	if( motor<1 || motor>4) {
		return 0;
	}

	if(enable){
		exp->write((gpioExp_t)port, 0);//enable
	}
	else{

		exp->write((gpioExp_t)port, 1);//disable
	}

	response = exp->read((gpioExp_t)port);

	delete exp;

	return response?0:1;
}

//0=counterclockwise
//1=clockwise
uint8_t PioMtr::readDirection(uint8_t motor) {

	uint8_t response = 0;
	uint8_t port = motor-1;

	if( motor<1 || motor>4) {
		fprintf(stderr, "ERROR: Invalid motor value to readDirection Method");
		return 0;
	}

	PioGpioExp* exp = new PioGpioExp();

	response = exp->read((gpioExp_t)port);

	delete exp;

	return response;
}

//0=counterclockwise
//1=clockwise
uint8_t PioMtr::writeDirection(uint8_t motor, uint8_t dir) {

	uint8_t response = 0;
	uint8_t port = motor-1;

	if( motor<1 || motor>4) {
		return 0;
	}

	PioGpioExp* exp = new PioGpioExp();

	if(dir){
		exp->write((gpioExp_t)port, 1);//clockwise
	}
	else{
		exp->write((gpioExp_t)port, 0);//counterclockwise
	}

	response = exp->read((gpioExp_t)port);

	delete exp;

	return response;
}

//0-255
uint8_t PioMtr::readSpeed(uint8_t motor) {

	uint8_t response = 0;

	if(motor == 1){
		response = speedPwm1;
	}
	else if(motor == 2) {
		response = speedPwm2;
	}
	else if(motor == 3) {
		response = speedPwm3;
	}
	else if(motor == 4) {
		response = speedPwm4;
	}
	else {
		return 0;
	}

	return response;
}

//0-255
uint8_t PioMtr::writeSpeed(uint8_t motor, uint8_t speed) {

	uint8_t response = 0;

	if(motor == 1){
		speedPwm1 = speed;
		if(speed==0){
			analogWrite(ED_M1_PWM_PIN, 1);
		}
		else{
			analogWrite(ED_M1_PWM_PIN, speedPwm1);
		}
		
		response = speedPwm1;
	}
	else if(motor == 2) {
		speedPwm2 = speed;
		if(speed==0){
			analogWrite(ED_M2_PWM_PIN, 1);
		}
		else{
			analogWrite(ED_M2_PWM_PIN, speedPwm2);
		}
		
		response = speedPwm2;
	}
	else if(motor == 3) {
		speedPwm3 = speed;
		if(speed==0){
			analogWrite(ED_M3_PWM_PIN, 1);
		}
		else{
			analogWrite(ED_M3_PWM_PIN, speedPwm3);
		}
		
		response = speedPwm3;
	}
	else if(motor == 4) {
		speedPwm4 = speed;
		if(speed==0){
			analogWrite(ED_M4_PWM_PIN, 1);
		}
		else{
			analogWrite(ED_M4_PWM_PIN, speedPwm4);
		}
		
		response = speedPwm4;
	}
	else {
		return 0;
	}

	return response;
}


