/*
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY,  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED PRODUCTS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated Products
 * shall not be used except as stated in the Maxim Integrated Products
 * Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products retains all ownership rights.
 *
 ***************************************************************************/
/*
 * 
 * Created: 18 Feb 2016
 * By: Alex Ticer
 * Modified: 1 May 2016
 * By: Alex Ticer
 * Version: 0.2.0
 *
 ***************************************************************************/
#include "PioEnc.h"
#include "PioGpioExp.h"
#include <stdio.h>

#define ED_ENC1_A_PIN				12
#define ED_ENC1_B_PIN				15
#define ED_ENC1_Z_PIN				19

#define ED_ENC2_A_PIN				37
#define ED_ENC2_B_PIN				16
#define ED_ENC2_Z_PIN				14

#define ED_ENC3_A_PIN				13
#define ED_ENC3_B_PIN				17
#define ED_ENC3_Z_PIN				6

static int position1;
static int position2;
static int position3;

PioEnc::PioEnc() {
	
	position1 = 0;
	position2 = 0;
	position3 = 0;
}

PioEnc::~PioEnc() {

	delete max14890E;
	max14890E = NULL;

	detachInterrupt(ED_ENC1_A_PIN);
	detachInterrupt(ED_ENC2_A_PIN);
	detachInterrupt(ED_ENC3_A_PIN);

}

void PioEnc::init(){
	
	max14890E = new MAX14890E();

	pinMode(ED_ENC1_A_PIN, INPUT);
	pinMode(ED_ENC1_B_PIN, INPUT);
	pinMode(ED_ENC1_Z_PIN, INPUT);
	
	pinMode(ED_ENC2_A_PIN, INPUT);
	pinMode(ED_ENC2_B_PIN, INPUT);
	pinMode(ED_ENC2_Z_PIN, INPUT);
	
	pinMode(ED_ENC3_A_PIN, INPUT);
	pinMode(ED_ENC3_B_PIN, INPUT);
	pinMode(ED_ENC3_Z_PIN, INPUT);
	

	//default to SEHTL
	max14890E->setMode(1, SEHTL);
	max14890E->setMode(2, SEHTL);
	max14890E->setMode(3, SEHTL);
	
	attachInterrupt(ED_ENC1_A_PIN, signal1AISR, RISING);
	attachInterrupt(ED_ENC2_A_PIN, signal2AISR, RISING);
	attachInterrupt(ED_ENC3_A_PIN, signal3AISR, RISING);
}

void PioEnc::setTermination(uint8_t port, uint8_t mode){

	if(port<1 || port>3 || mode>3){
		return;
	}

	PioGpioExp* exp = new PioGpioExp();

	if( mode == RS422){

		if( port==1){
			exp->write((gpioExp_t)GPIO_ENC1_NR120, 0);
		}
		else if(port==3){
			exp->write((gpioExp_t)GPIO_ENC3_NR120, 0);
		}
		else if(port==2){
			exp->write((gpioExp_t)GPIO_ENC2_R120, 1);
		}
	}
	else{
		if( port==1){
			exp->write((gpioExp_t)GPIO_ENC1_NR120, 1);
		}
		else if(port==3){
			exp->write((gpioExp_t)GPIO_ENC3_NR120, 1);
		}
		else if(port==2){
			exp->write((gpioExp_t)GPIO_ENC2_R120, 0);
		}
	}

	delete exp;
}

uint8_t PioEnc::getMode(uint8_t port){

	if(port<1 || port>3){
		return 99;
	}
	else{
		return max14890E->getMode(port);
	}

}

void PioEnc::setMode(uint8_t port, uint8_t mode){

	if(port<1 || port>3 || mode>3){
		return;
	}
	else{
		setTermination(port, mode);

		max14890E->setMode(port, mode);
	}
}

void PioEnc::initPosition(uint8_t port, int count){

	if(port == 1){
		position1 = count;
	}
	else if(port == 2){
		position2 = count;
	}
	else if(port == 3){
		position3 = count;
	}
}

int PioEnc::position(uint8_t port){

	if(port == 1){
		return position1;
	}
	else if(port == 2){
		return position2;
	}
	else if(port == 3){
		return position3;
	}

	return 0;
}

void PioEnc::signal1AISR(){

	if(digitalRead(ED_ENC1_A_PIN)){

		if(digitalRead(ED_ENC1_Z_PIN)){

			if(digitalRead(ED_ENC1_B_PIN)){
				position1++;//CW
			}
			else{
				position1--;//CCW
			}
		}
	}
}

void PioEnc::signal2AISR(){

	if(digitalRead(ED_ENC2_A_PIN)){

		if(digitalRead(ED_ENC2_Z_PIN)){

			if(digitalRead(ED_ENC2_B_PIN)){
				position2++;//CW
			}
			else{
				position2--;//CCW
			}
		}
	}
}

void PioEnc::signal3AISR(){

	if(digitalRead(ED_ENC3_A_PIN)){

		if(digitalRead(ED_ENC3_Z_PIN)){

			if(digitalRead(ED_ENC3_B_PIN)){
				position3++;//CW
			}
			else{
				position3--;//CCW
			}
		}
	}
}


