/*
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY,  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED PRODUCTS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated Products
 * shall not be used except as stated in the Maxim Integrated Products
 * Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products retains all ownership rights.
 *
 ***************************************************************************/
/*
 * 
 * Created: 15 Feb 2016
 * By: Alex Ticer
 * Modified: 1 May 2016
 * By: Alex Ticer
 * Version: 0.3.0
 *
 ***************************************************************************/

#include "PioAo.h"
#include <PioSpi.h>

PioAo::PioAo() {
}

PioAo::~PioAo() {
}

uint16_t PioAo::writeCode(uint16_t code) {

	PioSpi* spi = new PioSpi();

	uint8_t messageBuffer[3] = { 0x40, 0x00, 0x00};//24bit word

	spi->configure(ED_SPI_MODE1, ED_SPI_CLOCK_1M);

	messageBuffer[0] |= ((code & 0xFC00) >> 10);//D21-D16
	messageBuffer[1] = ((code & 0x03FC) >> 2);//D15-D8
	messageBuffer[2] = ((code & 0x0003) << 6);//D7, D6

	spi->transfer(messageBuffer, 0, 3, SPI_AO);

	delete spi;
	
	return code;
}


