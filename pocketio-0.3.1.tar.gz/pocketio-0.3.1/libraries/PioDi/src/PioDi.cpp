/*
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY,  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED PRODUCTS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated Products
 * shall not be used except as stated in the Maxim Integrated Products
 * Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products retains all ownership rights.
 *
 ***************************************************************************/
/*
 * 
 * Created: 15 Feb 2016
 * By: Alex Ticer
 * Modified: 30 Apr 2016
 * By: Alex Ticer
 * Version: 0.3.0
 *
 ***************************************************************************/

#include "PioDi.h"
#include <PioSpi.h>

const int DB0 = 33;
const int DB1 = 34;

PioDi::PioDi() {
}

PioDi::~PioDi() {
}

void PioDi::init(){
	pinMode(DB0, OUTPUT);
	pinMode(DB1, OUTPUT);
}

uint16_t PioDi::read() {

	PioSpi* spi = new PioSpi();

	uint16_t response = 0x0000;

	uint8_t messageBuffer[2] = { 0x00, 0x00};
	uint8_t responseBuffer[2] = { 0x00, 0x00};

	spi->init();

	spi->transfer(messageBuffer, responseBuffer, 2, SPI_DI);

	delete spi;

	response = (responseBuffer[0]<<8) | responseBuffer[1];

	return response;
}

uint8_t PioDi::readInput() {

	PioSpi* spi = new PioSpi();

	uint8_t messageBuffer[2] = { 0x00, 0x00};
	uint8_t responseBuffer[2] = { 0x00, 0x00};

	spi->init();

	spi->transfer(messageBuffer, responseBuffer, 2, SPI_DI);

	delete spi;

	return responseBuffer[0];
}

uint8_t PioDi::readInput(uint8_t channel)
{
	PioSpi* spi = new PioSpi();

	uint8_t messageBuffer[2] = { 0x00, 0x00};
	uint8_t responseBuffer[2] = { 0x00, 0x00};
	uint8_t diValue = 0x00;

	spi->init();

	spi->transfer(messageBuffer, responseBuffer, 2, SPI_DI);

	delete spi;

	diValue = (responseBuffer[0]>>(channel-1) & 0x01);

	return diValue;
}

uint8_t PioDi::readTemperature() {

	PioSpi* spi = new PioSpi();

	uint8_t messageBuffer[2] = { 0x00, 0x00};
	uint8_t responseBuffer[2] = { 0x00, 0x00};
	uint8_t overTemp = 0x00;

	spi->init();

	spi->transfer(messageBuffer, responseBuffer, 2, SPI_DI);

	delete spi;

	overTemp = (responseBuffer[1]>>1) & 0x01;

	return overTemp;//either 0/1
}

uint8_t PioDi::readDebounce() {

	uint8_t db0 = digitalRead(DB0);
	uint8_t db1 = digitalRead(DB1);
	
	return (db1<<1) | db0;
}

uint8_t PioDi::writeDebounce(uint8_t debounce) {
	
	if(debounce>3){ debounce = 3;}
	
	uint8_t db0 = debounce & 0x01;
	uint8_t db1 = (debounce & 0x02)>>1;
	
	digitalWrite(DB0, 1);
	digitalWrite(DB1, 0);
	
	return debounce;
}
