/*
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY,  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED PRODUCTS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated Products
 * shall not be used except as stated in the Maxim Integrated Products
 * Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products retains all ownership rights.
 *
 ***************************************************************************/
/*
 * 
 * Created: 16 Feb 2016
 * By: Alex Ticer
 * Modified: 12 Sep 2016
 * By: Alex Ticer
 * Version: 0.3.2
 *
 ***************************************************************************/

#ifndef PIOMTR_H_
#define PIOMTR_H_

#include <stdint.h>

#define M1				1
#define M2				2
#define M3				3

#define COUNTERCLOCKWISE	0
#define CLOCKWISE			1

class PioMtr {
public:
	PioMtr();
	virtual ~PioMtr();
	
	void init();
	
	uint8_t readEnable(uint8_t motor);
	uint8_t writeEnable(uint8_t motor, uint8_t enable);

	uint8_t readDirection(uint8_t motor);
	uint8_t writeDirection(uint8_t motor, uint8_t dir);//0=cntclk, 1=clk

	uint8_t readSpeed(uint8_t motor);
	uint8_t writeSpeed(uint8_t motor, uint8_t speed);//0-255 with 0min, 255max
	
	uint32_t readPWMFreq(uint8_t motor);
	uint32_t writePWMFreq(uint8_t motor, uint32_t freq);//0(default=485.2Hz)
	
};

#endif /* PIOMTR_H_ */