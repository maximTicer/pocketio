/*******************************************************************************
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated
 * Products, Inc. shall not be used except as stated in the Maxim Integrated
 * Products, Inc. Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products, Inc. retains all
 * ownership rights.
 *******************************************************************************
 */
/*
 * 
 * Created: 15 Feb 2016
 * By: Alex Ticer
 * Modified: 12 Sep 2016
 * By: Alex Ticer
 * Version: 0.3.4
 *
 ***************************************************************************/

#ifndef PIODI_H_
#define PIODI_H_

#include <Arduino.h>

const uint8_t DI1 = 1;
const uint8_t DI2 = 2;
const uint8_t DI3 = 3;
const uint8_t DI4 = 4;
const uint8_t DI5 = 5;
const uint8_t DI6 = 6;
const uint8_t DI7 = 7;
const uint8_t DI8 = 8;

class PioDi {
public:
	PioDi();
	virtual ~PioDi();
	
	void init();

	uint16_t read();
	uint8_t readInput();
	uint8_t readInput(uint8_t channel);
	uint8_t readTemperature();
	uint8_t readDebounce();
	uint8_t writeDebounce(uint8_t debounce);//0=0, 1=25us, 2=0.75ms, 3=3ms, default to 3ms pullup
};

#endif /* PIODI_H_ */
