/*******************************************************************************
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated
 * Products, Inc. shall not be used except as stated in the Maxim Integrated
 * Products, Inc. Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products, Inc. retains all
 * ownership rights.
 *******************************************************************************
 */
/*
 * 
 * Created: 15 Feb 2016
 * By: Alex Ticer
 * Modified: 12 Sep 2016
 * By: Alex Ticer
 * Version: 0.3.4
 *
 ***************************************************************************/

#ifndef PIOSPI_H_
#define PIOSPI_H_

#include "Arduino.h"

#define ED_SPI_MODE0 0x00
#define ED_SPI_MODE1 0x01
#define ED_SPI_MODE2 0x02
#define ED_SPI_MODE3 0x03

#define ED_SPI_CLOCK_10K 10000
#define ED_SPI_CLOCK_100K 100000
#define ED_SPI_CLOCK_125K 125000
#define ED_SPI_CLOCK_250K 250000
#define ED_SPI_CLOCK_500K 500000
#define ED_SPI_CLOCK_1M 1000000
#define ED_SPI_CLOCK_2M 2000000
#define ED_SPI_CLOCK_3M 3000000
#define ED_SPI_CLOCK_4M 4000000

typedef enum {
	SPI_NONE,	//0
	SPI_DO,		//1
	SPI_DI,		//2
	SPI_AO,		//3
	SPI_AI,		//4
	SPI_COM,	//5
	SPI_IOL,	//6
	SPI_ENC,	//7
	SPI_IOEXP	//8
} spiComm_t;

class PioSpi {
public:
	PioSpi();
	virtual ~PioSpi();

	int init();
	int configure(uint8_t, uint32_t);
	int transfer(uint8_t*, uint8_t*, int, uint8_t);

private:
	int setNssActive(uint8_t);
	int setNssInactive();

	int configureGpio();
	
	static bool isInit;
};

#endif /* PIOSPI_H_ */
