/*******************************************************************************
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated
 * Products, Inc. shall not be used except as stated in the Maxim Integrated
 * Products, Inc. Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products, Inc. retains all
 * ownership rights.
 *******************************************************************************
 */
/*
 * 
 * Created: 18 Feb 2016
 * By: Alex Ticer
 * Modified: 12 Sep 2016
 * By: Alex Ticer
 * Version: 0.3.6
 *
 ***************************************************************************/

#include "PioUserLed.h"
#include <PioSpi.h>
#include <stdio.h>

PioUserLed::PioUserLed() {
}

PioUserLed::~PioUserLed() {

	delete max3109;
	max3109 = NULL;
}

void PioUserLed::init(){

	uint8_t data = 0x00;
    
    PioSpi* spi = new PioSpi();
    spi->init();
    delete spi;
	
	max3109 = new MAX3109();
    max3109->init();
	
	//Init Leds
	data = 0x0F;
	max3109->write(0, MAX3109R_GPIOCONFG, data);
	data = 0x00;
	max3109->write(0, MAX3109R_GPIODATA, data);
	data = 0x0F;
	max3109->write(1, MAX3109R_GPIOCONFG, data);
	data = 0x00;
	max3109->write(1, MAX3109R_GPIODATA, data);
}

uint8_t PioUserLed::readLed(uint8_t led){

	uint8_t response = 0;
	uint8_t port = 0;

	if(led<1 || led>8){
		return 0;
	}

	if(led>4){
		port = 1;
	}

	response = max3109->read(port, MAX3109R_GPIODATA);

	if(port){
		response = (response>>(led-5)) & 0x01;
	}
	else{
		response = (response>>(led-1)) & 0x01;
	}

	return response;
}

void PioUserLed::writeLed(uint8_t led, uint8_t value){

	uint8_t message = 0x00;
	uint8_t response = 0x00;
	uint8_t port = 0;

	if(led<1 || led>8){
		return;
	}

	if(led>4){
		port = 1;
	}

	response = max3109->read(port, MAX3109R_GPIODATA);

	if(port){
		if(value){
			message = response | (0x01<<(led-5));//1
		}
		else{
			message = response & ~(0x01<<(led-5));//0
		}
	}
	else{
		if(value){
			message = response | (0x01<<(led-1));//1
		}
		else{
			message = response & ~(0x01<<(led-1));//0
		}
	}

	max3109->write(port, MAX3109R_GPIODATA, message);
}


