/*
  Copyright (c) 2011 Arduino.  All right reserved.
  Copyright (c) 2014 Intel Corporation.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <Arduino.h>
#include <interrupt.h>
#include <Mux.h>
#include <sysfs.h>
#include <trace.h>
#include "variant.h"

//Bindings to Arduino
#include "RingBuffer.h"
#include "TTYUART.h"
#include "fast_gpio_pci.h"

#define MY_TRACE_PREFIX "variant"

#ifdef __cplusplus
extern "C" {
#endif

#define GP12_PWM0			12
#define GP13_PWM1			13
#define GP182_PWM2			182
#define GP183_PWM3			183
#define any_equal(a,b,c,d)		(a==b||a==c||a==d||b==c||b==d||c==d)
#define all_pwms(a,b,c,d)		(digitalPinHasPWM(a)&&digitalPinHasPWM(b)&&\
					digitalPinHasPWM(c)&&digitalPinHasPWM(d))

struct pwm_muxing {
	uint8_t gpioid;
	mux_sel_t *muxing;
};

const int mux_sel_analog[NUM_ANALOG_INPUTS] = {
};

const int mux_sel_uart[NUM_UARTS][MUX_DEPTH_UART] = {
	/* This is auto-indexed (board pinout) */
	{MUX_SEL_NONE, MUX_SEL_NONE},				// ttyGS0 - USB not muxed
	{MUX_SEL_UART0_RXD,	MUX_SEL_UART0_TXD},		// ttyS0 - muxed
};

const int  mux_sel_spi[NUM_SPI][MUX_DEPTH_SPI] = {
	{
		MUX_SEL_NONE,
		MUX_SEL_NONE,
		MUX_SEL_NONE
	},
	{
		MUX_SEL_SPI1_MOSI,
		MUX_SEL_SPI1_MISO,
		MUX_SEL_SPI1_SCK
	},
};

const int  mux_sel_i2c[NUM_I2C][MUX_DEPTH_I2C] = {
	{
		MUX_SEL_I2C_SCL,
		MUX_SEL_I2C_SDA,
	},
};

mux_sel_t MuxDesc0[] = {
	//gpio, value, type
	{  12, PIN_MODE_0, FN_GPIO | FN_PWM } // GPIO mode
};

mux_sel_t MuxDesc1[] = {
	//gpio, value, type
	{  13, PIN_MODE_0, FN_GPIO | FN_PWM } // GPIO mode
};

mux_sel_t MuxDesc2[] = {
	//gpio, value, type
	{  14, PIN_MODE_0, FN_GPIO } // GPIO mode
};

mux_sel_t MuxDesc3[] = {
	//gpio, value, type
	{  15, PIN_MODE_0, FN_GPIO } // GPIO mode
};

mux_sel_t MuxDesc4[] = {
	//gpio, value, type
	{  19, PIN_MODE_0, FN_GPIO } // GPIO mode
};

mux_sel_t MuxDesc5[] = {
	//gpio, value, type
	{  20, PIN_MODE_0, FN_GPIO } // GPIO mode
};

mux_sel_t MuxDesc6[] = {
	//gpio, value, type
	{  27, PIN_MODE_0, FN_GPIO_INPUT } // GPIO mode
};

mux_sel_t MuxDesc7[] = {
	//gpio, value, type
	{  28, PIN_MODE_0, FN_GPIO } // GPIO mode
};

mux_sel_t MuxDesc8[] = {
	//gpio, value, type
	{  40, PIN_MODE_0, FN_GPIO } // GPIO mode
};

mux_sel_t MuxDesc9[] = {
	//gpio, value, type
	{  41, PIN_MODE_0, FN_GPIO } // GPIO mode
};

mux_sel_t MuxDesc10[] = {
	//gpio, value, type
	{  42, PIN_MODE_0, FN_GPIO } // GPIO mode
};

mux_sel_t MuxDesc11[] = {
	//gpio, value, type
	{  43, PIN_MODE_0, FN_GPIO } // GPIO mode
};

mux_sel_t MuxDesc12[] = {
	//gpio, value, type
	{  44, PIN_MODE_0, FN_GPIO_INPUT } // GPIO mode
};

mux_sel_t MuxDesc13[] = {
	//gpio, value, type
	{  45, PIN_MODE_0, FN_GPIO_INPUT } // GPIO mode
};

mux_sel_t MuxDesc14[] = {
	//gpio, value, type
	{  46, PIN_MODE_0, FN_GPIO } // GPIO mode
};

mux_sel_t MuxDesc15[] = {
	//gpio, value, type
	{  47, PIN_MODE_0, FN_GPIO_INPUT } // GPIO mode
};

mux_sel_t MuxDesc16[] = {
	//gpio, value, type
	{  48, PIN_MODE_0, FN_GPIO_INPUT } // GPIO mode
};

mux_sel_t MuxDesc17[] = {
	//gpio, value, type
	{  49, PIN_MODE_0, FN_GPIO_INPUT } // GPIO mode
};

mux_sel_t MuxDesc18[] = {
	//gpio, value, type
	{  77, PIN_MODE_0, FN_GPIO_INPUT } // GPIO mode
};

mux_sel_t MuxDesc19[] = {
	//gpio, value, type
	{  78, PIN_MODE_0, FN_GPIO_INPUT } // GPIO mode
};

mux_sel_t MuxDesc20[] = {
	//gpio, value, type
	{  79, PIN_MODE_0, FN_GPIO } // GPIO mode
};

mux_sel_t MuxDesc21[] = {
	//gpio, value, type
	{  80, PIN_MODE_0, FN_GPIO } // GPIO mode
};

mux_sel_t MuxDesc22[] = {
	//gpio, value, type
	{  81, PIN_MODE_0, FN_GPIO } // GPIO mode
};

mux_sel_t MuxDesc23[] = {
	//gpio, value, type
	{  82, PIN_MODE_0, FN_GPIO } // GPIO mode
};

mux_sel_t MuxDesc24[] = {
	//gpio, value, type
	{  83, PIN_MODE_0, FN_GPIO } // GPIO mode
};

mux_sel_t MuxDesc25[] = {
	//gpio, value, type
	{  84, PIN_MODE_0, FN_GPIO } // GPIO mode
};

mux_sel_t MuxDesc26[] = {
	//gpio, value, type
	{  109, PIN_MODE_1, FN_SPI } // SPI mode
};

mux_sel_t MuxDesc27[] = {
	//gpio, value, type
	{  110, PIN_MODE_0, FN_GPIO } // GPIO mode
};

mux_sel_t MuxDesc28[] = {
	//gpio, value, type
	{  111, PIN_MODE_0, FN_GPIO } // GPIO mode
};

mux_sel_t MuxDesc29[] = {
	//gpio, value, type
	{  114, PIN_MODE_1, FN_SPI } // GPIO mode
};

mux_sel_t MuxDesc30[] = {
	//gpio, value, type
	{  115, PIN_MODE_1, FN_SPI } // GPIO mode
};

mux_sel_t MuxDesc31[] = {
	//gpio, value, type
	{  128, PIN_MODE_0, FN_GPIO } // GPIO mode
};

mux_sel_t MuxDesc32[] = {
	//gpio, value, type
	{  129, PIN_MODE_0, FN_GPIO } // GPIO mode
};

mux_sel_t MuxDesc33[] = {
	//gpio, value, type
	{  130, PIN_MODE_0, FN_GPIO } // GPIO mode
};

mux_sel_t MuxDesc34[] = {
	//gpio, value, type
	{  131, PIN_MODE_0, FN_GPIO } // GPIO mode
};

mux_sel_t MuxDesc35[] = {
	//gpio, value, type
	{  134, PIN_MODE_0, FN_GPIO } // GPIO mode
};

mux_sel_t MuxDesc36[] = {
	//gpio, value, type
	{  135, PIN_MODE_0, FN_GPIO } // GPIO mode
};

mux_sel_t MuxDesc37[] = {
	//gpio, value, type
	{  165, PIN_MODE_0, FN_GPIO_INPUT } // GPIO mode
};

mux_sel_t MuxDesc38[] = {
	//gpio, value, type
	{  182, PIN_MODE_0, FN_GPIO | FN_PWM } // GPIO mode
};

mux_sel_t MuxDesc39[] = {
	//gpio, value, type
	{  183, PIN_MODE_0, FN_GPIO | FN_PWM } // GPIO mode
};

// Sorted by Linux GPIO ID
PinDescription g_APinDescription[] =
{
//	gpiolib	alias	fastinf	ardid	Initial			FixdSt	ptMuxDesc,		MuxCount		type		Handle	extPU	iAlt	pAlt
	{ 12,	NONE,	NONE,	0,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc0,	MUX_SIZE(MuxDesc0),		FN_GPIO,	-1,	1,	0,	NULL },
	{ 13,	NONE,	NONE,	1,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc1,	MUX_SIZE(MuxDesc1),		FN_GPIO,	-1,	1,	0,	NULL },
	{ 14,	NONE,	NONE,	2,	FN_GPIO_INPUT_HIZ,	NONE,	NULL,	0,		FN_GPIO,	-1,	1,	0,	NULL },
	{ 15,	NONE,	NONE,	3,	FN_GPIO_INPUT_HIZ,	NONE,	NULL,	0,		FN_GPIO,	-1,	1,	0,	NULL },
	{ 19,	NONE,	NONE,	4,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc4,	MUX_SIZE(MuxDesc4),		FN_GPIO,	-1,	1,	0,	NULL },
	{ 20,	NONE,	NONE,	5,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc5,	MUX_SIZE(MuxDesc5),		FN_GPIO,	-1,	1,	0,	NULL },
	{ 27,	NONE,	NONE,	6,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc6,	MUX_SIZE(MuxDesc6),		FN_GPIO,	-1,	1,	0,	NULL },
	{ 28,	NONE,	NONE,	7,	FN_GPIO_INPUT_HIZ,	NONE,	NULL,	0,		FN_GPIO,	-1,	1,	0,	NULL },
	{ 40,	NONE,	NONE,	8,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc8,	MUX_SIZE(MuxDesc8),		FN_GPIO,	-1,	1,	0,	NULL },
	{ 41,	NONE,	NONE,	9,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc9,	MUX_SIZE(MuxDesc9),		FN_GPIO,	-1,	1,	0,	NULL },
	{ 42,	NONE,	NONE,	10,	FN_GPIO_INPUT_HIZ,	NONE,	NULL,	0,	FN_GPIO,	-1,	1,	0,	NULL },
	{ 43,	NONE,	NONE,	11,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc11,	MUX_SIZE(MuxDesc11),	FN_GPIO,	-1,	1,	0,	NULL },
	{ 44,	NONE,	NONE,	12,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc12,	MUX_SIZE(MuxDesc12),	FN_GPIO,	-1,	1,	0,	NULL },
	{ 45,	NONE,	NONE,	13,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc13,	MUX_SIZE(MuxDesc13),	FN_GPIO,	-1,	1,	0,	NULL },
	{ 46,	NONE,	NONE,	14,	FN_GPIO_INPUT_HIZ,	NONE,	NULL,	0,	FN_GPIO,	-1,	1,	0,	NULL },
	{ 47,	NONE,	NONE,	15,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc15,	MUX_SIZE(MuxDesc15),	FN_GPIO,	-1,	1,	0,	NULL },
	{ 48,	NONE,	NONE,	16,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc16,	MUX_SIZE(MuxDesc16),	FN_GPIO,	-1,	1,	0,	NULL },
	{ 49,	NONE,	NONE,	17,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc17,	MUX_SIZE(MuxDesc17),	FN_GPIO,	-1,	1,	0,	NULL },
	{ 77,	NONE,	NONE,	18,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc18,	MUX_SIZE(MuxDesc18),	FN_GPIO,	-1,	1,	0,	NULL },
	{ 78,	NONE,	NONE,	19,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc19,	MUX_SIZE(MuxDesc19),	FN_GPIO,	-1,	1,	0,	NULL },
	{ 79,	NONE,	NONE,	20,	FN_GPIO_INPUT_HIZ,	NONE,	NULL,	0,	FN_GPIO,	-1,	1,	0,	NULL },
	{ 80,	NONE,	NONE,	21,	FN_GPIO_INPUT_HIZ,	NONE,	NULL,	0,	FN_GPIO,	-1,	1,	0,	NULL },
	{ 81,	NONE,	NONE,	22,	FN_GPIO_INPUT_HIZ,	NONE,	NULL,	0,	FN_GPIO,	-1,	1,	0,	NULL },
	{ 82,	NONE,	NONE,	23,	FN_GPIO_INPUT_HIZ,	NONE,	NULL,	0,	FN_GPIO,	-1,	1,	0,	NULL },
	{ 83,	NONE,	NONE,	24,	FN_GPIO_INPUT_HIZ,	NONE,	NULL,	0,	FN_GPIO,	-1,	1,	0,	NULL },
	{ 84,	NONE,	NONE,	25,	FN_GPIO_INPUT_HIZ,	NONE,	NULL,	0,	FN_GPIO,	-1,	1,	0,	NULL },
	{ 109,	NONE,	NONE,	26,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc26,	MUX_SIZE(MuxDesc26),	FN_GPIO,	-1,	1,	0,	NULL },
	{ 110,	NONE,	NONE,	27,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc27,	MUX_SIZE(MuxDesc27),	FN_GPIO,	-1,	1,	0,	NULL },
	{ 111,	NONE,	NONE,	28,	FN_GPIO_INPUT_HIZ,	NONE,	NULL,	0,	FN_GPIO,	-1,	1,	0,	NULL },
	{ 114,	NONE,	NONE,	29,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc29,	MUX_SIZE(MuxDesc29),	FN_GPIO,	-1,	1,	0,	NULL },
	{ 115,	NONE,	NONE,	30,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc30,	MUX_SIZE(MuxDesc30),	FN_GPIO,	-1,	1,	0,	NULL },
	{ 128,	NONE,	NONE,	31,	FN_GPIO_INPUT_HIZ,	NONE,	NULL,	0,	FN_GPIO,	-1,	1,	0,	NULL },
	{ 129,	NONE,	NONE,	32,	FN_GPIO_INPUT_HIZ,	NONE,	NULL,	0,	FN_GPIO,	-1,	1,	0,	NULL },
	{ 130,	NONE,	NONE,	33,	FN_GPIO_INPUT_HIZ,	NONE,	NULL,	0,	FN_GPIO,	-1,	1,	0,	NULL },
	{ 131,	NONE,	NONE,	34,	FN_GPIO_INPUT_HIZ,	NONE,	NULL,	0,	FN_GPIO,	-1,	1,	0,	NULL },
	{ 134,	NONE,	NONE,	35,	FN_GPIO_INPUT_HIZ,	NONE,	NULL,	0,	FN_GPIO,	-1,	1,	0,	NULL },
	{ 135,	NONE,	NONE,	36,	FN_GPIO_INPUT_HIZ,	NONE,	NULL,	0,	FN_GPIO,	-1,	1,	0,	NULL },
	{ 165,	NONE,	NONE,	37,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc37,	MUX_SIZE(MuxDesc37),	FN_GPIO,	-1,	1,	0,	NULL },
	{ 182,	NONE,	NONE,	38,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc38,	MUX_SIZE(MuxDesc38),	FN_GPIO,	-1,	1,	0,	NULL },
	{ 183,	NONE,	NONE,	39,	FN_GPIO_INPUT_HIZ,	NONE,	(mux_sel_t*)&MuxDesc39,	MUX_SIZE(MuxDesc39),	FN_GPIO,	-1,	1,	0,	NULL },
	
};

uint32_t sizeof_g_APinDescription;

uint32_t ardPin2DescIdx[GPIO_TOTAL];

// Sorted by Linux PWM ID
PwmDescription g_APwmDescription[] = {
	{ 0,	0,	-1,	-1,	GP12_PWM0,	-1 },
	{ 1,	1,	-1,	-1,	GP13_PWM1,	-1 },
	{ 2,	38,	-1,	-1,	GP182_PWM2,	-1 },
	{ 3,	39,	-1,	-1,	GP183_PWM3,	-1 },
};
uint32_t sizeof_g_APwmDescription;

AdcDescription g_AdcDescription[] = {
	{ 0,	-1 },
	{ 1,	-1 },
	{ 2,	-1 },
	{ 3,	-1 },
	{ 4,	-1 },
	{ 5,	-1 },
};
uint32_t sizeof_g_AdcDescription;

// Sorted Arduino Pin ID
PinState g_APinState[]=
{
	/* uCurrentPwm	uPwmEnabled	uCurrentInput	uCurrentAdc		*/
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},
	{ 0,		0,		1,		0},	
	{ 0,		0,		1,		0},	
};
uint32_t sizeof_g_APinState;

#ifdef __cplusplus
}
#endif


RingBuffer rx_buffer1;
RingBuffer rx_buffer2;
RingBuffer rx_buffer3;

TTYUARTClass Serial(&rx_buffer1, 0, false);	// ttyGS0  (USB serial)
TTYUARTClass Serial1(&rx_buffer2, 1, false);	// ttyMFD1(IO0/1)
TTYUARTClass Serial2(&rx_buffer3, 2, true);	// ttyMFD2 (system console)


// ----------------------------------------------------------------------------

int variantPinMode(uint8_t pin, uint8_t mode)
{
	/*
	 * Standard (sysfs) or fast-mode UIO options are available for some pins
	 *
	 * The pin at this time is set to Fast-mode by default, if available
	 */

	int ret = 0;
	PinDescription *p = NULL;

	/* Search for entry */
	if ((p = pinDescriptionById(pin)) == NULL) {
		trace_error("%s: invalid pin %u\n", __func__, pin);
		return PIN_EINVAL;
	}

	/* Alternate entries for Fast-Mode GPIO: enable by default if available */
	if (p->pAlternate) {
		p->iAlternate = 1;
		trace_debug("%s: enable Fast-Mode SoC GPIO for pin%u",
			    __func__, pin);
	}
	
	return 0;
}

int variantPinModeIRQ(uint8_t pin, uint8_t mode)
{
	return 0;
}

/*
 * Set the pin as used for PWM and do the muxing at SoC level to enable
 * the PWM output.
 */
void turnOnPWM(uint8_t pin)
{
	int i;

	/* Mark PWM enabled on pin */
	g_APinState[pin].uCurrentPwm = 1;
	g_APinState[pin].uCurrentAdc = 0;

	for (i = 0; i < sizeof_g_APwmDescription; i++)
		if (g_APwmDescription[i].ulArduinoId == pin) {
			sysfsGpioSetCurrentPinmux(g_APwmDescription[i].pwmChPinId,
					PIN_MODE_1);
			break;
		}
}

void turnOffPWM(uint8_t pin)
{
	int handle = 0, ret = 0;
	PinDescription *p = NULL;

	// Scan mappings
	if ((p = pinDescriptionById(pin)) == NULL) {
		trace_error("%s: invalid pin %u\n", __func__, pin);
		return;
	}

	pin2alternate(&p);

	if(p->ulArduinoId == pin) {
		handle = pin2pwmhandle_enable(pin);
		if ((int)PIN_EINVAL == handle) {
			trace_error("%s: bad handle for pin%u",
					__func__, pin);
			return;
		}
		if (sysfsPwmDisable(handle)) {
			trace_error("%s: couldn't disable pwm "
					"on pin%u", __func__, pin);
			return;
		}

		/* Mark PWM disabled on pin */
		g_APinState[pin].uCurrentPwm = 0;
		g_APinState[pin].uPwmEnabled = 0;

		return;
	}

	trace_error("%s: unknown pin%u", __func__, pin);
}

void variantEnableFastGpio(int pin)
{
	int entryno = ardPin2DescIdx[pin];
	PinDescription *p = NULL;
	int ret = 0;

	if (entryno >= sizeof_g_APinDescription) {
		trace_error("%s: ardPin2DescIdx[%d] == %d >= "
				"sizeof_g_APinDescription", __func__, pin, entryno);
		return;
	}

	/* Enable alternate to route to SoC */
	p = &g_APinDescription[entryno];
	p->iAlternate = 1;
}

/*
 * Set the PWM description table accordingly following the PWM swizzler present
 * on the board
 *
 * Suppose the function is called like this: setPwmSwizzler(3, 5, 10, 11). That
 * means the swizzler configuration is as follows:
 *
 *   PWM channel/output 0 is connected to pin 3
 *   PWM channel/output 1 is connected to pin 5
 *   PWM channel/output 2 is connected to pin 10
 *   PWM channel/output 3 is connected to pin 11
 *
 * Default config follows swizzler's default config (3, 5, 6, 9). To change it
 * just call the function in your sketch's setup()
 *
 * Making modifications to the swizzler will break standard GPIO functionality
 * on the affected pins.
 */
void setPwmSwizzler(uint8_t pwmout0, uint8_t pwmout1, uint8_t pwmout2,
		uint8_t pwmout3)
{
	int i;

	/* All parameters must be different */
	if (any_equal(pwmout0, pwmout1, pwmout2, pwmout3)) {
		trace_error("%s All pwm outputs should be different. Got: "
				"%u, %u, %u, %u", __func__, pwmout0, pwmout1,
				pwmout2, pwmout3);
		return;
	}

	/* All parameters must be valid PWM pins */
	if (!all_pwms(pwmout0, pwmout1, pwmout2, pwmout3)) {
		trace_error("%s Some pwm outputs are not valid. Got: "
				"%u, %u, %u, %u", __func__, pwmout0, pwmout1,
				pwmout2, pwmout3);
		return;
	}

	/* Fill the description table with the new pin layout */
	for (i = 0; i < sizeof_g_APwmDescription; i++)
		if (g_APwmDescription[i].ulPWMId == 0)
			g_APwmDescription[i].ulArduinoId = pwmout0;
		else if (g_APwmDescription[i].ulPWMId == 1)
			g_APwmDescription[i].ulArduinoId = pwmout1;
		else if (g_APwmDescription[i].ulPWMId == 2)
			g_APwmDescription[i].ulArduinoId = pwmout2;
		else if (g_APwmDescription[i].ulPWMId == 3)
			g_APwmDescription[i].ulArduinoId = pwmout3;
}

void eepromInit(void)
{
	int fd;
	char buf = 0xff;

	/* Do nothing if file exists already */
	if (access(LINUX_EEPROM, F_OK) == 0)
		return;

	if ((fd = open(LINUX_EEPROM, O_RDWR | O_CREAT, 0660)) < 0) {
		trace_error("%s Can't create EEPROM file: %s", __func__,
				strerror(errno));
		return;
	}

	if (lseek(fd, 0, SEEK_SET)) {
		trace_error("%s Can't lseek in EEPROM file: %s", __func__,
						strerror(errno));
		goto err;
	}

	if (write(fd, &buf, LINUX_EEPROM_SIZE) != LINUX_EEPROM_SIZE)
		trace_error("%s Can't write to EEPROM file: %s", __func__,
				strerror(errno));

	trace_debug("%s Created EEPROM file '%s' of size %u bytes", __func__,
			LINUX_EEPROM, LINUX_EEPROM_SIZE);
err:
	close(fd);
}

void init( int argc, char * argv[] )
{
	if(argc > 1)
		if(Serial.init_tty(argv[1]) != 0)
			return;

	if(Serial1.init_tty(LINUX_SERIAL1_TTY) != 0)
		return;
	if(Serial2.init_tty(LINUX_SERIAL2_TTY) != 0)
		return;

	sizeof_g_APinDescription = sizeof(g_APinDescription)/sizeof(struct _PinDescription);
	sizeof_g_APinState = sizeof(g_APinState)/sizeof(struct _PinState);
	pinInit();

	/* Initialize fast path to GPIO */
	if (fastGpioPciInit())
		trace_error("Unable to initialize fast GPIO mode!");

	sizeof_g_APwmDescription = sizeof(g_APwmDescription)/sizeof(struct _PwmDescription);
	pwmInit();

	sizeof_g_AdcDescription = sizeof(g_AdcDescription)/sizeof(struct _AdcDescription);
	adcInit();

	eepromInit();
}

