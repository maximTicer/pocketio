/*
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY,  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED PRODUCTS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated Products
 * shall not be used except as stated in the Maxim Integrated Products
 * Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products retains all ownership rights.
 *
 ***************************************************************************/
/*
 * 
 * Created: 17 Feb 2016
 * By: Alex Ticer
 * Modified: 10 May 2016
 * By: Alex Ticer
 * Version: 0.4.0
 *
 ***************************************************************************/
#include "PioCom.h"
#include <MAX3109.h>

PioCom::PioCom() {
	
}

PioCom::~PioCom() {

	delete max3109;
	max3109 = NULL;
}

void PioCom::init() {

	uint8_t data = 0x00;
	
	max3109 = new MAX3109();

	//////Configure Clocks
	//For now hardcoded to 115200

	for(int x=0; x<2; x++)
	{
		//PLLCONFIG
		data = 0x019;
		max3109->write(x, MAX3109R_PLLCONFIG, data);

		//BRGCONFIG
		data = 0x08;
		max3109->write(x, MAX3109R_BRGCONFIG, data);

		//DIVLSB
		data = 0x02;
		max3109->write(x, MAX3109R_DIVLSB, data);

		//DIVMSB
		data = 0x00;
		max3109->write(x, MAX3109R_DIVMSB, data);

		//CLKSOURCE
		data = 0x04;//0x08
		max3109->write(x, MAX3109R_CLKSOURCE, data);

		///////Configure Modes

		//set transceiver control
		data = 0x10;
		max3109->write(x, MAX3109R_MODE1, data);

		//set line control
		data = 0x07;//No parity, stop bits, word length 8
		max3109->write(x, MAX3109R_LCR, data);

		//////Configure Interrupts
		//set RX FIFO int to go high when FIFO is not empty
		data = 0x08;
		max3109->write(x, MAX3109R_MODE2, data);
	}
}

void PioCom::read(uint8_t port, uint8_t *dataBuffer, uint8_t bufferLen, uint8_t *rxLen) {

	//get rxFIFOLevel
	*rxLen = readRxFifoLevel(port);

	//check
	if( bufferLen >= *rxLen)//no worries
	{
		readFifo(port, dataBuffer, *rxLen);
		//Able to read entire FIFO, thus clear
		clearInterrupts(port);
	}
	else{
		//will not be able to read entire FIFO,
		//thus should not clear after read
		readFifo(port, dataBuffer, bufferLen);
	}
}

void PioCom::write(uint8_t port, uint8_t *dataBuffer, uint8_t bufferLen) {
	writeFifo(port, dataBuffer, bufferLen);
}

void PioCom::writeFifo(uint8_t port, uint8_t *dataBuffer, uint8_t bufferLen) {

	max3109->puts(port, MAX3109R_THR, bufferLen, dataBuffer);
}

void PioCom::readFifo(uint8_t port, uint8_t *dataBuffer, uint8_t bufferLen) {

	max3109->gets(port, MAX3109R_RHR, bufferLen, dataBuffer);
}

uint8_t PioCom::readRxFifoLevel(uint8_t port) {

	uint8_t response = 0;
	response = max3109->read(port, MAX3109R_RXFIFOLVL);

	return response;
}

void PioCom::clearInterrupts(uint8_t port) {

	max3109->read(port, MAX3109R_ISR);//clear by reading
}



