/*
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY,  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED PRODUCTS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated Products
 * shall not be used except as stated in the Maxim Integrated Products
 * Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products retains all ownership rights.
 *
 ***************************************************************************/
/*
 * 
 * Created: 18 Feb 2016
 * By: Alex Ticer
 * Modified: 1 Aug 2016
 * By: Alex Ticer
 * Version: 0.3.0
 *
 ***************************************************************************/

#include "MAX14890E.h"
#include "PioSpi.h"
#include <stdio.h>

#define WRITE_CONFIG				0xA0
#define READ_CONFIG					0xE0
#define READ_OUTPUT_FAULT			0x60
#define READ_DETAILED_FAULT			0x00

MAX14890E::MAX14890E() {
}

MAX14890E::~MAX14890E() {
}

uint8_t MAX14890E::getMode(uint8_t port) {

	uint8_t messageBuffer[6] = { 0xE0,0,0xE0,0,0xE0,0 };
	uint8_t responseBuffer[6] = { 0,0,0,0,0,0 };
	uint8_t response = 0x00;

	if(port<1 || port>3){
		return 255;
	}

	PioSpi* spi = new PioSpi();
	spi->init();

	if(port == 1){
		messageBuffer[4] = READ_CONFIG;
		//send command
		spi->transfer(messageBuffer, 0, 6, SPI_ENC);

		spi->transfer(messageBuffer, responseBuffer, 6, SPI_ENC);

		response = responseBuffer[5];
	}
	else if(port == 2){
		messageBuffer[2] = READ_CONFIG;
		//send command
		spi->transfer(messageBuffer, 0, 6, SPI_ENC);

		spi->transfer(messageBuffer, responseBuffer, 6, SPI_ENC);

		response = responseBuffer[3];
	}
	else if(port == 3){
		messageBuffer[0] = READ_CONFIG;
		//send command
		spi->transfer(messageBuffer, 0, 6, SPI_ENC);

		spi->transfer(messageBuffer, responseBuffer, 6, SPI_ENC);

		response = responseBuffer[1];
	}

	delete spi;

	//Since A,B,Z are the same, just reading Z
	response &= 0xC0;
	response = response >>6;

	return response;
}


void MAX14890E::setMode(uint8_t port, uint8_t mode) {

	uint8_t messageBuffer[6] = { 0,0,0,0,0,0 };

	if(port<1 || port>3){
		return;
	}

	if(mode>3){
		return;
	}

	PioSpi* spi = new PioSpi();
	spi->init();

	if(port == 1){
		messageBuffer[4] = WRITE_CONFIG;
		//for now setting A,B,Z all to same
		messageBuffer[4] = messageBuffer[4] | mode;//B
		messageBuffer[4] = messageBuffer[4] | (mode<<2);//A
		messageBuffer[5] = (mode<<6);//Z

		spi->transfer(messageBuffer, 0, 6, SPI_ENC);
	}
	else if(port == 2){
		messageBuffer[2] = WRITE_CONFIG;
		//for now setting A,B,Z all to same
		messageBuffer[2] = messageBuffer[2] | mode;//B
		messageBuffer[2] = messageBuffer[2] | (mode<<2);//A
		messageBuffer[3] = (mode<<6);//Z

		spi->transfer(messageBuffer, 0, 6, SPI_ENC);
	}
	else if(port == 3){
		messageBuffer[0] = WRITE_CONFIG;
		//for now setting A,B,Z all to same
		messageBuffer[0] = messageBuffer[0] | mode;//B
		messageBuffer[0] = messageBuffer[0] | (mode<<2);//A
		messageBuffer[1] = (mode<<6);//Z

		spi->transfer(messageBuffer, 0, 6, SPI_ENC);
	}

	delete spi;
}


