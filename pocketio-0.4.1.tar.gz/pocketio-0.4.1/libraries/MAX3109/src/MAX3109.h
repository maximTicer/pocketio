/*
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY,  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED PRODUCTS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated Products
 * shall not be used except as stated in the Maxim Integrated Products
 * Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products retains all ownership rights.
 *
 ***************************************************************************/
/*
 * 
 * Created: 17 Feb 2016
 * By: Alex Ticer
 * Modified: 1 May 2016
 * By: Alex Ticer
 * Version: 0.4.0
 *
 ***************************************************************************/

#ifndef MAX3109_H_
#define MAX3109_H_

#include <Arduino.h>

#define MAX3109R_RHR          (0x00)
#define MAX3109R_THR          (0x00)
#define MAX3109R_IRQEN        (0x01)
#define MAX3109R_ISR          (0x02)
#define MAX3109R_LSRINTEN     (0x03)
#define MAX3109R_LSR          (0x04)
#define MAX3109R_SPCLCHRINTEN (0x05)
#define MAX3109R_SPCLCHARINT  (0x06)
#define MAX3109R_STSINTEN     (0x07)
#define MAX3109R_STSINT       (0x08)
#define MAX3109R_MODE1        (0x09)
#define MAX3109R_MODE2        (0x0a)
#define MAX3109R_LCR          (0x0b)
#define MAX3109R_RXTIMEOUT    (0x0c)
#define MAX3109R_HDPLXDELAY   (0x0d)
#define MAX3109R_IRDA         (0x0e)
#define MAX3109R_FLOWLVL      (0x0f)
#define MAX3109R_FIFOTRGLVL   (0x10)
#define MAX3109R_TXFIFOLVL    (0x11)
#define MAX3109R_RXFIFOLVL    (0x12)
#define MAX3109R_FLOWCTRL     (0x13)
#define MAX3109R_XON1         (0x14)
#define MAX3109R_XON2         (0x15)
#define MAX3109R_XOFF1        (0x16)
#define MAX3109R_XOFF2        (0x17)
#define MAX3109R_GPIOCONFG    (0x18)
#define MAX3109R_GPIODATA     (0x19)
#define MAX3109R_PLLCONFIG    (0x1a)
#define MAX3109R_BRGCONFIG    (0x1b)
#define MAX3109R_DIVLSB       (0x1c)
#define MAX3109R_DIVMSB       (0x1d)
#define MAX3109R_CLKSOURCE    (0x1e)

#define MAX3109_PORT0			0x00
#define MAX3109_PORT1			0x01
#define MAX3109_PORT0_MASK		0xDF
#define MAX3109_PORT1_MASK		0x20

class MAX3109 {
public:
	MAX3109();
	virtual ~MAX3109();

	bool isIrq(uint8_t port);

	uint8_t read(uint8_t port, uint8_t reg);
	void write(uint8_t port, uint8_t reg, uint8_t data);

	void puts(uint8_t port, uint8_t reg, uint8_t len, uint8_t *dataBuffer);
	void gets(uint8_t port, uint8_t reg, uint8_t len, uint8_t *dataBuffer);

};

#endif /* MAX3109_H_ */