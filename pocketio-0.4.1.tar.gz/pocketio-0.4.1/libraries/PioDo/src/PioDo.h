/*
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY,  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED PRODUCTS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated Products
 * shall not be used except as stated in the Maxim Integrated Products
 * Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products retains all ownership rights.
 *
 ***************************************************************************/
/*
 * 
 * Created: 15 Feb 2016
 * By: Alex Ticer
 * Modified: 15 Feb 2016
 * By: Alex Ticer
 * Version: 0.4.0
 *
 ***************************************************************************/

#ifndef PIODO_H_
#define PIODO_H_

#include "Arduino.h"

#define HS_MODE			0
#define PP_MODE			1

#define DO1				1
#define DO2				2
#define DO3				3
#define DO4				4
#define DO5				5
#define DO6				6
#define DO7				7
#define DO8				8


class PioDo {
public:
	PioDo();
	virtual ~PioDo();
	
	uint8_t readMode(uint8_t channel);
	
	uint8_t setMode(uint8_t channel, uint8_t mode);
	uint8_t setModeAll(uint8_t mode);
	
	uint8_t readOutput(uint8_t channel);
	uint8_t readOutputAll();
	
	uint8_t writeOutput(uint8_t channel, uint8_t doValue);
	uint8_t writeOutputAll(uint8_t doValue);
	
	uint8_t readFault(uint8_t channel, uint8_t clearFault);
	uint8_t readFaultAll(uint8_t clearFault);
	
	uint16_t readOutputReadFault(uint8_t clearFault);

private:

};

#endif /* PIODO_H_ */
