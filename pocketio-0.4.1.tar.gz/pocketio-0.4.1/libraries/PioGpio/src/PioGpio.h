/*
 * Copyright (c) 2010 by Cristian Maglie <c.maglie@bug.st>
 * Copyright (c) 2013 Intel Corporation
 * SPI Master library for arduino.
 *
 * This file is free software; you can redistribute it and/or modify
 * it under the terms of either the GNU General Public License version 2
 * or the GNU Lesser General Public License version 2.1, both as
 * published by the Free Software Foundation.
 */

#ifndef _PIOGPIO_H_INCLUDED
#define _PIOGPIO_H_INCLUDED

#include "Arduino.h"

static const uint8_t GP12 = 0;
static const uint8_t GP13 = 1;
static const uint8_t GP14 = 2;
static const uint8_t GP15 = 3;
static const uint8_t GP19 = 4;
static const uint8_t GP20 = 5;
static const uint8_t GP27 = 6;
static const uint8_t GP28 = 7;
static const uint8_t GP40 = 8;
static const uint8_t GP41 = 9;
static const uint8_t GP42 = 10;
static const uint8_t GP43 = 11;
static const uint8_t GP44 = 12;
static const uint8_t GP45 = 13;
static const uint8_t GP46 = 14;
static const uint8_t GP47 = 15;
static const uint8_t GP48 = 16;
static const uint8_t GP49 = 17;
static const uint8_t GP77 = 18;
static const uint8_t GP78 = 19;
static const uint8_t GP79 = 20;
static const uint8_t GP80 = 21;
static const uint8_t GP81 = 22;
static const uint8_t GP82 = 23;
static const uint8_t GP83 = 24;
static const uint8_t GP84 = 25;
static const uint8_t GP109 = 26;
static const uint8_t GP110 = 27;
static const uint8_t GP111 = 28;
static const uint8_t GP114 = 29;
static const uint8_t GP115 = 30;
static const uint8_t GP128 = 31;
static const uint8_t GP129 = 32;
static const uint8_t GP130 = 33;
static const uint8_t GP131 = 34;
static const uint8_t GP134 = 35;
static const uint8_t GP135 = 36;
static const uint8_t GP165 = 37;
static const uint8_t GP182 = 38;
static const uint8_t GP183 = 39;

#endif
