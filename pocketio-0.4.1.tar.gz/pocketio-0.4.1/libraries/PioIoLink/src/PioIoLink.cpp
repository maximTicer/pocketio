/*
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY,  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED PRODUCTS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated Products
 * shall not be used except as stated in the Maxim Integrated Products
 * Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products retains all ownership rights.
 *
 ***************************************************************************/
/*
 * 
 * Created: 21 May 2016
 * By: Alex Ticer
 * Modified: 21 May 2016
 * By: Alex Ticer
 * Version: 0.4.0
 *
 ***************************************************************************/

#include "PioIoLink.h"
#include "PioSpi.h"
#include <stdio.h>

const int ED_IOL_INT_PIN = 23;
const uint8_t IOL4_RAW_READ = 0x65;
const uint8_t IOL4_RAW_WRITE = 0x66;
const uint8_t IOL4_PDCONT_ENABLE = 0x67;
const uint8_t IOL4_PDCONT_DISABLE = 0x68;
const uint8_t IOL4_PDCONT_CLEAR = 0x69;

const uint32_t SPI_MAXBUFFERSIZE = 32;//32
const uint32_t SPI_MAXPACKETSIZE = 30;//30

volatile static bool isRxBufferAwaiting;
volatile static int rxIndexCounter;
static uint8_t txBuffer[IOL_MAXBUFFERSIZE];
static uint8_t rxBuffer[IOL_MAXBUFFERSIZE];

const uint32_t IOL_SPI_SPEED = 1125000;//562000;

PioIoLink::PioIoLink() {

	rxIndexCounter = 0;
	isRxBufferAwaiting = false;
}

PioIoLink::~PioIoLink() {

	detachInterrupt(ED_IOL_INT_PIN);
}

void PioIoLink::init(){
	
	pinMode(ED_IOL_INT_PIN, INPUT);
	attachInterrupt(ED_IOL_INT_PIN, rxISR, RISING);
}

bool PioIoLink::isMessageAwaiting(){
	return isRxBufferAwaiting;
}

void PioIoLink::getMessage(uint8_t *buffer){

	if(buffer != NULL){
		//assuming this must have at least IOL_MAXBUFFERSIZE
		memcpy(buffer, rxBuffer, IOL_MAXBUFFERSIZE);
	}

	isRxBufferAwaiting = false;
}

void PioIoLink::sendMessage(uint8_t *buffer){

	//assuming buffer is in correct format
	uint8_t txBuf[SPI_MAXBUFFERSIZE];
	uint8_t rxBuf[SPI_MAXBUFFERSIZE];

	int length = 0;
	int indexCounter = 0;
	int packetLen = 0;
	int remainder = 0;

	if(buffer[1] > 1){
		//simple length
		length = buffer[1];
	}
	else{
		//extended length
		length = 0;
		length = buffer[2]<<8;
		length |= buffer[1];
	}

	packetLen = length/SPI_MAXPACKETSIZE;
	remainder = length%SPI_MAXPACKETSIZE;
	if(remainder){ packetLen++; }

	PioSpi* pioSpi = new PioSpi();
	//pioSpi->init();//1MHz
	pioSpi->configure(ED_SPI_MODE0, IOL_SPI_SPEED);

	txBuf[0] = IOL4_RAW_WRITE;//IOL4_Raw_Write

	while( packetLen > 0)
	{
		txBuf[1] = packetLen--;
		memcpy(&txBuf[2], &buffer[indexCounter], SPI_MAXPACKETSIZE);

		indexCounter += SPI_MAXPACKETSIZE;

		pioSpi->transfer(txBuf, rxBuf, SPI_MAXBUFFERSIZE, SPI_IOL);
	}

	delete pioSpi;
}

void PioIoLink::setPDCont(uint8_t numParams, uint8_t *paramBuffer, uint8_t indexOfBreak, uint8_t logOpBreak){
	uint8_t txBuf[SPI_MAXBUFFERSIZE];
	uint8_t rxBuf[SPI_MAXBUFFERSIZE];
	
	if(numParams>7){ return; }
	
	txBuf[0] = IOL4_PDCONT_ENABLE;
	txBuf[1] = 0;//NA
	txBuf[2] = numParams;//#ofParams
	
	for(int x=0; x<numParams; x++){
		txBuf[3+x*4] = paramBuffer[x*4];
		txBuf[4+x*4] = paramBuffer[1+x*4];
		txBuf[5+x*4] = paramBuffer[2+x*4];
		txBuf[6+x*4] = paramBuffer[3+x*4];
	}
	
	txBuf[3+numParams*4] = indexOfBreak;
	txBuf[4+numParams*4] = logOpBreak;
	
	PioSpi* pioSpi = new PioSpi();
	//pioSpi->init();//1MHz
	pioSpi->configure(ED_SPI_MODE0, IOL_SPI_SPEED);
	pioSpi->transfer(txBuf, rxBuf, SPI_MAXBUFFERSIZE, SPI_IOL);
	delete pioSpi;
	
}

void PioIoLink::getPD(){
	uint8_t txBuf[SPI_MAXBUFFERSIZE];
	uint8_t rxBuf[SPI_MAXBUFFERSIZE];
	
	PioSpi* pioSpi = new PioSpi();
	//pioSpi->init();//1MHz
	pioSpi->configure(ED_SPI_MODE0, IOL_SPI_SPEED);

	txBuf[0] = IOL4_RAW_READ;
	pioSpi->transfer(txBuf, rxBuf, SPI_MAXBUFFERSIZE, SPI_IOL);
	delete pioSpi;
}

void PioIoLink::clearPD(){
	uint8_t txBuf[SPI_MAXBUFFERSIZE];
	uint8_t rxBuf[SPI_MAXBUFFERSIZE];
	
	PioSpi* pioSpi = new PioSpi();
	//pioSpi->init();//1MHz
	pioSpi->configure(ED_SPI_MODE0, IOL_SPI_SPEED);

	txBuf[0] = IOL4_PDCONT_CLEAR;
	pioSpi->transfer(txBuf, rxBuf, SPI_MAXBUFFERSIZE, SPI_IOL);
	delete pioSpi;
}

void PioIoLink::disablePDCont(){
	uint8_t txBuf[SPI_MAXBUFFERSIZE];
	uint8_t rxBuf[SPI_MAXBUFFERSIZE];
	
	txBuf[0] = IOL4_PDCONT_DISABLE;
	
	PioSpi* pioSpi = new PioSpi();
	//pioSpi->init();//1MHz
	pioSpi->configure(ED_SPI_MODE0, IOL_SPI_SPEED);
	pioSpi->transfer(txBuf, rxBuf, SPI_MAXBUFFERSIZE, SPI_IOL);
	delete pioSpi;
}

void PioIoLink::rxISR(){

	int packetLen = 0;

	uint8_t txBuf[SPI_MAXBUFFERSIZE];
	uint8_t rxBuf[SPI_MAXBUFFERSIZE];

	txBuf[0] = IOL4_RAW_READ;
	txBuf[1] = 0x01;//1 packet

	PioSpi* pioSpi = new PioSpi();
	//pioSpi->init();//1MHz
	pioSpi->configure(ED_SPI_MODE0, IOL_SPI_SPEED);
	
	pioSpi->transfer(txBuf, rxBuf, SPI_MAXBUFFERSIZE, SPI_IOL);

	packetLen = rxBuf[1];
	
	if(packetLen == 1){//single packet being sent
		memcpy(&rxBuffer[rxIndexCounter], &rxBuf[2], SPI_MAXPACKETSIZE);
	}
	else{//multi packet message
		memcpy(&rxBuffer[rxIndexCounter], &rxBuf[2], SPI_MAXPACKETSIZE);
		rxIndexCounter += SPI_MAXPACKETSIZE;
		
		while(packetLen > 0){
			pioSpi->transfer(txBuf, rxBuf, SPI_MAXBUFFERSIZE, SPI_IOL);

			packetLen = rxBuf[1];
			memcpy(&rxBuffer[rxIndexCounter], &rxBuf[2], SPI_MAXPACKETSIZE);
			rxIndexCounter += SPI_MAXPACKETSIZE;
		}
		
	}

	delete pioSpi;
	
	rxIndexCounter =0;
	isRxBufferAwaiting = true;
}
