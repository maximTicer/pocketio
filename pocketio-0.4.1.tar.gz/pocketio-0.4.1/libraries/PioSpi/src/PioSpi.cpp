/*
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY,  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED PRODUCTS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated Products
 * shall not be used except as stated in the Maxim Integrated Products
 * Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products retains all ownership rights.
 *
 ***************************************************************************/
/*
 * 
 * Created: 15 Feb 2016
 * By: Alex Ticer
 * Modified: 27 Jul 2016
 * By: Alex Ticer
 * Version: 0.4.0
 *
 ***************************************************************************/

#include "PioSpi.h"
#include <SPI.h>
#include <pthread.h>

#define ED_SPI_MOSI_PIN				30
#define ED_SPI_MISO_PIN				29
#define ED_SPI_SCLK_PIN				26
#define ED_SPI_NSS_PIN				27
#define ED_SPI_A0_PIN				4
#define ED_SPI_A1_PIN				5
#define ED_SPI_A2_PIN				2
#define ED_SPI_A3_PIN				3

static SPIClass	spi;
static pthread_mutex_t spiMutex = PTHREAD_MUTEX_INITIALIZER;

bool PioSpi::isInit = false;

PioSpi::PioSpi() {
	pthread_mutex_lock(&spiMutex);
}

PioSpi::~PioSpi() {
	pthread_mutex_unlock(&spiMutex);
}

int PioSpi::init() {
	
	if(!isInit){ 
		spi.begin();
		isInit = true;
	}
	
	spi.setDataMode(SPI_MODE0);
	spi.setClockSpeed(SPI_CLOCK_1M);//1MHz

	return configureGpio();
}


int PioSpi::configure(uint8_t mode, uint32_t speed) {
	//Don't need init AND configure, just use one
	
	if(!isInit){
		spi.begin();
		isInit = true;
	}

	if( mode == 0){ spi.setDataMode(SPI_MODE0);; }
	else if( mode == 1){ spi.setDataMode(SPI_MODE1);; }
	else if( mode == 2){ spi.setDataMode(SPI_MODE2);; }
	else if( mode == 3){ spi.setDataMode(SPI_MODE3);; }
	else{
		return -1;
	}
	
	spi.setClockSpeed(speed);

	return configureGpio();
}

int PioSpi::transfer(uint8_t* txBuf, uint8_t* rxBuf, int length, uint8_t spiComm) {
	
	setNssActive(spiComm);

	spi.transferBuffer(txBuf, rxBuf, length);

	setNssInactive();

	return 0;
}

int PioSpi::setNssActive(uint8_t spiComm) {

	//set Muxing
	if(spiComm == SPI_NONE)
	{
		digitalWrite(ED_SPI_A0_PIN, 1);
		digitalWrite(ED_SPI_A1_PIN, 1);
		digitalWrite(ED_SPI_A2_PIN, 1);
		digitalWrite(ED_SPI_A3_PIN, 1);
	}
	else if(spiComm == SPI_DO)
	{
		digitalWrite(ED_SPI_A1_PIN, 0);
		digitalWrite(ED_SPI_A3_PIN, 0);
	}
	else if(spiComm == SPI_DI)
	{
		digitalWrite(ED_SPI_A1_PIN, 0);
		digitalWrite(ED_SPI_A2_PIN, 0);
		digitalWrite(ED_SPI_A3_PIN, 1);
	}
	else if(spiComm == SPI_AO)
	{
		digitalWrite(ED_SPI_A1_PIN, 0);
		digitalWrite(ED_SPI_A2_PIN, 1);
		digitalWrite(ED_SPI_A3_PIN, 1);
	}
	else if(spiComm == SPI_AI)
	{
		digitalWrite(ED_SPI_A0_PIN, 0);
		digitalWrite(ED_SPI_A1_PIN, 1);
		digitalWrite(ED_SPI_A3_PIN, 0);
	}
	else if(spiComm == SPI_COM)
	{
		digitalWrite(ED_SPI_A0_PIN, 0);
		digitalWrite(ED_SPI_A1_PIN, 1);
		digitalWrite(ED_SPI_A2_PIN, 0);
		digitalWrite(ED_SPI_A3_PIN, 1);
	}
	else if(spiComm == SPI_IOL)
	{
		digitalWrite(ED_SPI_A0_PIN, 0);
		digitalWrite(ED_SPI_A1_PIN, 1);
		digitalWrite(ED_SPI_A2_PIN, 1);
		digitalWrite(ED_SPI_A3_PIN, 1);
	}
	else if(spiComm == SPI_ENC)
	{
		digitalWrite(ED_SPI_A0_PIN, 1);
		digitalWrite(ED_SPI_A1_PIN, 1);
		digitalWrite(ED_SPI_A3_PIN, 0);
	}
	else if(spiComm == SPI_ENP)
	{
		digitalWrite(ED_SPI_A0_PIN, 1);
		digitalWrite(ED_SPI_A1_PIN, 1);
		digitalWrite(ED_SPI_A2_PIN, 1);
		digitalWrite(ED_SPI_A3_PIN, 1);
	}
	else{
		digitalWrite(ED_SPI_A0_PIN, 1);
		digitalWrite(ED_SPI_A1_PIN, 1);
		digitalWrite(ED_SPI_A2_PIN, 0);
		digitalWrite(ED_SPI_A3_PIN, 1);
	}

	//Now set NSS
	digitalWrite(ED_SPI_NSS_PIN, 0);

	return 0;
}

int PioSpi::setNssInactive() {

	//reset NSS
	digitalWrite(ED_SPI_NSS_PIN, 1);

	//reset Muxing
	digitalWrite(ED_SPI_A0_PIN, 1);
	digitalWrite(ED_SPI_A1_PIN, 1);
	digitalWrite(ED_SPI_A2_PIN, 1);
	digitalWrite(ED_SPI_A3_PIN, 1);

	return 0;
}

int PioSpi::configureGpio() {

	//nss
	pinMode(ED_SPI_NSS_PIN, OUTPUT);
	digitalWrite(ED_SPI_NSS_PIN, 1);

	//a0
	pinMode(ED_SPI_A0_PIN, OUTPUT);
	digitalWrite(ED_SPI_A0_PIN, 1);

	//a1
	pinMode(ED_SPI_A1_PIN, OUTPUT);
	digitalWrite(ED_SPI_A1_PIN, 1);

	//a2
	pinMode(ED_SPI_A2_PIN, OUTPUT);
	digitalWrite(ED_SPI_A2_PIN, 1);

	//a3
	pinMode(ED_SPI_A3_PIN, OUTPUT);
	digitalWrite(ED_SPI_A3_PIN, 1);
	
	return 0;
}
