/*
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY,  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED PRODUCTS BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated Products
 * shall not be used except as stated in the Maxim Integrated Products
 * Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products retains all ownership rights.
 *
 ***************************************************************************/
/*
 * 
 * Created: 18 Feb 2016
 * By: Alex Ticer
 * Modified: 6 Sep 2016
 * By: Alex Ticer
 * Version: 0.4.2
 *
 ***************************************************************************/
#include "PioEnc.h"
#include <PioSpi.h>
#include <stdio.h>

const uint8_t ENP_CMD = 0x18;
const uint8_t ENC_SET_TERM = 0x30;
const uint8_t ENC_INIT_POS = 0x31;
const uint8_t ENC_GET_POS = 0x32;

const uint32_t SPI_MAXBUFFERSIZE = 32;//32

PioEnc::PioEnc() {
}

PioEnc::~PioEnc() {
	delete max14890E;
	max14890E = NULL;
}

void PioEnc::init(){
	
	max14890E = new MAX14890E();
    
    max14890E->init();

	//default to SEHTL
	//max14890E->setMode(1, SEHTL);
	//max14890E->setMode(2, SEHTL);
	//max14890E->setMode(3, SEHTL);
}

void PioEnc::setTermination(uint8_t port, uint8_t mode){

	uint8_t txBuf[SPI_MAXBUFFERSIZE];
	uint8_t rxBuf[SPI_MAXBUFFERSIZE];
	
	if(port<1 || port>3 || mode>3){
		return;
	}
	
	txBuf[0] = ENP_CMD;
	txBuf[1] = ENC_SET_TERM;
	txBuf[2] = port;
	txBuf[3] = mode;

	PioSpi* pioSpi = new PioSpi();
	
	pioSpi->transfer(txBuf, rxBuf, SPI_MAXBUFFERSIZE, SPI_ENP);
	delete pioSpi;
	
}

void PioEnc::setMode(uint8_t port, uint8_t mode){

	if(port<1 || port>3 || mode>3){
		return;
	}
	else{
		setTermination(port, mode);

		max14890E->setMode(port, mode);
	}
}

void PioEnc::initCount(uint8_t port){

	uint8_t txBuf[SPI_MAXBUFFERSIZE];
	uint8_t rxBuf[SPI_MAXBUFFERSIZE];
	uint32_t temp = 0;

	if(port<1 || port>3){
		return;
	}
	
	txBuf[0] = ENP_CMD;
	txBuf[1] = ENC_INIT_POS;
	txBuf[2] = port;

	PioSpi* pioSpi = new PioSpi();
	
	pioSpi->transfer(txBuf, rxBuf, SPI_MAXBUFFERSIZE, SPI_ENP);
	delete pioSpi;
}

int PioEnc::getCount(uint8_t port){

	uint8_t txBuf[SPI_MAXBUFFERSIZE];
	uint8_t rxBuf[SPI_MAXBUFFERSIZE];
	int value = 0;
	uint32_t temp = 0;
	
	if(port<1 || port>3){
		return 0;
	}
	
	txBuf[0] = ENP_CMD;
	txBuf[1] = ENC_GET_POS;
	txBuf[2] = port;

	PioSpi* pioSpi = new PioSpi();
	
	pioSpi->transfer(txBuf, NULL, SPI_MAXBUFFERSIZE, SPI_ENP);
	
	pioSpi->transfer(txBuf, rxBuf, SPI_MAXBUFFERSIZE, SPI_ENP);
	
	delete pioSpi;
	
	value |= rxBuf[1];
	temp = rxBuf[2];
	value |= temp<<8;
	temp = rxBuf[3];
	value |= temp<<16;
	temp = rxBuf[4];
	value |= temp<<24;

	return value;
}

