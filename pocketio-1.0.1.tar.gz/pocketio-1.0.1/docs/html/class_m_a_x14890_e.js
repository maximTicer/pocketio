var class_m_a_x14890_e =
[
    [ "MAX14890E", "class_m_a_x14890_e.html#ae88b1fbfae0f5f120e64378c1f5b444c", null ],
    [ "~MAX14890E", "class_m_a_x14890_e.html#a16d11aecf20d54f8f331edab64b7c576", null ],
    [ "getMode", "class_m_a_x14890_e.html#acbbe8101a1d5daae32018f3e9312c950", null ],
    [ "init", "class_m_a_x14890_e.html#af9f461a5a5112f724a9fc5beedff034b", null ],
    [ "setMode", "class_m_a_x14890_e.html#a4344dee4e72d58d3a47160224f709b90", null ]
];