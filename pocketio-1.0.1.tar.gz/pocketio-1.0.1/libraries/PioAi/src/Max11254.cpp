/*******************************************************************************
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated
 * Products, Inc. shall not be used except as stated in the Maxim Integrated
 * Products, Inc. Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products, Inc. retains all
 * ownership rights.
 *******************************************************************************
 */
/*
 * 
 * Created: 15 Feb 2016
 * By: Alex Ticer
 * Modified: 6 Sep 2016
 * By: Alex Ticer
 * Version: 1.0.1
 *
 ***************************************************************************/

#include "Max11254.h"
#include <PioSpi.h>
#include "EEPROM.h"

#define SP_1_9		0
#define SP_15_6		3
#define SP_31_2		4
#define SP_62_5		5
#define SP_250		7
#define SP_500		8
#define SP_1000		9

const int AI_NRST_PIN = 31;
const int ED_AI_NRDY_PIN = 8;

const int CAL_VOLTAGE_FULL_ADDR = 0;//0-3=soc, 4-7=sgc
const int CAL_VOLTAGE_ZERO_ADDR = 8;
const int CAL_CURRENT_FULL_ADDR = 16;
const int CAL_CURRENT_ZERO_ADDR = 24;

Max11254::Max11254() {
}

Max11254::~Max11254() {
}

/**
 * Always call before use.
 */
void Max11254::init(){
	pinMode(ED_AI_NRDY_PIN, INPUT);
	pinMode(AI_NRST_PIN, OUTPUT);
	digitalWrite(AI_NRST_PIN, HIGH);
    
    PioSpi* spi = new PioSpi();
    spi->init();
    delete spi;
}

/**
 * Read 8 bit register.
 * @param addr Address for register to be read.
 * @return 8 bit value from register.
 */
uint8_t Max11254::readReg8Bit(uint8_t addr) {

	PioSpi* spi = new PioSpi();
	uint8_t messageBuffer[2] = { 0x00, 0x00 };
	uint8_t responseBuffer[2] = { 0x00, 0x00 };

	messageBuffer[0] = 0xc1 | (addr<<1);

	spi->transfer(messageBuffer, responseBuffer, 2, SPI_AI);

	delete spi;

	return responseBuffer[1];
}

/**
 * Write 8 bit register.
 * @param addr Address for register to be written.
 * @param data 8 bit value to be written to register.
 */
void Max11254::writeReg8Bit(uint8_t addr, uint8_t data) {

	PioSpi* spi = new PioSpi();
	uint8_t messageBuffer[2] = { 0x00, 0x00 };
	uint8_t responseBuffer[2] = { 0x00, 0x00 };

	messageBuffer[0] = 0xc0 | (addr<<1);
	messageBuffer[1] = data;

	spi->transfer(messageBuffer, responseBuffer, 2, SPI_AI);

	delete spi;
}

/**
 * Read 16 bit register.
 * @param addr Address for register to be read.
 * @return 16 bit value from register.
 */
uint16_t Max11254::readReg16Bit(uint8_t addr) {

	PioSpi* spi = new PioSpi();
	uint16_t response = 0;
	uint8_t messageBuffer[3] = { 0x00, 0x00, 0x00 };
	uint8_t responseBuffer[3] = { 0x00, 0x00, 0x00 };

	messageBuffer[0] = 0xc1 | (addr<<1);

	spi->transfer(messageBuffer, responseBuffer, 3, SPI_AI);

	response = ( responseBuffer[1]<<8) | responseBuffer[2];

	delete spi;

	return response;
}

/**
 * Write 16 bit register.
 * @param addr Address for register to be written.
 * @param data 16 bit value to be written to register.
 */
void Max11254::writeReg16Bit(uint8_t addr, uint16_t data) {

	PioSpi* spi = new PioSpi();
	uint8_t messageBuffer[3] = { 0x00, 0x00, 0x00 };
	uint8_t responseBuffer[3] = { 0x00, 0x00, 0x00 };

	messageBuffer[0] = 0xc0 | (addr<<1);
	messageBuffer[1] = data>>8;
	messageBuffer[2] = data & 0x00FF;

	spi->transfer(messageBuffer, responseBuffer, 3, SPI_AI);

	delete spi;
}

/**
 * Read 24 bit register.
 * @param addr Address for register to be read.
 * @return 24 bit value from register.
 */
uint32_t Max11254::readReg24Bit(uint8_t addr) {

	PioSpi* spi = new PioSpi();
	uint32_t response = 0;
	uint8_t messageBuffer[4] = { 0x00, 0x00, 0x00, 0x00 };
	uint8_t responseBuffer[4] = { 0x00, 0x00, 0x00, 0x00 };

	messageBuffer[0] = 0xc1 | (addr<<1);

	spi->transfer(messageBuffer, responseBuffer, 4, SPI_AI);

	response = ( responseBuffer[1]<<16) | ( responseBuffer[2]<<8) | responseBuffer[3];

	delete spi;

	return response;
}

/**
 * Write 24 bit register.
 * @param addr Address for register to be written.
 * @param data 24 bit value to be written to register.
 */
void Max11254::writeReg24Bit(uint8_t addr, uint32_t data) {

	PioSpi* spi = new PioSpi();
	uint8_t messageBuffer[4] = { 0x00, 0x00, 0x00, 0x00 };
	uint8_t responseBuffer[4] = { 0x00, 0x00, 0x00, 0x00 };

	messageBuffer[0] = 0xc0 | (addr<<1);
	messageBuffer[1] = data>>16;
	messageBuffer[2] = (data>>8) & 0x000000FF;
	messageBuffer[3] = data & 0x000000FF;

	spi->transfer(messageBuffer, responseBuffer, 4, SPI_AI);

	delete spi;
}

/**
 * Read internal buffer for MAX11254.
 * @return (0=no buf, 1=PGA buf, 2=PGA buf(low power mode).
 */
uint8_t Max11254::readIntBuffer() {

	uint8_t ctrl2Reg = 0x00;
	ctrl2Reg = readReg8Bit(0x02);//read CTRL2 Reg
	ctrl2Reg &= 0x18;
	ctrl2Reg = ctrl2Reg >>3;

	if( ctrl2Reg==1 ){ return 1; }//PGA buffer
	else if( ctrl2Reg==3 ){ return 2; }//PGA buffer (low power mode)
	else{ return 0; }//no internal buffer
}

/**
 * Write internal buffer for MAX11254.
 * @param (0=no buf, 1=PGA buf, 2=PGA buf(low power mode).
 */
void Max11254::writeIntBuffer(uint8_t buf) {

	uint8_t ctrl2Reg = 0x00;
	ctrl2Reg = readReg8Bit(0x02);//read CTRL2 Reg
	ctrl2Reg &= 0xE7;

	if(buf == 0){ ctrl2Reg |= 0x00; }
	else if( buf == 1){ ctrl2Reg |= 0x08; }
	else{ ctrl2Reg |= 0x18; }

	writeReg8Bit(0x02, ctrl2Reg);
}

/**
 * Read PGA gain for MAX11254.
 * @return (2^gain = x).
 * 0=gain x1,
 * 1=gain x2,
 * 2=gain x4,
 * 3=gain x8,
 * 4=gain x16,
 * 5=gain x32,
 * 6=gain x64,
 * 7=gain x128.
 */
uint8_t Max11254::readPgaGain() {

	uint8_t ctrl2Reg = 0x00;

	ctrl2Reg = readReg8Bit(0x02);
	ctrl2Reg &= 0x07;
	return ctrl2Reg;
}

/**
 * Write PGA gain for MAX11254.
 * @param (2^gain = x).
 * 0=gain x1,
 * 1=gain x2,
 * 2=gain x4,
 * 3=gain x8,
 * 4=gain x16,
 * 5=gain x32,
 * 6=gain x64,
 * 7=gain x128.
 */
void Max11254::writePgaGain(uint8_t gain) {

	uint8_t ctrl2Reg = 0x00;

	ctrl2Reg = readReg8Bit(0x02);
	ctrl2Reg &= 0xF8;
	ctrl2Reg |= gain;

	writeReg8Bit(0x02, ctrl2Reg);
}

/**
 * Read sample rate.
 * @return Byte with sample rate.
 */
uint8_t Max11254::readSamplingRate() {

	uint32_t statReg = 0x00000000;
	uint8_t rate = 0x00;

	statReg = readReg24Bit(0x00);
	statReg &= 0x000000F0;
	rate = statReg>>4;

	return rate;
}

/**
 * Set buffer gain for channel.
 * @param channel Specific channel to determine buffer gain.
 */
void Max11254::swBufGain(uint8_t channel) {

	uint8_t response = 0x00;
	
	if(channel==0 || channel==1 ){
		response = readReg8Bit(0x03);
		response &= 0xF3;
		writeReg8Bit(0x03, response);

		response = readReg8Bit(0x08);
		response &= 0x1F;
		writeReg8Bit(0x08, response);

		response = readReg8Bit(0x01);
		response &= 0xF7;
		writeReg8Bit(0x01, response);

		writeIntBuffer(0);//no internal buffer
	}
	else if(channel==2 || channel==3){
		response = readReg8Bit(0x03);
		response |= 0x0C;
		writeReg8Bit(0x03, response);

		response = readReg8Bit(0x08);
		response &= 0x1F;
		response |= 0x20;
		writeReg8Bit(0x08, response);

		response = readReg8Bit(0x01);
		response &= 0xF7;
		writeReg8Bit(0x01, response);

		writeIntBuffer(2);//select PGA buffers
		writePgaGain(2);//2^2=4
	}
	
}

/**
 * Start sampling ADC.
 * @param rate Set sampling rate for ADC.
 */
void Max11254::startSampling(uint8_t rate) {

	uint8_t message = 0x00;
	PioSpi* spi = new PioSpi();

	message = 0xB0 | rate;

	spi->transfer(&message, 0, 1, SPI_AI);

	delete spi;
}

/**
 * Read sample for specific channel.
 * @param channel Select ADC channel to read sample.
 * @return ADC sample for selected channel.
 */
uint32_t Max11254::readSample(uint8_t channel) {

	if(channel == 0){ return readReg24Bit(0x0E); }
	else if(channel == 1){ return readReg24Bit(0x0F); }
	else if(channel == 2){ return readReg24Bit(0x10); }
	else if(channel == 3){ return readReg24Bit(0x11); }
	else{ return 0; }//Invalid channel
}

/**
 * Perform single sample conversion for ADC.
 * @param channel Set ADC channel.
 * @param rate Set rate for selected channel.
 * @return ADC sample for selected channel.
 */
uint32_t Max11254::singleConvert(uint8_t channel, uint8_t rate) {

	uint8_t message = 0x00;
	uint8_t response = 0x00;
	uint32_t timeoutCounter = 0;
	uint32_t timeoutLimit = 100000;

	response = readReg8Bit(0x01);//read CTRL1 Reg
	response &= 0xFC;
	//response |= 0x08;//unipolar input range
	response &= 0xF7;//bipolar input range
	response |= 0x04;//offset binary
	response |= 0x02;//single cycle mode and single conversion
	writeReg8Bit(0x01, response);

	response = readReg8Bit(0x08);//read sequencer Reg
	response &= 0x07;

	if(channel == 0){ response |= 0x00; }
	else if(channel == 1){ response |= 0x20; }
	else if(channel == 2){ response |= 0x40; }
	else if(channel == 3){ response |= 0x60; }

	writeReg8Bit(0x08, response);

	startSampling(rate);//start conversion at rate

	while( !isReady() && timeoutCounter<timeoutLimit)
	{
		timeoutCounter++;
	}

	if(timeoutCounter == timeoutLimit)
	{
		return 0;
	}

	return readSample(channel);
}

/**
 * Perform self calibration.
 */
void Max11254::selfCal() {

	uint8_t message = 0x00;
	uint8_t response = 0x00;

	response = readReg8Bit(0x01);
	response &= 0x3F;
	writeReg8Bit(0x01, response);//select self-calibration mode

	response = readReg8Bit(0x08);
	response &= 0xE7;
	writeReg8Bit(0x08, response);//select single conversion

	PioSpi* spi = new PioSpi();

	message = 0xA0;//start calibration
	spi->transfer(&message, 0, 1, SPI_AI);
	
	delete spi;

	sleep(0.5);//500ms
}

/**
 * Get zero calibration value for current.
 * @return Stored zero cal float value.
 */
float Max11254::getZeroCalCurrent(){
	
	uint32_t value = 0;
	float zero = 0.0;
	
	//current zero
	value |= EEPROM.read(24)<<24;
	value |= EEPROM.read(25)<<16;
	value |= EEPROM.read(26)<<8;
	value |= EEPROM.read(27);
	
	return (float)value;
}

/**
 * Get full calibration value for current.
 * @return Stored full cal float value.
 */
float Max11254::getFullCalCurrent(){

	uint32_t value = 0;
	float full = 0;

	//current full
	value |= EEPROM.read(16)<<24;
	value |= EEPROM.read(17)<<16;
	value |= EEPROM.read(18)<<8;
	value |= EEPROM.read(19);
	
	return (float)value;
}

/**
 * Set system zero calibration for selected channel.
 * @param channel Selected ADC channel.
 */
void Max11254::systemZeroCal(uint8_t channel) {

	uint8_t message = 0x00;
	uint8_t response = 0x00;
	uint8_t data = 0;
	uint32_t addr = 0;
	uint32_t value = 0;
	float average = 0.0;
	uint32_t timeoutCounter = 0;
	uint32_t timeoutLimit = 100000;
	
	if(channel==0 || channel==1){
		response = readReg8Bit(0x01);
		response &= 0x3F;
		response |= 0x40;
		writeReg8Bit(0x01, response);//select system offset calibration mode

		response = readReg8Bit(0x08);
		response &= 0xE7;
		response |= (channel<<5);
		writeReg8Bit(0x08, response);

		PioSpi* spi = new PioSpi();

		message = 0xA0;//start calibration
		spi->transfer(&message, 0, 1, SPI_AI);
	
		delete spi;

		sleep(0.5);//500ms
	}
	else if(channel==2 || channel==3){
		
		powerDown();
		swBufGain(channel);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		powerDown();
		
		data = (value>>24) & 0xFF;
		EEPROM.write(CAL_CURRENT_ZERO_ADDR, data);
		
		data = (value>>16) & 0xFF;
		EEPROM.write(CAL_CURRENT_ZERO_ADDR+1, data);
		
		data = (value>>8) & 0xFF;
		EEPROM.write(CAL_CURRENT_ZERO_ADDR+2, data);
		
		data = value & 0xFF;
		EEPROM.write(CAL_CURRENT_ZERO_ADDR+3, data);
	}
	
}

/**
 * Set system full calibration for selected channel.
 * @param channel Selected ADC channel.
 */
void Max11254::systemFullCal(uint8_t channel) {

	uint8_t message = 0x00;
	uint8_t response = 0x00;
	uint32_t addr = 0;
	uint8_t data = 0;
	uint32_t value = 0;
	float average = 0.0;
	uint32_t timeoutCounter = 0;
	uint32_t timeoutLimit = 100000;
	
	if(channel==0 || channel==1){
		response = readReg8Bit(0x01);
		response &= 0x3F;
		response |= 0x80;
		writeReg8Bit(0x01, response);//select system full calibration mode

		response = readReg8Bit(0x08);
		response &= 0x07;
		response |= (channel<<5);
		writeReg8Bit(0x08, response);//select single conversion and input channel

		PioSpi* spi = new PioSpi();

		message = 0xA0;//start calibration
		spi->transfer(&message, 0, 1, SPI_AI);
	
		delete spi;

		sleep(0.5);//500ms
	}
	else if(channel==2 || channel==3){
		
		powerDown();
		swBufGain(channel);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		value = singleConvert(channel, SP_1_9);
		powerDown();
		
		
		data = (value>>24) & 0xFF;
		EEPROM.write(CAL_CURRENT_FULL_ADDR, data);
		
		data = (value>>16) & 0xFF;
		EEPROM.write(CAL_CURRENT_FULL_ADDR+1, data);
		
		data = (value>>8) & 0xFF;
		EEPROM.write(CAL_CURRENT_FULL_ADDR+2, data);
		
		data = value & 0xFF;
		EEPROM.write(CAL_CURRENT_FULL_ADDR+3, data);
	}
	
}

/**
 * Store system calibration values for selected channel.
 * @param channel Selected ADC channel.
 */
void Max11254::storeSystemCalValues(uint8_t channel) {

	uint32_t soc = 0;
	uint32_t sgc = 0;
	int soc_addr = 0;
	int sgc_addr = 0;
	uint8_t data = 0x00;
	
	if(channel==0 || channel==1){
		soc_addr = CAL_VOLTAGE_FULL_ADDR;
	}
	else{
		return;
	}
	sgc_addr = soc_addr + 4;
	

	soc = readReg24Bit(0x0A);
	sgc = readReg24Bit(0x0B);
	
	for(int x=0; x<4; x++)
	{
		//soc
		data = (soc >> 8*(3-x)) & 0x000000FF;
		EEPROM.write(soc_addr+x, data);
		
		//sgc
		data = (sgc >> 8*(3-x)) & 0x000000FF;
		EEPROM.write(sgc_addr+x, data);
	}

}

/**
 * Restore system calibration values for selected channel.
 * @param channel Selected ADC channel.
 */
void Max11254::restoreSystemCalValues(uint8_t channel) {

	uint32_t soc = 0;
	uint32_t sgc = 0;
	int soc_addr = 0;
	int sgc_addr = 0;
	uint8_t data = 0x00;

	if(channel==0 || channel==1){
		soc_addr = CAL_VOLTAGE_FULL_ADDR;
	}
	else{
		return;
	}
	sgc_addr = soc_addr + 4;
	
	for(int x=0; x<4; x++)
	{
		//soc
		data = EEPROM.read(soc_addr+x);
		soc = soc | (data<< 8*(3-x) );
		
		//sgc
		data = EEPROM.read(sgc_addr+x);
		sgc = sgc | (data<< 8*(3-x) );
	}

	writeReg24Bit(0x0A, soc);
	writeReg24Bit(0x0B, sgc);
}

/**
 * Reset MAX11254
 */
void Max11254::reset() {
	
	digitalWrite(AI_NRST_PIN, LOW);
	sleep(0.5);
	digitalWrite(AI_NRST_PIN, HIGH);
}

/**
 * Powerdown MAX11254
 */
void Max11254::powerDown() {

	uint8_t response = 0x00;
	uint8_t message = 0x00;

	response = readReg8Bit(0x01);//CTRL 1 Reg
	response &= 0xCF;
	response |= (0x10<<4);
	writeReg8Bit(0x01, response);

	PioSpi* spi = new PioSpi();

	message = 0x90;//power down command
	spi->transfer(&message, 0, 1, SPI_AI);
	
	delete spi;
}

/**
 * Check if ADC reading is ready.
 * @return Boolean if ADC NRDY pin is low.
 */
bool Max11254::isReady() {

	if(digitalRead(ED_AI_NRDY_PIN) == 0){ return true; }//active low
	else{ return false; }//not ready
}

