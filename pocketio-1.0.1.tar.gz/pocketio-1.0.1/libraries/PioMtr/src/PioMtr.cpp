/*******************************************************************************
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated
 * Products, Inc. shall not be used except as stated in the Maxim Integrated
 * Products, Inc. Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products, Inc. retains all
 * ownership rights.
 *******************************************************************************
 */
/*
 * 
 * Created: 16 Feb 2016
 * By: Alex Ticer
 * Modified: 6 Sep 2016
 * By: Alex Ticer
 * Version: 1.0.1
 *
 ***************************************************************************/

#include "PioMtr.h"
#include <PioSpi.h>

const uint8_t ENP_CMD = 0x18;
const uint8_t MTR_READ_EN = 0x10;
const uint8_t MTR_WRITE_EN = 0x11;
const uint8_t MTR_READ_DIR = 0x12;
const uint8_t MTR_WRITE_DIR = 0x13;
const uint8_t MTR_READ_SPEED = 0x14;
const uint8_t MTR_WRITE_SPEED = 0x15;
const uint8_t MTR_READ_FREQ = 0x16;
const uint8_t MTR_WRITE_FREQ = 0x17;

const uint32_t SPI_MAXBUFFERSIZE = 32;//32

PioMtr::PioMtr() {
}

PioMtr::~PioMtr() {
}

/**
 * Always call before use.
 */
void PioMtr::init(){
    PioSpi* spi = new PioSpi();
    spi->init();
    delete spi;
}

/**
 * Read enable for selected motor.
 * @param motor (M1, M2, M3).
 * @return 0=disabled, 1=enabled.
 */
uint8_t PioMtr::readEnable(uint8_t motor) {

	uint8_t txBuf[SPI_MAXBUFFERSIZE];
	uint8_t rxBuf[SPI_MAXBUFFERSIZE];
	uint8_t response = 0;

	if(motor<1 || motor>3){
		return 0;
	}
	
	txBuf[0] = ENP_CMD;
	txBuf[1] = MTR_READ_EN;
	txBuf[2] = motor;

	PioSpi* pioSpi = new PioSpi();
	
	pioSpi->transfer(txBuf, rxBuf, SPI_MAXBUFFERSIZE, SPI_ENP);
	
	//may need second transfer to capture most valid data
	//pioSpi->transfer(txBuf, rxBuf, SPI_MAXBUFFERSIZE, SPI_ENP);
	
	delete pioSpi;
	
	//may want to confirm command byte
	response = rxBuf[1];
	
	return response;
}

/**
 * Write enable for selected motor.
 * @param motor (M1, M2, M3).
 * @param enable 0=disabled, 1=enabled.
 */
void PioMtr::writeEnable(uint8_t motor, uint8_t enable) {

	uint8_t txBuf[SPI_MAXBUFFERSIZE];
	uint8_t rxBuf[SPI_MAXBUFFERSIZE];

	if(motor<1 || motor>3){
		return;
	}
	
	txBuf[0] = ENP_CMD;
	txBuf[1] = MTR_WRITE_EN;
	txBuf[2] = motor;
	txBuf[3] = enable;

	PioSpi* pioSpi = new PioSpi();
	
	pioSpi->transfer(txBuf, rxBuf, SPI_MAXBUFFERSIZE, SPI_ENP);
	delete pioSpi;
}

/**
 * Read direction for selected motor.
 * @param motor (M1, M2, M3).
 * @return 0=COUNTERCLOCKWISE, 1=CLOCKWISE.
 */
uint8_t PioMtr::readDirection(uint8_t motor) {

	uint8_t txBuf[SPI_MAXBUFFERSIZE];
	uint8_t rxBuf[SPI_MAXBUFFERSIZE];
	uint8_t response = 0;

	if(motor<1 || motor>3){
		return 0;
	}
	
	txBuf[0] = ENP_CMD;
	txBuf[1] = MTR_READ_DIR;
	txBuf[2] = motor;

	PioSpi* pioSpi = new PioSpi();
	
	pioSpi->transfer(txBuf, rxBuf, SPI_MAXBUFFERSIZE, SPI_ENP);
	delete pioSpi;
	
	//may want to confirm command byte
	response = rxBuf[1];
	
	return response;
}

/**
 * Write direction for selected motor.
 * @param motor (M1, M2, M3).
 * @param dir 0=COUNTERCLOCKWISE, 1=CLOCKWISE.
 */
void PioMtr::writeDirection(uint8_t motor, uint8_t dir) {

	uint8_t txBuf[SPI_MAXBUFFERSIZE];
	uint8_t rxBuf[SPI_MAXBUFFERSIZE];

	if(motor<1 || motor>3){
		return;
	}
	
	txBuf[0] = ENP_CMD;
	txBuf[1] = MTR_WRITE_DIR;
	txBuf[2] = motor;
	txBuf[3] = dir;

	PioSpi* pioSpi = new PioSpi();
	
	pioSpi->transfer(txBuf, rxBuf, SPI_MAXBUFFERSIZE, SPI_ENP);
	delete pioSpi;
}

/**
 * Read speed for selected motor.
 * @param motor (M1, M2, M3).
 * @return 0=0%, 100=100%.
 */
uint8_t PioMtr::readSpeed(uint8_t motor) {

	uint8_t txBuf[SPI_MAXBUFFERSIZE];
	uint8_t rxBuf[SPI_MAXBUFFERSIZE];
	uint8_t response = 0;

	if(motor<1 || motor>3){
		return 0;
	}
	
	txBuf[0] = ENP_CMD;
	txBuf[1] = MTR_READ_SPEED;
	txBuf[2] = motor;

	PioSpi* pioSpi = new PioSpi();
	
	pioSpi->transfer(txBuf, rxBuf, SPI_MAXBUFFERSIZE, SPI_ENP);
	delete pioSpi;
	
	//may want to confirm command byte
	response = rxBuf[1];
	
	return response;
}

/**
* Write speed for selected motor.
* @param motor (M1, M2, M3).
* @param speed 0=0%, 100=100%.
*/
void PioMtr::writeSpeed(uint8_t motor, uint8_t speed) {

	uint8_t txBuf[SPI_MAXBUFFERSIZE];
	uint8_t rxBuf[SPI_MAXBUFFERSIZE];

	if(motor<1 || motor>3){
		return;
	}
	
	txBuf[0] = ENP_CMD;
	txBuf[1] = MTR_WRITE_SPEED;
	txBuf[2] = motor;
	txBuf[3] = speed;

	PioSpi* pioSpi = new PioSpi();
	
	pioSpi->transfer(txBuf, rxBuf, SPI_MAXBUFFERSIZE, SPI_ENP);
	delete pioSpi;
}

/**
 * Read PWM frequnecy for selected motor.
 * @param motor (M1, M2, M3).
 * @return PWM frequency (default=20000=20KHz, min=1100=1.1KHz, max=10000000=10MHz).
 */
uint32_t PioMtr::readPWMFreq(uint8_t motor) {

	uint8_t txBuf[SPI_MAXBUFFERSIZE];
	uint8_t rxBuf[SPI_MAXBUFFERSIZE];
	uint32_t response = 0;
	uint32_t temp = 0;

	if(motor<1 || motor>3){
		return 0;
	}
	
	txBuf[0] = ENP_CMD;
	txBuf[1] = MTR_READ_FREQ;
	txBuf[2] = motor;

	PioSpi* pioSpi = new PioSpi();
	
	pioSpi->transfer(txBuf, rxBuf, SPI_MAXBUFFERSIZE, SPI_ENP);
	delete pioSpi;
	
	//may want to confirm command byte
	response = rxBuf[1];
	temp = rxBuf[2];
	response |= (temp<<8);
	temp = rxBuf[3];
	response |= (temp<<16);
	temp = rxBuf[4];
	response |= (temp<<24);
	
	return response;
}

/**
 * Write PWM frequnecy for selected motor.
 * @param motor (M1, M2, M3).
 * @param freq PWM frequency to set (default=20000=20KHz, min=1100=1.1KHz, max=10000000=10MHz).
 */
void PioMtr::writePWMFreq(uint8_t motor, uint32_t freq) {

	uint8_t txBuf[SPI_MAXBUFFERSIZE];
	uint8_t rxBuf[SPI_MAXBUFFERSIZE];

	if(motor<1 || motor>3){
		return;
	}
	
	txBuf[0] = ENP_CMD;
	txBuf[1] = MTR_WRITE_FREQ;
	txBuf[2] = motor;
	txBuf[3] = (freq & 0x000000ff);
	txBuf[4] = (freq & 0x0000ff00)>>8;
	txBuf[5] = (freq & 0x00ff0000)>>16;
	txBuf[6] = (freq & 0xff000000)>>24;

	PioSpi* pioSpi = new PioSpi();
	
	pioSpi->transfer(txBuf, rxBuf, SPI_MAXBUFFERSIZE, SPI_ENP);
	delete pioSpi;
}

