var class_wi_fi_server =
[
    [ "WiFiServer", "class_wi_fi_server.html#a84973ac8552fc2b463394297285550f4", null ],
    [ "~WiFiServer", "class_wi_fi_server.html#a32ee7848df5dc97748550ec8ae9265a8", null ],
    [ "available", "class_wi_fi_server.html#abfd839b75fa3c40bd5e22c4a122ed800", null ],
    [ "begin", "class_wi_fi_server.html#a953b3d2a3ea0b0582be9535b6aa908d9", null ],
    [ "closeNotify", "class_wi_fi_server.html#a2e24cac9f4dc0275a007b4634f36a8e1", null ],
    [ "write", "class_wi_fi_server.html#aaed8ea03b4c6fc90aa452f816fbbaf1a", null ],
    [ "write", "class_wi_fi_server.html#a8334bcb9ea8e8035d186d0dc3f1dfb27", null ]
];