/*******************************************************************************
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated
 * Products, Inc. shall not be used except as stated in the Maxim Integrated
 * Products, Inc. Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products, Inc. retains all
 * ownership rights.
 *******************************************************************************
 */
/*
 * 
 * Created: 15 Feb 2016
 * By: Alex Ticer
 * Modified: 6 Sep 2016
 * By: Alex Ticer
 * Version: 1.0.2
 *
 ***************************************************************************/

#include "PioDo.h"
#include <PioSpi.h>

//MAX14912
const uint8_t CLRFLT =						0x80;
const uint8_t CMD_WRITEOUT =				0x00;
const uint8_t CMD_WRITEOUT_CLRFLT =			CMD_WRITEOUT | CLRFLT;
const uint8_t CMD_SETMODE =					0x01;
const uint8_t CMD_SETMODE_CLRFLT =			CMD_SETMODE | CLRFLT;
const uint8_t CMD_SETDETECT =				0x02;
const uint8_t CMD_SETDETECT_CLRFLT =		CMD_SETDETECT | CLRFLT;
const uint8_t CMD_SETCFG =					0x03;
const uint8_t CMD_SETCFG_CLRFLT =			CMD_SETCFG | CLRFLT;
const uint8_t CMD_READREG =					0x20;
const uint8_t CMD_READREG_CLRFLT =			CMD_READREG | CLRFLT;
const uint8_t CMD_READOUT =					0x30;
const uint8_t CMD_READOUT_CLRFLT =			CMD_READOUT | CLRFLT;

PioDo::PioDo() {
}

PioDo::~PioDo() {
}

/**
 * Always call before use.
 */
void PioDo::init(){
    PioSpi* spi = new PioSpi();
    spi->init();
    delete spi;
}

/**
 * Read mode for selected channel.
 * @param channel Selected DO channel (DO1-DO8).
 * @return 0=HS_MODE, 1=PP_MODE.
 */
uint8_t PioDo::readMode(uint8_t channel){
	
	if(channel<1 || channel>8){
		return 255;
	}
	
	PioSpi* spi = new PioSpi();

	uint8_t messageBuffer[2] = { 0x00, 0x00};
	uint8_t responseBuffer[2] = { 0x00, 0x00};
	uint8_t currentValue = 0x00;
	
	//First must get currnet values
	messageBuffer[1] = 0x01;
	messageBuffer[0] = CMD_READREG;
	//data only valid on next cycle
	spi->transfer(messageBuffer, 0, 2, SPI_DO);
	spi->transfer(messageBuffer, responseBuffer, 2, SPI_DO);

	delete spi;
	
	return (responseBuffer[1]>>(channel-1) & 0x01);
}

/**
 * Set mode for all DO channels.
 * @param mode DO mode for all channels (0=HS_MODE, 1=PP_MODE).
 * @return Always returns 0, can ignore.
 */
uint8_t PioDo::setModeAll(uint8_t mode){
	
	PioSpi* spi = new PioSpi();

	uint8_t messageBuffer[2] = { 0x00, 0x00};
	
	messageBuffer[0] = CMD_SETMODE;
	
	if(mode){
		messageBuffer[1] = 0xFF;
	}
	else{
		messageBuffer[1] = 0x00;
	}
	
	//data only valid on next cycle
	spi->transfer(messageBuffer, 0, 2, SPI_DO);

	delete spi;
	
	return 0;
}

/**
 * Set mode for selected DO channel.
 * @param channel Selected DO channel (DO1-DO8).
 * @param mode DO mode for selected channel (0=HS_MODE, 1=PP_MODE).
 * @return Always returns 0, can ignore.
 */
uint8_t PioDo::setMode(uint8_t channel, uint8_t mode){
	
	if(channel<1 || channel>8){
		return 255;
	}
	
	PioSpi* spi = new PioSpi();

	uint8_t messageBuffer[2] = { 0x00, 0x00};
	uint8_t responseBuffer[2] = { 0x00, 0x00};
	uint8_t currentValue = 0x00;
	
	//First must get currnet values
	messageBuffer[1] = 0x01;
	messageBuffer[0] = CMD_READREG;
	//data only valid on next cycle
	spi->transfer(messageBuffer, 0, 2, SPI_DO);
	spi->transfer(messageBuffer, responseBuffer, 2, SPI_DO);
	
	currentValue = responseBuffer[1];
	
	if(mode){
		currentValue = currentValue | (0x01<<(channel-1));
	}
	else{
		currentValue = currentValue & ~(0x01<<(channel-1));
	}
	
	messageBuffer[0] = CMD_SETMODE;
	messageBuffer[1] = currentValue;
	
	//data only valid on next cycle
	spi->transfer(messageBuffer, 0, 2, SPI_DO);

	delete spi;
	
	return 0;
}

/**
 * Read DO for all channels.
 * @return Byte with all DO channel values (bit0=DO1, bit1=DO2,..., bit7=DO8).
 */
uint8_t PioDo::readOutputAll() {

	PioSpi* spi = new PioSpi();

	uint8_t messageBuffer[2] = { 0x00, 0x00};
	uint8_t responseBuffer[2] = { 0x00, 0x00};

	messageBuffer[1] = 0x00;
	messageBuffer[0] = CMD_READOUT;
	//data only valid on next cycle
	spi->transfer(messageBuffer, 0, 2, SPI_DO);
	spi->transfer(messageBuffer, responseBuffer, 2, SPI_DO);

	delete spi;

	return responseBuffer[1];
}

/**
 * Read DO for selected channel.
 * @param channel Selected DO channel (DO1-DO8).
 * @return 0=low, 1=high.
 */
uint8_t PioDo::readOutput(uint8_t channel) {
	
	if(channel<1 || channel>8){
		return 0;
	}

	PioSpi* spi = new PioSpi();

	uint8_t messageBuffer[2] = { 0x00, 0x00};
	uint8_t responseBuffer[2] = { 0x00, 0x00};

	messageBuffer[1] = 0x00;
	messageBuffer[0] = CMD_READOUT;
	//data only valid on next cycle
	spi->transfer(messageBuffer, 0, 2, SPI_DO);
	spi->transfer(messageBuffer, responseBuffer, 2, SPI_DO);

	delete spi;

	return (responseBuffer[1]>>(channel-1) & 0x01);
}

/**
 * Write output for all DO channels.
 * @param doValue Byte with all DO channel values (bit0=DO1, bit1=DO2,...,bit7=DO8).
 * @return Byte with read values from chip output levels.
 */
uint8_t PioDo::writeOutputAll(uint8_t doValue) {

	PioSpi* spi = new PioSpi();

	uint8_t messageBuffer[2] = { 0x00, doValue};
	uint8_t responseBuffer[2] = { 0x00, 0x00};

	messageBuffer[0] = CMD_WRITEOUT;
	
	//data only valid on next cycle
	spi->transfer(messageBuffer, 0, 2, SPI_DO);

	spi->transfer(messageBuffer, responseBuffer, 2, SPI_DO);

	delete spi;

	return responseBuffer[1];
}

/**
 * Write output for selected DO channel.
 * @param channel Selected DO channel (DO1-DO8).
 * @param doValue Value to write to selected channel 0 or 1.
 * @return Byte with read value for selected channel.
 */
uint8_t PioDo::writeOutput(uint8_t channel, uint8_t doValue) {
	
	if(channel<1 || channel>8){
		return 0;
	}

	PioSpi* spi = new PioSpi();

	uint8_t currentValue = 0x00;
	uint8_t messageBuffer[2] = { 0x00, 0x00};
	uint8_t responseBuffer[2] = { 0x00, 0x00};
	
	//First must get currnet values
	messageBuffer[1] = 0x00;
	messageBuffer[0] = CMD_READOUT;
	//data only valid on next cycle
	spi->transfer(messageBuffer, 0, 2, SPI_DO);
	spi->transfer(messageBuffer, responseBuffer, 2, SPI_DO);
	
	currentValue = responseBuffer[1];
	
	if(doValue){
		doValue = 0x01;
		doValue = currentValue | (doValue<<(channel-1));
	}
	else{
		doValue = 0x01;
		doValue = currentValue & ~(doValue<<(channel-1));
	}

	messageBuffer[0] = CMD_WRITEOUT;
	messageBuffer[1] = doValue;
	//data only valid on next cycle
	spi->transfer(messageBuffer, 0, 2, SPI_DO);

	spi->transfer(messageBuffer, responseBuffer, 2, SPI_DO);

	delete spi;

	return (responseBuffer[1]>>(channel-1) & 0x01);
}

/**
 * Read fault for all DO channels.
 * @param clearFault Should faults be cleared after read (0=no, 1=yes).
 * @return Byte with all DO channel faults, (bit0=DO1Fault, bit7=DO8Fault).
 */
uint8_t PioDo::readFaultAll(uint8_t clearFault) {

	PioSpi* spi = new PioSpi();

	uint8_t messageBuffer[2] = { CMD_READOUT, 0x00};
	uint8_t responseBuffer[2] = { 0x00, 0x00};

	//data only valid on next cycle
	spi->transfer(messageBuffer, 0, 2, SPI_DO);

	//obviously this would be on the second read in this case
	//check if we need to change command to clear faults
	if(clearFault){
		messageBuffer[0] = CMD_READOUT_CLRFLT;
	}

	//now ok to clear fault
	spi->transfer(messageBuffer, responseBuffer, 2, SPI_DO);

	delete spi;

	return responseBuffer[0];
}

/**
 * Read fault for selected DO channel.
 * @param channel Selected DO channel (DO1-DO8).
 * @param clearFault Should faults be cleared after read (0=no, 1=yes).
 * @return 0=no fault, 1=fault for selected DO channel.
 */
uint8_t PioDo::readFault(uint8_t channel, uint8_t clearFault) {

	if(channel<1 || channel>8){
		return 0;
	}
	
	PioSpi* spi = new PioSpi();

	uint8_t messageBuffer[2] = { CMD_READOUT, 0x00};
	uint8_t responseBuffer[2] = { 0x00, 0x00};

	//data only valid on next cycle
	spi->transfer(messageBuffer, 0, 2, SPI_DO);

	//obviously this would be on the second read in this case
	//check if we need to change command to clear faults
	if(clearFault){
		messageBuffer[0] = CMD_READOUT_CLRFLT;
	}

	//now ok to clear fault
	spi->transfer(messageBuffer, responseBuffer, 2, SPI_DO);

	delete spi;

	return (responseBuffer[0]>>(channel-1) & 0x01);
}

/**
 * Read output and faults for all DO channels.
 * @param clearFault Should faults be cleared after read (0=no, 1=yes).
 * @return bit0=DO1Level, bit1=DO2Level,..., bit7=DO8Level, bit8=DO1Fault,..., bit15=DO8Fault.
 */
uint16_t PioDo::readOutputReadFault(uint8_t clearFault) {

	PioSpi* spi = new PioSpi();

	uint16_t response = 0x0000;
	uint8_t messageBuffer[2] = { CMD_READOUT, 0x00};
	uint8_t responseBuffer[2] = { 0x00, 0x00};

	//data only valid on next cycle
	spi->transfer(messageBuffer, 0, 2, SPI_DO);

	//obviously this would be on the second read in this case
	if(clearFault){
		messageBuffer[0] = CMD_READOUT_CLRFLT;
	}
	else{
		messageBuffer[0] = CMD_READOUT;
	}
	//now ok to clear fault
	spi->transfer(messageBuffer, responseBuffer, 2, SPI_DO);

	delete spi;

	//want whole message
	response = (responseBuffer[0]<<8) | responseBuffer[1];

	return response;
}
