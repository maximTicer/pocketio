/*******************************************************************************
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All rights Reserved.
 * * This software is protected by copyright laws of the United States and
 * of foreign countries. This material may also be protected by patent laws
 * and technology transfer regulations of the United States and of foreign
 * countries. This software is furnished under a license agreement and/or a
 * nondisclosure agreement and may only be used or reproduced in accordance
 * with the terms of those agreements. Dissemination of this information to
 * any party or parties not specified in the license agreement and/or
 * nondisclosure agreement is expressly prohibited.
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated
 * Products, Inc. shall not be used except as stated in the Maxim Integrated
 * Products, Inc. Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products, Inc. retains all
 * ownership rights.
 *******************************************************************************
 */
/*
 * 
 * Created: 21 May 2016
 * By: Alex Ticer
 * Modified: 1 Nov 2016
 * By: Alex Ticer
 * Version: 1.0.2
 *
 ***************************************************************************/

#include "IoLinkLow.h"
#include "PioSpi.h"
#include <stdio.h>

const int ED_IOL_INT_PIN = 23;
const uint8_t IOL4_RAW_READ = 0x65;
const uint8_t IOL4_RAW_WRITE = 0x66;

const uint32_t SPI_MAXBUFFERSIZE = 32;//32
const uint32_t SPI_MAXPACKETSIZE = 30;//30

volatile static bool isRxBufferAwaiting;
volatile static int rxIndexCounter;
static uint8_t txBuffer[IOL_MAXBUFFERSIZE];
static uint8_t rxBuffer[IOL_MAXBUFFERSIZE];

const uint32_t IOL_SPI_SPEED = 1125000;

IoLinkLow::IoLinkLow() {

	rxIndexCounter = 0;
	isRxBufferAwaiting = false;
}

IoLinkLow::~IoLinkLow() {

	detachInterrupt(ED_IOL_INT_PIN);
}

void IoLinkLow::init(){
    
    PioSpi* spi = new PioSpi();
    spi->init();
    delete spi;
	
	pinMode(ED_IOL_INT_PIN, INPUT);
	attachInterrupt(ED_IOL_INT_PIN, rxISR, RISING);
}

bool IoLinkLow::isMessageAwaiting(){
	return isRxBufferAwaiting;
}

void IoLinkLow::getMessage(uint8_t *buffer, int length){

	if(buffer != NULL){
        int len = min(length, IOL_MAXBUFFERSIZE);
		memcpy(buffer, rxBuffer, len);
	}

	isRxBufferAwaiting = false;
}

bool IoLinkLow::getMessageWithWait(uint8_t *buffer, int length, int waitTime){
    
    if(buffer != NULL){
        int len = min(length, IOL_MAXBUFFERSIZE);
        
        if(waitTime < 0){//means wait indefinitely
            while(!isMessageAwaiting());
            memcpy(buffer, rxBuffer, len);
            return true;
        }
        else{
            for(int x=0; x<waitTime && !isMessageAwaiting(); x++){}
            if(isMessageAwaiting()){
                memcpy(buffer, rxBuffer, len);
                return true;
            }
        }
    }
    
    isRxBufferAwaiting = false;
    return false;
}

void IoLinkLow::sendMessage(uint8_t *buffer){

	//assuming buffer is in correct format
	uint8_t txBuf[SPI_MAXBUFFERSIZE];
	uint8_t rxBuf[SPI_MAXBUFFERSIZE];

	int length = 0;
	int indexCounter = 0;
	int packetLen = 0;
	int remainder = 0;

	if(buffer[1] > 1){
		//simple length
		length = buffer[1];
	}
	else{
		//extended length
		length = 0;
		length = buffer[2]<<8;
		length |= buffer[1];
	}

	packetLen = length/SPI_MAXPACKETSIZE;
	remainder = length%SPI_MAXPACKETSIZE;
	if(remainder){ packetLen++; }

	PioSpi* pioSpi = new PioSpi();

	txBuf[0] = IOL4_RAW_WRITE;//IOL4_Raw_Write

	while( packetLen > 0)
	{
		txBuf[1] = packetLen--;
		memcpy(&txBuf[2], &buffer[indexCounter], SPI_MAXPACKETSIZE);

		indexCounter += SPI_MAXPACKETSIZE;

		pioSpi->transfer(txBuf, rxBuf, SPI_MAXBUFFERSIZE, SPI_IOL);
	}

	delete pioSpi;
}

void IoLinkLow::rxISR(){

	int packetLen = 0;

	uint8_t txBuf[SPI_MAXBUFFERSIZE];
	uint8_t rxBuf[SPI_MAXBUFFERSIZE];

	txBuf[0] = IOL4_RAW_READ;
	txBuf[1] = 0x01;//1 packet

	PioSpi* pioSpi = new PioSpi();
	
	pioSpi->transfer(txBuf, rxBuf, SPI_MAXBUFFERSIZE, SPI_IOL);

	packetLen = rxBuf[1];
	
	if(packetLen == 1){//single packet being sent
		memcpy(&rxBuffer[rxIndexCounter], &rxBuf[2], SPI_MAXPACKETSIZE);
	}
	else{//multi packet message
		memcpy(&rxBuffer[rxIndexCounter], &rxBuf[2], SPI_MAXPACKETSIZE);
		rxIndexCounter += SPI_MAXPACKETSIZE;
		
		while(packetLen > 0){
			pioSpi->transfer(txBuf, rxBuf, SPI_MAXBUFFERSIZE, SPI_IOL);

			packetLen = rxBuf[1];
			memcpy(&rxBuffer[rxIndexCounter], &rxBuf[2], SPI_MAXPACKETSIZE);
			rxIndexCounter += SPI_MAXPACKETSIZE;
		}
		
	}

	delete pioSpi;
	
	rxIndexCounter =0;
	isRxBufferAwaiting = true;
}
