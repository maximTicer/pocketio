/*******************************************************************************
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated
 * Products, Inc. shall not be used except as stated in the Maxim Integrated
 * Products, Inc. Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products, Inc. retains all
 * ownership rights.
 *******************************************************************************
 */
/*
 * 
 * Created: 18 Feb 2016
 * By: Alex Ticer
 * Modified: 6 Sep 2016
 * By: Alex Ticer
 * Version: 1.0.2
 *
 ***************************************************************************/

#include "PioUserLed.h"
#include <PioSpi.h>
#include <stdio.h>

const uint8_t ENP_CMD = 0x18;
const uint8_t ENP_READ_LED = 0xA0;
const uint8_t ENP_WRITE_LED = 0xA1;

const uint32_t SPI_MAXBUFFERSIZE = 32;//32

PioUserLed::PioUserLed() {
}

PioUserLed::~PioUserLed() {
}

/**
 * Always call before use.
 */
void PioUserLed::init(){
    PioSpi* spi = new PioSpi();
    spi->init();
    delete spi;
}

/**
 * Read user LED value.
 * @param led User LED to read (LED1, LED2,..., LED8).
 * @return LED value 0=low, 1=high.
 */
uint8_t PioUserLed::readLed(uint8_t led){

	uint8_t txBuf[SPI_MAXBUFFERSIZE];
	uint8_t rxBuf[SPI_MAXBUFFERSIZE];
	uint8_t response = 0;

	if(led<1 || led>8){
		return 0;
	}
	
	txBuf[0] = ENP_CMD;
	txBuf[1] = ENP_READ_LED;
	txBuf[2] = led;

	PioSpi* pioSpi = new PioSpi();
	
	pioSpi->transfer(txBuf, NULL, SPI_MAXBUFFERSIZE, SPI_ENP);
	
	pioSpi->transfer(txBuf, rxBuf, SPI_MAXBUFFERSIZE, SPI_ENP);
	
	delete pioSpi;
	
	//may want to confirm command byte
	response = rxBuf[1];
	
	return response;
}

/**
 * Write user LED value.
 * @param led User LED to write (LED1, LED2,..., LED8).
 * @param value LED value 0=low, 1=high.
 */
void PioUserLed::writeLed(uint8_t led, uint8_t value){

	uint8_t txBuf[SPI_MAXBUFFERSIZE];
	uint8_t rxBuf[SPI_MAXBUFFERSIZE];

	if(led<1 || led>8){
		return;
	}
	
	txBuf[0] = ENP_CMD;
	txBuf[1] = ENP_WRITE_LED;
	txBuf[2] = led;
	txBuf[3] = value;//0=low, else high

	PioSpi* pioSpi = new PioSpi();
	
	pioSpi->transfer(txBuf, rxBuf, SPI_MAXBUFFERSIZE, SPI_ENP);
	delete pioSpi;
}


