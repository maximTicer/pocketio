var class_e_e_p_r_o_m_class =
[
    [ "read", "class_e_e_p_r_o_m_class.html#aa504020e188bc95dc1d555c6dc254d28", null ],
    [ "write", "class_e_e_p_r_o_m_class.html#a8ebe57942be10984c8fb6ed4b55fe69d", null ]
];