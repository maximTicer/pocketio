var class_s_p_i_class =
[
    [ "SPIClass", "class_s_p_i_class.html#a50c3dcd98bab69db9d3d0ea1b5f463b2", null ],
    [ "attachInterrupt", "class_s_p_i_class.html#a715dff0f3f87dbb64b2ef83d15ee97c0", null ],
    [ "begin", "class_s_p_i_class.html#a4a2646959a242f6af423b04734c003f0", null ],
    [ "detachInterrupt", "class_s_p_i_class.html#abf83d2ea70e46aed0dd278011e1e8741", null ],
    [ "end", "class_s_p_i_class.html#a79d89d8e3f5f1b003cb7b0aed2d77eab", null ],
    [ "setBitOrder", "class_s_p_i_class.html#aa50f88614cda319d2d983749b9a7626d", null ],
    [ "setClockDivider", "class_s_p_i_class.html#ac364a8e46c27d1f6d94a58e9a2455c62", null ],
    [ "setClockSpeed", "class_s_p_i_class.html#a67875294155ca810505aa9c5d78a235e", null ],
    [ "setDataMode", "class_s_p_i_class.html#ae7e89ec7f26a6412fb2d218db331195d", null ],
    [ "transfer", "class_s_p_i_class.html#a3abacb0a60d799ca98c4bad47235e06a", null ],
    [ "transferBuffer", "class_s_p_i_class.html#a50d72a191ff04f008939625e1bdbc9d4", null ]
];