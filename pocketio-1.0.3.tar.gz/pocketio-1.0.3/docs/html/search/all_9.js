var searchData=
[
  ['transfer',['transfer',['../class_pio_spi.html#ad3f3b89fb29807b64b8a2a4311d1a415',1,'PioSpi']]]
];
