/*******************************************************************************
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated
 * Products, Inc. shall not be used except as stated in the Maxim Integrated
 * Products, Inc. Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products, Inc. retains all
 * ownership rights.
 *******************************************************************************
 */
/*
 * 
 * Created: 15 Feb 2016
 * By: Alex Ticer
 * Modified: 14 Sep 2016
 * By: Alex Ticer
 * Version: 1.0.4
 *
 ***************************************************************************/

#include "PioAi.h"
#include "Max11254.h"
#include "EEPROM.h"

#include <stdio.h>

static Max11254* max11254;

PioAi::PioAi() {
}

PioAi::~PioAi() {
	
	delete max11254;
	max11254 = NULL;
}

/**
 * Always call before use.
 */
void PioAi::init(){
	
	max11254 = new Max11254();
	
	max11254->init();

	//max11254->reset();

	//CTRL1 setup
	max11254->writeReg8Bit(0x01, 0x05);
	//CTRL2 setup
	max11254->writeReg8Bit(0x02, 0x20);
	//CTRL3 setup
	max11254->writeReg8Bit(0x03, 0x0C);
	//SEQ setup
	max11254->writeReg8Bit(0x08, 0x01);

	//self cal
	//max11254->selfCal();

	//powerDown
	max11254->powerDown();
}

/**
 * Always call before calibration.
 */
void PioAi::initCal(uint8_t channel){
    
    max11254->selfCal();
		
	max11254->swBufGain(channel);
}

/**
 * Set full calibration for selected channel.
 * @param channel Selected AI channel (0-3).
 */
void PioAi::setFullCal(uint8_t channel){
	
	max11254->systemFullCal(channel);
}

/**
 * Set zero calibration for selected channel.
 * @param channel Selected AI channel (0-3).
 */
void PioAi::setZeroCal(uint8_t channel){
	
	max11254->systemZeroCal(channel);
}

/**
 * Store calibration values for selected channel.
 * @param channel Selected AI channel (0-3).
 */
void PioAi::storeCal(uint8_t channel){

	max11254->storeSystemCalValues(channel);
}

/**
 * Restore calibration values for selected channel.
 * @param channel Selected AI channel (0-3).
 */
void PioAi::restoreCal(uint8_t channel){
	
	max11254->restoreSystemCalValues(channel);
}

/**
 * Read code for selected AI channel.
 * @param channel Selected AI channel (0-3).
 * @param rate Rate for ADC conversion.
 * @return ADC code value (0-16777215).
 */
uint32_t PioAi::readCode(uint8_t channel, uint8_t rate) {

	max11254->swBufGain(channel);

	return max11254->singleConvert(channel, rate);
}

/**
 * Converts AI code value to float for selected AI channel.
 * @param channel Selected Ai channel (0-3).
 * @param rate Rate for ADC conversion.
 * @return ADC float value (-12.0 to +12.0).
 */
float PioAi::readFloat(uint8_t channel, uint8_t rate){
	
	uint32_t code = 0;
	float value = 0.0;
	float zero = 0;
	float full = 0;
	uint8_t data = 0;
	
	max11254->swBufGain(channel);
	
	code = max11254->singleConvert(channel, rate);
	
	if(channel==0 || channel==1){//voltage
		value = (float)(code/16777216.0)*24.0 - 12.0;
	}
	else if(channel==2 || channel==3){//current
		
		zero = max11254->getZeroCalCurrent();
		full = max11254->getFullCalCurrent();
		
		value = (float)(-24.0*(2.0*code-zero-full)/(zero-full));
	}
	
	return value;
}

