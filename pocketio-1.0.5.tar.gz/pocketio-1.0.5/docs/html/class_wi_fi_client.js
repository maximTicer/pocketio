var class_wi_fi_client =
[
    [ "WiFiClient", "class_wi_fi_client.html#aa22ef0fd15a3e2b8ac45eceb0df3bc74", null ],
    [ "WiFiClient", "class_wi_fi_client.html#a10eaa532a8d95b354fbbe0ed23f071dd", null ],
    [ "available", "class_wi_fi_client.html#a027090f7f03b80180d23316cf2647cf8", null ],
    [ "connect", "class_wi_fi_client.html#a9a980afa20a5b18a169837156153a91e", null ],
    [ "connect", "class_wi_fi_client.html#a8a61c19fc573d90e1f59a3e632706af2", null ],
    [ "connected", "class_wi_fi_client.html#aaf69c75c27d44c01484185e9306bd8da", null ],
    [ "flush", "class_wi_fi_client.html#a1cc36e211c82ef9fddf97dda54cacca2", null ],
    [ "operator bool", "class_wi_fi_client.html#ae531112d39020fc3bdab3b318cccfb2d", null ],
    [ "peek", "class_wi_fi_client.html#ab47076806232cb80dbabbaa832919d84", null ],
    [ "read", "class_wi_fi_client.html#a823bdc93651f12103ec4dddb4ee8581d", null ],
    [ "read", "class_wi_fi_client.html#afca9c595c57ca5b67074422918f52b15", null ],
    [ "status", "class_wi_fi_client.html#abccde279d6ac21131ef54a4121d14be5", null ],
    [ "stop", "class_wi_fi_client.html#a43c3ec6dfd681de3eacb1b0ec835991f", null ],
    [ "write", "class_wi_fi_client.html#a48db220c84756ab99fc6356901ded0f9", null ],
    [ "write", "class_wi_fi_client.html#aa8b77cac3d176243ddc26903a99ee9f3", null ],
    [ "WiFiServer", "class_wi_fi_client.html#a98a487eb7fb049868f04e033efbed38f", null ],
    [ "_inactive_counter", "class_wi_fi_client.html#aa5d3ad1fb6d69189f30e17239dc5badd", null ],
    [ "_pCloseServer", "class_wi_fi_client.html#a289c122e1867086d11c531e5e1730e51", null ],
    [ "_sock", "class_wi_fi_client.html#a9564490c418bf500eee095838aaf0ca3", null ],
    [ "connect_true", "class_wi_fi_client.html#aeadf5c083dd76adafe005cabc71f6c8d", null ],
    [ "id", "class_wi_fi_client.html#a1a5e770a76a4fd68ffeec47da9f257ac", null ]
];