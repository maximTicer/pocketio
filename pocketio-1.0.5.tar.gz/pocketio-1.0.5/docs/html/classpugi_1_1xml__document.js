var classpugi_1_1xml__document =
[
    [ "xml_document", "classpugi_1_1xml__document.html#afa82ca6827bda8504ce7dadbc443fa21", null ],
    [ "~xml_document", "classpugi_1_1xml__document.html#af37d8a79f7465ad48d65c2bd13461580", null ],
    [ "document_element", "classpugi_1_1xml__document.html#aa3b17a8891e2c89996ab4c7a2a6759ad", null ],
    [ "load", "classpugi_1_1xml__document.html#abb7db3882f94ac35b870510789a87778", null ],
    [ "load", "classpugi_1_1xml__document.html#a36131b6f1a80a1248666f4e7fe352685", null ],
    [ "load", "classpugi_1_1xml__document.html#ae17a77772fa21a40f3d91d9c79e60d0b", null ],
    [ "load_buffer", "classpugi_1_1xml__document.html#ab29840790e26b2166a395c63a2b2d9bd", null ],
    [ "load_buffer_inplace", "classpugi_1_1xml__document.html#a3e20650182ccbdd175ca069dd5e08632", null ],
    [ "load_buffer_inplace_own", "classpugi_1_1xml__document.html#a9da4bdcdc4ad914fb0f4680b02983502", null ],
    [ "load_file", "classpugi_1_1xml__document.html#aad350209a4a91589fbd7e8cdaf79e010", null ],
    [ "load_file", "classpugi_1_1xml__document.html#ac5a29d9c9e754120a5e0c072b332a25a", null ],
    [ "load_string", "classpugi_1_1xml__document.html#a706a276ee3d5010f2bb8c7eacb75a891", null ],
    [ "reset", "classpugi_1_1xml__document.html#acf2b9daf1d12e12048796118b7a7685d", null ],
    [ "reset", "classpugi_1_1xml__document.html#a4230de3de88f4fe481c4c3d5312aa5cf", null ],
    [ "save", "classpugi_1_1xml__document.html#ae69983f0991300cc9afc8891ff9ca4ac", null ],
    [ "save", "classpugi_1_1xml__document.html#a471d7354af62da143f10943057c99ffa", null ],
    [ "save", "classpugi_1_1xml__document.html#ae0b377bda28c7fbac4ba50b4e3f9d211", null ],
    [ "save_file", "classpugi_1_1xml__document.html#ac67294573cbaa41d3e6210480a9f7f99", null ],
    [ "save_file", "classpugi_1_1xml__document.html#a47e18cd3438eabd64fa2f82d56b08aef", null ]
];