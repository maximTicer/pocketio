var classpugi_1_1xml__writer__file =
[
    [ "xml_writer_file", "classpugi_1_1xml__writer__file.html#a458afaf5231f88e182fa16b13fc2b0a6", null ],
    [ "write", "classpugi_1_1xml__writer__file.html#a228a6e448d8fdbc155032e6eab5d86ed", null ]
];