var NAVTREE =
[
  [ "Pocket IO™ Library", "index.html", [
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Functions", "functions_func.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
".html",
"class_pio_mtr.html#a1ed856340e884f859388210567c54278",
"classpugi_1_1xml__document.html#aad350209a4a91589fbd7e8cdaf79e010",
"classpugi_1_1xpath__variable.html#ae065e6f4380a8a530c7352703c09ff80",
"structopt__true.html#a93a7039f202aca3a935c98aa8e069ea5a3f8405655cc98a5710236f177e042b72"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';