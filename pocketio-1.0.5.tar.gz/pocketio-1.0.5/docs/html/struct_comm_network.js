var struct_comm_network =
[
    [ "bitrate", "struct_comm_network.html#adcca6d41bb4d0e581d3e340519909f46", null ],
    [ "ioLinkRevision", "struct_comm_network.html#a374067dca27a9d421ef8aead1c89a3e8", null ],
    [ "isSioSupported", "struct_comm_network.html#a4590d3a056b1b7779c5595a16904c6c0", null ],
    [ "minCycleTime", "struct_comm_network.html#ad4af0cbf5878331db22564f915d86ec7", null ],
    [ "physics", "struct_comm_network.html#abdc69dda8b44579e5747f9ad2832ca55", null ]
];