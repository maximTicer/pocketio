var struct_condition_t =
[
    [ "subindex", "struct_condition_t.html#ab19cceb810f360165bc2a53aa8c2375a", null ],
    [ "value", "struct_condition_t.html#a34074c2e024bc42c975c6758f8fcf166", null ],
    [ "variableId", "struct_condition_t.html#ab2e9f4adb0772b9a77c12ab549df5c6b", null ]
];