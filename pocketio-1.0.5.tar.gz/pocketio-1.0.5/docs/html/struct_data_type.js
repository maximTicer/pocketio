var struct_data_type =
[
    [ "hasType", "struct_data_type.html#abf9a438e4b1a48b732be068b2ac85577", null ],
    [ "arrayT", "struct_data_type.html#affe09f523d734032ec9ba4f3418ccdf4", null ],
    [ "isArray", "struct_data_type.html#a054c6a8745cdebd44928da86c7a95bfd", null ],
    [ "isRecord", "struct_data_type.html#a11d44c55416cbf4327bd96d35a1a88d7", null ],
    [ "isSimple", "struct_data_type.html#abd22848c8d5dfe09efe7d51e52baa2a3", null ],
    [ "recordT", "struct_data_type.html#a0d06b9121259b3774a90cd895c236588", null ],
    [ "simpleDataType", "struct_data_type.html#aac8e35ba91ccf751e4415597fcf0c2fe", null ]
];