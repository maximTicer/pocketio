var struct_device_identity =
[
    [ "deviceFamily", "struct_device_identity.html#a36287186f4a63e6d004b88fedd8633c2", null ],
    [ "deviceId", "struct_device_identity.html#ad4434b709e1b09fc10c37a8c4eb312c8", null ],
    [ "deviceVarantIndex", "struct_device_identity.html#a3a68f8598b1f6190ab49b87edd62d696", null ],
    [ "deviceVariantCollection", "struct_device_identity.html#a16016c5b7dc5b8a4e4cb0d34b72adeb6", null ],
    [ "vendorId", "struct_device_identity.html#a3bc8d4d5102aa3317d5df8e1a68e169a", null ],
    [ "vendorLogo", "struct_device_identity.html#a2dc0a165ccb02513a6e34e5afd1516fd", null ],
    [ "vendorName", "struct_device_identity.html#ae32606ca123117f676be606163729767", null ],
    [ "vendorText", "struct_device_identity.html#a555179e8b0d096aacae2ce5133a309d5", null ],
    [ "vendorUrl", "struct_device_identity.html#a51e20c047188a10d195ecc48b7efe674", null ]
];