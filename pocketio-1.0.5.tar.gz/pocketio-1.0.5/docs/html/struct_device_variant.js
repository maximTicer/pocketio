var struct_device_variant =
[
    [ "deviceIcon", "struct_device_variant.html#aa8646194899359c5eb45b6ff9623d611", null ],
    [ "deviceSymbol", "struct_device_variant.html#a6d8242d285939bde2524dd128aaa1618", null ],
    [ "firmwareRevision", "struct_device_variant.html#a7154ebe217619271be8446928e2ead0c", null ],
    [ "hardwareRevision", "struct_device_variant.html#a1861e008936ef2c9b425c3194f97253b", null ],
    [ "productId", "struct_device_variant.html#a393b681549a41cdc968a093c2b9b501b", null ],
    [ "productName", "struct_device_variant.html#a089216b6865e860648e67948dd12934a", null ],
    [ "productText", "struct_device_variant.html#a1a229a806e3992892ed8548d1f0d1a63", null ]
];