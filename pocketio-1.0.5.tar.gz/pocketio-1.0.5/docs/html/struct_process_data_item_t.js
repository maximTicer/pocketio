var struct_process_data_item_t =
[
    [ "bitLength", "struct_process_data_item_t.html#a632b4fd50099bb885c4bfc29a9648dc7", null ],
    [ "dataType", "struct_process_data_item_t.html#a2c1cd46bd2738497925ef32c38379aa3", null ],
    [ "idString", "struct_process_data_item_t.html#a4cf78ffdaae516981b072e2997e9599a", null ],
    [ "isDataType", "struct_process_data_item_t.html#a82ed9399aaae256af66564617df37bae", null ],
    [ "name", "struct_process_data_item_t.html#ad860d52e1eae64822e371a8d1c7a9aa0", null ]
];