/*******************************************************************************
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated
 * Products, Inc. shall not be used except as stated in the Maxim Integrated
 * Products, Inc. Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products, Inc. retains all
 * ownership rights.
 *******************************************************************************
 */
/*
 * 
 * Created: 17 Feb 2016
 * By: Alex Ticer
 * Modified: 6 Sep 2016
 * By: Alex Ticer
 * Version: 1.0.5
 *
 ***************************************************************************/

#include "MAX3109.h"
#include <PioSpi.h>

const int UART_NIRQ = 10;//dont currently use

MAX3109::MAX3109() {
}

MAX3109::~MAX3109() {
}

/**
 * Always call before use.
 */
void MAX3109::init(){
    PioSpi* spi = new PioSpi();
    spi->init();
    delete spi;
}

/**
 * Check if interrupt has been triggered.
 * @param port Either MAX3109_PORT0 or MAX3109_PORT1.
 * @return Boolean indicating whether interrupt has been triggered.
 */
bool MAX3109::isIrq(uint8_t port) {

	uint8_t response = 0x00;
	uint8_t messageBuffer[2] = { 0x00, 0x00};
	uint8_t responseBuffer[2] = { 0x00, 0x00};

	PioSpi* spi = new PioSpi();

	messageBuffer[0] = MAX3109R_LSR & 0x7F;//arb reg with no COR

	if(port>0){
		messageBuffer[0] |= MAX3109_PORT1_MASK;

		spi->transfer(messageBuffer, responseBuffer, 2, SPI_COM);

		delete spi;

		response = (responseBuffer[0] & 0x02)>>1;

		return response;
	}
	else{
		messageBuffer[0] &= MAX3109_PORT0_MASK;

		spi->transfer(messageBuffer, responseBuffer, 2, SPI_COM);

		delete spi;

		response = (responseBuffer[0] & 0x01);

		return response;
	}
}

/**
 * Read register for port.
 * @param port Either MAX3109_PORT0 or MAX3109_PORT1.
 * @param reg MAX3109 register to read.
 * @return Register value.
 */
uint8_t MAX3109::read(uint8_t port, uint8_t reg) {

	uint8_t messageBuffer[2] = { 0x00, 0x00};
	uint8_t responseBuffer[2] = { 0x00, 0x00};

	PioSpi* spi = new PioSpi();

	messageBuffer[0] = reg & 0x7F;

	if(port>0){ messageBuffer[0] |= MAX3109_PORT1_MASK; }
	else{ messageBuffer[0] &= MAX3109_PORT0_MASK; }

	spi->transfer(messageBuffer, responseBuffer, 2, SPI_COM);

	delete spi;

	return responseBuffer[1];
}

/**
 * Write to register for port.
 * @param port Either MAX3109_PORT0 or MAX3109_PORT1.
 * @param reg MAX3109 register to write data.
 * @param data Byte to enter into requested register for port.
 */
void MAX3109::write(uint8_t port, uint8_t reg, uint8_t data) {

	uint8_t messageBuffer[2] = { 0x00, 0x00};
	PioSpi* spi = new PioSpi();

	messageBuffer[0] = reg | 0x80;
	if(port>0){ messageBuffer[0] |= MAX3109_PORT1_MASK; }
	else{ messageBuffer[0] &= MAX3109_PORT0_MASK; }

	messageBuffer[1] = data;

	spi->transfer(messageBuffer, 0, 2, SPI_COM);

	delete spi;
}

/**
 * Read from multiple registers.
 * @param port Either MAX3109_PORT0 or MAX3109_PORT1.
 * @param reg MAX3109 register to read data.
 * @param len Number of bytes to be read.
 * @param dataBuffer Byte buffer to store read registers, must be at least len length.
 */
void MAX3109::gets(uint8_t port, uint8_t reg, uint8_t len, uint8_t* dataBuffer) {

	uint8_t messageBuffer[len+1];
	uint8_t responseBuffer[len+1];
	PioSpi* spi = new PioSpi();

	messageBuffer[0] = reg & 0x7F;
	if(port>0){ messageBuffer[0] |= MAX3109_PORT1_MASK; }
	else{ messageBuffer[0] &= MAX3109_PORT0_MASK; }

	spi->transfer(messageBuffer, responseBuffer, len+1, SPI_COM);

	delete spi;

	for(int x=0; x<len; x++)
	{
		dataBuffer[x] = responseBuffer[x+1];
	}
}

/**
 * Write to multiple registers.
 * @param port Either MAX3109_PORT0 or MAX3109_PORT1.
 * @param reg MAX3109 register to write data.
 * @param len Number of bytes to be written.
 * @param dataBuffer Byte buffer containing data to be written to registers, must be at least len length.
 */
void MAX3109::puts(uint8_t port, uint8_t reg, uint8_t len, uint8_t* dataBuffer) {

	uint8_t messageBuffer[len+1];
	PioSpi* spi = new PioSpi();

	messageBuffer[0] = reg | 0x80;
	if(port>0){ messageBuffer[0] |= MAX3109_PORT1_MASK; }
	else{ messageBuffer[0] &= MAX3109_PORT0_MASK; }

	for(int x=0; x<len; x++)
	{
		messageBuffer[x+1] = dataBuffer[x];
	}

	spi->transfer(messageBuffer, 0, len+1, SPI_COM);

	delete spi;
}



