/*******************************************************************************
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All rights Reserved.
 * * This software is protected by copyright laws of the United States and
 * of foreign countries. This material may also be protected by patent laws
 * and technology transfer regulations of the United States and of foreign
 * countries. This software is furnished under a license agreement and/or a
 * nondisclosure agreement and may only be used or reproduced in accordance
 * with the terms of those agreements. Dissemination of this information to
 * any party or parties not specified in the license agreement and/or
 * nondisclosure agreement is expressly prohibited.
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated
 * Products, Inc. shall not be used except as stated in the Maxim Integrated
 * Products, Inc. Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products, Inc. retains all
 * ownership rights.
 *******************************************************************************
 */
/*
 * 
 * Created: 1 Nov 2016
 * By: Alex Ticer
 * Modified: 17 Dec 2016
 * By: Alex Ticer
 * Version: 1.0.5
 *
 ***************************************************************************/

#include "PioIoLink.h"
#include "IoLinkLow.h"
#include "IoLinkObject.h"
#include <stdio.h>

const uint8_t GETINFO                            = 0x00;
const uint8_t SETPDI                             = 0x01;
const uint8_t GETPDI                             = 0x02;
const uint8_t CNTSTA                             = 0x03;
const uint8_t SETPORTCNFPAR                      = 0x04;
const uint8_t GETPORTCNFPAR                      = 0x05;
const uint8_t SETDSHDR                           = 0x06;
const uint8_t GETDSHDR                           = 0x07;
const uint8_t UPLDS                              = 0x08;
const uint8_t DWNDS                              = 0x09;
const uint8_t ISDUREQ                            = 0x0A;
const uint8_t ISDUGET                            = 0x0B;
const uint8_t RDEVENT                            = 0x0C;

const int IOL_WAIT_TIME = 1000000;

IoLinkLow iol;
IoLinkObject* iolObjects[4];

//TODO need to handle extended length

PioIoLink::PioIoLink() {
    for(int x=0; x<4; x++){
        iolObjects[x] = new IoLinkObject();
    }
}

PioIoLink::~PioIoLink() {
    for(int x=0; x<4; x++){
        delete iolObjects[x];
    }
}

void PioIoLink::init(){
    
    iol.init();
    
    activePdInLen = 0;
}

bool PioIoLink::setChannelWithIoddFilePath(uint8_t channel, const char *filePath){
    if(!isValidChannel(channel)){ return false; }
    
    return iolObjects[channel-1]->iodd.setIoddFilePath(filePath);
}

void PioIoLink::resetChannel(uint8_t channel){
    if(!isValidChannel(channel)){ return; }
    
    delete iolObjects[channel-1];
    
    iolObjects[channel-1] = new IoLinkObject();
}

void PioIoLink::startIoLink(uint8_t channel){
    if(!isValidChannel(channel)){ return; }
    
    uint8_t prevOpMode = iolObjects[channel-1]->portConfig.opMode;
    
    //Should enable user to change these
    //TODO
    iolObjects[channel-1]->portConfig.opMode = 3;
    iolObjects[channel-1]->portConfig.cycleMode = 1;
    int minCycleTime = iolObjects[channel-1]->iodd.network.minCycleTime.toInt()/100;
    uint16_t cycleTime = minCycleTime + 2;//sometimes it seems unstable at fastest
    iolObjects[channel-1]->portConfig.cycleTime = cycleTime;
    
    sendPdInterface(channel);
    delay(5);
    sendPortConfig(channel);
    delay(5);
    sendControlStatus(channel, true);
    delay(500);
    
    if(prevOpMode != 3){//prevents multiple call issue
        activePdInLen += iolObjects[channel-1]->pdInPosLen;
    }
}

void PioIoLink::stopIoLink(uint8_t channel){
    if(!isValidChannel(channel)){ return; }
    
    if(iolObjects[channel-1]->portConfig.opMode != 0){
        activePdInLen -= iolObjects[channel-1]->pdInPosLen;
    }

    iolObjects[channel-1]->portConfig.opMode = 0;
    iolObjects[channel-1]->portConfig.cycleMode = 0;
    
    activePdInLen -= iolObjects[channel-1]->pdInPosLen;
    
    sendPdInterface(channel);
    delay(5);
    sendPortConfig(channel);
    delay(5);
    sendControlStatus(channel, false);
    delay(5);
    
}

int PioIoLink::getTotalProcessDataIndexCount(uint8_t channel){
    if(!isValidChannel(channel)){ return 0; }
    
    return iolObjects[channel-1]->iodd.processDataCollection.size();
}

bool PioIoLink::setProcessDataIndex(uint8_t channel, int pdIndex){
    if(!isValidChannel(channel)){ return false; }
    
    const int LIMIT = iolObjects[channel-1]->iodd.processDataCollection.size();
    
    if(pdIndex<0 || pdIndex>=LIMIT){
        return false;
    }
    
    iolObjects[channel-1]->pdIndex = pdIndex;
    
    return true;
}

int PioIoLink::getProcessDataInLen(uint8_t channel){
    if(!isValidChannel(channel)){ return 0; }
    
    return getPdInNumOfBytes(channel);
}

bool PioIoLink::getProcessData(uint8_t channel, uint8_t array[], int length){
    if(!isValidChannel(channel)){ return false; }
    
    uint8_t pdInLen = iolObjects[channel-1]->pdInPosLen;
    if(length < pdInLen){ return false; }
    
    uint8_t expectedArrayLength = 11 + activePdInLen;
    uint8_t rxBuf[expectedArrayLength];
    
    sendControlStatus(channel, true);
    delay(5);
    
    if(iol.getMessageWithWait(rxBuf, expectedArrayLength, IOL_WAIT_TIME)){
        
        uint8_t actualLength = rxBuf[1];
        if(actualLength == expectedArrayLength){
            
            uint8_t pdInOffset = iolObjects[channel-1]->pdInPosOffset;
            uint8_t packetOffset = 10 + pdInOffset;
            
            for(int x=0; x<pdInLen; x++){
                array[x] = rxBuf[packetOffset+x];
                //May want to format, for now raw
                //Potential TODO
            }
            return true;
        }
    }
    
    return false;
}

int PioIoLink::getIsduByteLen(uint8_t channel, uint16_t index){
    if(!isValidChannel(channel)){ return 0; }
    
    //Check if it exists
    std::map<int, VariableT>::iterator it;
    it = iolObjects[channel-1]->iodd.isduVariableCollection.find(index);
    if( it != iolObjects[channel-1]->iodd.isduVariableCollection.end()){
        DataType dataType = iolObjects[channel-1]->iodd.isduVariableCollection[index].dataType;
        int byteLen = 0;
        
        if(dataType.isSimple){
            byteLen = dataType.simpleDataType.bitLength.toInt()/8;
            if(dataType.simpleDataType.bitLength.toInt()%8 != 0){
                byteLen++;
            }
        }
        else if(dataType.isRecord){
            byteLen = dataType.recordT.bitLength.toInt()/8;
            if(dataType.recordT.bitLength.toInt()%8 != 0){
                byteLen++;
            }
        }
        else if(dataType.isArray){
            int count = dataType.arrayT.count.toInt();
            int bitLength = dataType.arrayT.simpleDataType.bitLength.toInt();
            byteLen = (count*bitLength)/8;
            if( (count*bitLength)%8 != 0){
                byteLen++;
            }
        }
        
        return byteLen;
    }
    else{//index wasnt found, return 0
        return 0;
    }
    
}

bool PioIoLink::readIsdu(uint8_t channel, uint16_t index, uint8_t subindex, uint8_t buffer[], uint8_t *len){
    
    if(!isValidChannel(channel)){ return false; }
    
    uint8_t length = 8;
    
    uint8_t indexUpper = (index >> 8) & 0xff;
    uint8_t indexLower = index & 0xff;
    
    uint8_t txBuf1[] = {ISDUREQ, length, channel-1, 1, indexUpper, indexLower, subindex, 0};
    
    insertCheckSum(txBuf1, length);
    iol.sendMessage(txBuf1);
    iol.getMessage(NULL, 0);
    delay(5);
    
    length = 4;
    
    uint8_t rxBuf[IOL_MAXBUFFERSIZE];
    uint8_t txBuf2[] = {ISDUGET, length, channel-1, 0};
    
    insertCheckSum(txBuf2, length);
    
    uint8_t repeatCounter = 0;
    
    while(repeatCounter < 10){
        
        iol.sendMessage(txBuf2);
        iol.getMessage(NULL, 0);
        delay(10);
        
        if(iol.getMessageWithWait(rxBuf, IOL_MAXBUFFERSIZE, IOL_WAIT_TIME)){
            
            uint8_t actualLength = rxBuf[1];
            uint8_t isduDataLength = actualLength - 6;
            if(isduDataLength<=0){ return false; }
            
            uint8_t port = rxBuf[2];
            if( port != (channel-1)){ return false; }
            
            uint8_t isduAnswer = rxBuf[3];
            
            //TODO, handle errors
            if(isduAnswer==2 || isduAnswer==4){
                //check error codes, etc...
                repeatCounter++;
            }
            else if( isduAnswer == 3){
                
                memcpy(buffer, &rxBuf[5], isduDataLength);
                *len = isduDataLength;
                return true;
            }
        }
    }
    
    return false;
}

bool PioIoLink::writeIsdu(uint8_t channel, uint16_t index, uint8_t subindex, uint8_t buffer[], uint8_t len){
    
    if(!isValidChannel(channel)){ return false; }
    
    uint8_t length = 8 + len;
    
    uint8_t indexUpper = (index >> 8) & 0xff;
    uint8_t indexLower = index & 0xff;
    
    uint8_t txBuf[length];
    txBuf[0] = ISDUREQ;
    txBuf[1] = length;
    txBuf[2] = channel-1;
    txBuf[3] = 0;
    txBuf[4] = indexUpper;
    txBuf[5] = indexLower;
    txBuf[6] = subindex;
    //txBuf[7] = 3;
    //txBuf[8] = 0;
    
    txBuf[length-1] = 0;
    
    for(int x=0; x<len; x++){
        txBuf[7+x] = buffer[x];
    }
    
    
    insertCheckSum(txBuf, length);
    iol.sendMessage(txBuf);
    delay(500);
    
    if(iol.getMessageWithWait(txBuf, 6+len, IOL_WAIT_TIME)){
        
        //delay(1000);
        return true;
    }
    
    return false;
}

void PioIoLink::clearAll(){
    
    for(int x=0; x<2; x++){
        sendResetForAllPDs();
        resetChannel(1);
        sendPortConfig(1);
        resetChannel(2);
        sendPortConfig(2);
        resetChannel(3);
        sendPortConfig(3);
        resetChannel(4);
        sendPortConfig(4);
        sendResetForAllControls();
        delay(5);
    }
    
}

//////////private

void PioIoLink::sendResetForAllPDs(){
    uint8_t txBuf[7] = {SETPDI,0x07,0x00,0x00,0x00,0x00,0x00};
    insertCheckSum(txBuf, 7);
    iol.sendMessage(txBuf);
}

void PioIoLink::sendResetForAllControls(){
    uint8_t txBuf[11] = {CNTSTA,0x0B,0x80,0x74,0x80,0x74,0x80,0x74,0x80,0x74,0x00};
    insertCheckSum(txBuf, 11);
    iol.sendMessage(txBuf);
}

void PioIoLink::sendPdInterface(uint8_t channel){
    if(!isValidChannel(channel)){ return; }
    
    updateAllPdPosData();
    
    uint8_t length = 7;
    
    unsigned pdInLen = 0;
    for(int x=0; x<4; x++){
        pdInLen += iolObjects[x]->pdInPosLen;
    }
    
    unsigned pdOutLen = 0;
    for(int x=0; x<4; x++){
        pdOutLen += iolObjects[x]->pdOutPosLen;
    }
    
    uint8_t pdInLenUpper = (pdInLen >> 8) & 0xff;
    uint8_t pdInLenLower = pdInLen & 0xff;
    uint8_t pdOutLenUpper = (pdOutLen >> 8) & 0xff;
    uint8_t pdOutLenLower = pdOutLen & 0xff;
    
    uint8_t txBuf[] = {SETPDI, length, pdOutLenUpper, pdOutLenLower, pdInLenUpper, pdInLenLower, 0};
    
    insertCheckSum(txBuf, length);
    iol.sendMessage(txBuf);
}

void PioIoLink::sendPortConfig(uint8_t channel){
    if(!isValidChannel(channel)){ return; }
    
    updateAllPdPosData();
    
    uint8_t length = 40;
    PortConfigObject pConfig = iolObjects[channel-1]->portConfig;
    uint16_t cycleTime = pConfig.cycleTime;
    uint8_t cycleTimeUpper = (cycleTime>>8) & 0xff;
    uint8_t cycleTimeLower = (cycleTime & 0xff);
    
    uint8_t pdInNum = iolObjects[channel-1]->pdInPosLen;
    uint8_t pdOutNum = iolObjects[channel-1]->pdOutPosLen;//always leave at 0?
    
    uint8_t pdInPosOffset = iolObjects[channel-1]->pdInPosOffset;
    uint8_t pdOutPosOffset = iolObjects[channel-1]->pdOutPosOffset;
    
    int vendorId = iolObjects[channel-1]->iodd.deviceIdentity.vendorId.toInt();
    uint8_t vendorIdUpper = (vendorId >> 8) & 0xff;
    uint8_t vendorIdLower = vendorId & 0xff;
    
    int deviceId = iolObjects[channel-1]->iodd.deviceIdentity.deviceId.toInt();
    uint8_t deviceId3 = (deviceId >> 24) & 0xff;
    uint8_t deviceId2 = (deviceId >> 16) & 0xff;
    uint8_t deviceId1 = (deviceId >> 8) & 0xff;
    uint8_t deviceId0 = deviceId & 0xff;
    
    uint8_t txBuf[] = {SETPORTCNFPAR, length, channel-1, pConfig.opMode,
        pConfig.cycleMode, cycleTimeUpper, cycleTimeLower, pdInNum, pdInPosOffset, 0,
        pdOutNum, pdOutPosOffset, 0, vendorIdUpper, vendorIdLower,
        deviceId3, deviceId2, deviceId1, deviceId0,
        0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,0x30,
        0x2D, pConfig.inspectionLevel,
        pConfig.dsActivationState, pConfig.dsDownloadEnable, pConfig.dsUploadEnable,0};
    
    insertCheckSum(txBuf, length);
    iol.sendMessage(txBuf);
}

void PioIoLink::sendControlStatus(uint8_t channel, bool enable){
    if(!isValidChannel(channel)){ return; }
    
    updateAllPdPosData();
    
    unsigned pdOutLen = 0;
    for(int x=0; x<4; x++){
        pdOutLen += iolObjects[x]->pdOutPosLen;
    }
    
    unsigned pdOutOffset = iolObjects[channel-1]->pdOutPosOffset;
    
    uint8_t length = 11 + pdOutLen;
    uint8_t txBuf[length];
    
    //enable/process PD out to send
    //TODO
    
    int x=0;
    txBuf[x++] = CNTSTA;
    txBuf[x++] = length;
    
    //control bytes
    while(x < 10)
    {
        if( x/(2.0*channel) == 1.0){
            if(enable){
                txBuf[x++] = 0x80;
                txBuf[x++] = 0xA8;
            }
            else{
                txBuf[x++] = 0x80;
                txBuf[x++] = 0x74;
            }
        }
        else{
            txBuf[x++] = 0;
        }
    }
    
    //clear pd out
    for(int a=0; a<pdOutOffset; a++){
        txBuf[x++] = 0;
    }
    
    //assign pd out
    //TODO
    
    //clear remaining
    while( x < length){
        txBuf[x++] = 0;
    }
    
    insertCheckSum(txBuf, length);
    iol.sendMessage(txBuf);
}

void PioIoLink::updateAllPdPosData(){
    updatePdPosData(1);
    updatePdPosData(2);
    updatePdPosData(3);
    updatePdPosData(4);
}

void PioIoLink::updatePdPosData(uint8_t channel){
    if(!isValidChannel(channel)){ return; }
    
    int pdIndex = iolObjects[channel-1]->pdIndex;
    
    //in pos
    iolObjects[channel-1]->pdInPosLen = getPdInNumOfBytes(channel);
    //in offset
    uint8_t pdInPosOffset = 0;
    for(int x=1; x<channel; x++){
        pdInPosOffset += getPdInNumOfBytes(x);
    }
    iolObjects[channel-1]->pdInPosOffset = pdInPosOffset;
    
    //out pos
    iolObjects[channel-1]->pdOutPosLen = getPdOutNumOfBytes(channel);
    //out offset
    uint8_t pdOutPosOffset = 0;
    for(int x=1; x<channel; x++){
        pdInPosOffset += getPdOutNumOfBytes(x);
    }
    iolObjects[channel-1]->pdOutPosOffset = pdOutPosOffset;
}

uint8_t PioIoLink::getPdInNumOfBytes(uint8_t channel){
    if(!isValidChannel(channel)){ return 0; }
    
    unsigned index = iolObjects[channel-1]->pdIndex;
    if(index < iolObjects[channel-1]->iodd.processDataCollection.size()){
        uint8_t temp = iolObjects[channel-1]->iodd.processDataCollection[index].processDataIn.bitLength.toInt()/8;
        return temp;
    }
    return 0;
}

uint8_t PioIoLink::getPdOutNumOfBytes(uint8_t channel){
    if(!isValidChannel(channel)){ return 0; }
    
    unsigned index = iolObjects[channel-1]->pdIndex;
    if(index < iolObjects[channel-1]->iodd.processDataCollection.size()){
        uint8_t temp = iolObjects[channel-1]->iodd.processDataCollection[index].processDataOut.bitLength.toInt()/8;
        return temp;
    }
    return 0;
}

bool PioIoLink::isValidChannel(uint8_t channel){
    if(channel<1 || channel>4){ return false; }
    else{
        return true;
    }
}

void PioIoLink::insertCheckSum(uint8_t array[], int length){
    uint8_t chkSum = getCheckSumByte(array, length);
    array[length-1] = chkSum;
}

uint8_t PioIoLink::getCheckSumByte(uint8_t array[], int length){
    uint8_t chkSum = 0;
    
    for(int x=0; x<(length-1); x++){//dont do last byte
        chkSum ^= array[x];
    }
    
    return chkSum;
}

