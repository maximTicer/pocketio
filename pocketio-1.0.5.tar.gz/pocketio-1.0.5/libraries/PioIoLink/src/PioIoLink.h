/*******************************************************************************
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All rights Reserved.
 * * This software is protected by copyright laws of the United States and
 * of foreign countries. This material may also be protected by patent laws
 * and technology transfer regulations of the United States and of foreign
 * countries. This software is furnished under a license agreement and/or a
 * nondisclosure agreement and may only be used or reproduced in accordance
 * with the terms of those agreements. Dissemination of this information to
 * any party or parties not specified in the license agreement and/or
 * nondisclosure agreement is expressly prohibited.
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated
 * Products, Inc. shall not be used except as stated in the Maxim Integrated
 * Products, Inc. Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products, Inc. retains all
 * ownership rights.
 *******************************************************************************
 */
/*
 * 
 * Created: 1 Nov 2016
 * By: Alex Ticer
 * Modified: 17 Dec 2016
 * By: Alex Ticer
 * Version: 1.0.5
 *
 ***************************************************************************/

#ifndef PIOIOLINK_H_
#define PIOIOLINK_H_

#include <Arduino.h>

class PioIoLink {
public:
	PioIoLink();
	virtual ~PioIoLink();
	
	void init();
    
    bool setChannelWithIoddFilePath(uint8_t channel, const char *filePath);
    void resetChannel(uint8_t channel);
    
    void startIoLink(uint8_t channel);
    void stopIoLink(uint8_t channel);
    
    int getTotalProcessDataIndexCount(uint8_t channel);
    bool setProcessDataIndex(uint8_t channel, int pdIndex);
    
    int getProcessDataInLen(uint8_t channel);
    bool getProcessData(uint8_t channel, uint8_t array[], int length);
    
    int getIsduByteLen(uint8_t channel, uint16_t index);
    bool readIsdu(uint8_t channel, uint16_t index, uint8_t subindex, uint8_t buffer[], uint8_t *len);
    bool writeIsdu(uint8_t channel, uint16_t index, uint8_t subindex, uint8_t buffer[], uint8_t len);
    
    void clearAll();

private:
    
    void sendResetForAllPDs();
    void sendResetForAllControls();
    
    void sendPdInterface(uint8_t channel);
    void sendPortConfig(uint8_t channel);
    void sendControlStatus(uint8_t channel, bool enable);
    
    void updateAllPdPosData();
    void updatePdPosData(uint8_t channel);
    uint8_t getPdInNumOfBytes(uint8_t channel);
    uint8_t getPdOutNumOfBytes(uint8_t channel);
    
    bool isValidChannel(uint8_t channel);
    void insertCheckSum(uint8_t array[], int length);
    uint8_t getCheckSumByte(uint8_t array[], int length);
    
    uint8_t activePdInLen;
    
    
};

#endif /* PIOIOLINK_H_ */

