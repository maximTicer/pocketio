var class_process_data_t =
[
    [ "ProcessDataT", "class_process_data_t.html#a95253417cdbe7fbcdf3beaa74bb71c37", null ],
    [ "~ProcessDataT", "class_process_data_t.html#af0a87deebbcd525dac93904a25f5156c", null ],
    [ "condition", "class_process_data_t.html#a2f59e44de05922fccc003bf1641e9001", null ],
    [ "idString", "class_process_data_t.html#ae4ee094ec8ae36e20e0bbf5ef0f8c87c", null ],
    [ "processDataIn", "class_process_data_t.html#aa9efab80842aa46e45b1276ebe7dd991", null ],
    [ "processDataOut", "class_process_data_t.html#ac84198d7097b2f10ea1087f50bd17361", null ]
];