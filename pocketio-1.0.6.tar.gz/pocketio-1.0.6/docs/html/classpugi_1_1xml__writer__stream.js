var classpugi_1_1xml__writer__stream =
[
    [ "xml_writer_stream", "classpugi_1_1xml__writer__stream.html#a259c28368c08378e15cf28b35a1dcd9a", null ],
    [ "xml_writer_stream", "classpugi_1_1xml__writer__stream.html#afa342cf0bb3a0bd6ee3d47550ad23333", null ],
    [ "write", "classpugi_1_1xml__writer__stream.html#a3ec185992d56341f6ee8d1037a6efb17", null ]
];