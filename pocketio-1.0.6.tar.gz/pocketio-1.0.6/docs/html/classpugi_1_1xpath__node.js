var classpugi_1_1xpath__node =
[
    [ "xpath_node", "classpugi_1_1xpath__node.html#a149bbfe4c145f7ebb8852ae5136ede49", null ],
    [ "xpath_node", "classpugi_1_1xpath__node.html#af35940ce58d68e3210c88c816396c158", null ],
    [ "xpath_node", "classpugi_1_1xpath__node.html#a64e77111af6283205e83b97b76d953d0", null ],
    [ "attribute", "classpugi_1_1xpath__node.html#ad3c5fe70e4293c70451abba5021a9406", null ],
    [ "node", "classpugi_1_1xpath__node.html#a5b504b06678b84eedc8467cbd39beb8f", null ],
    [ "operator unspecified_bool_type", "classpugi_1_1xpath__node.html#a6e0b138075a145e47dc00a7a17b4ba81", null ],
    [ "operator!", "classpugi_1_1xpath__node.html#a98167a5daf167fa06dff88b6c4af5646", null ],
    [ "operator!=", "classpugi_1_1xpath__node.html#a785725ca60a15a9d2df83b91725105bd", null ],
    [ "operator==", "classpugi_1_1xpath__node.html#ac41341c30e66880aad2a731203d9cf4b", null ],
    [ "parent", "classpugi_1_1xpath__node.html#a69d8000479ceddd7c6939c7258f27c39", null ]
];