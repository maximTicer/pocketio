var classpugi_1_1xpath__query =
[
    [ "xpath_query", "classpugi_1_1xpath__query.html#a6ff5db850994f40154a7373b461c61d0", null ],
    [ "xpath_query", "classpugi_1_1xpath__query.html#a4bd5c7035c03313fbac0d036b3b083f7", null ],
    [ "~xpath_query", "classpugi_1_1xpath__query.html#a430b82947a8a74f30a757940530544cf", null ],
    [ "evaluate_boolean", "classpugi_1_1xpath__query.html#a9d7c21acdc934a0b969f88f8ae3df21e", null ],
    [ "evaluate_node", "classpugi_1_1xpath__query.html#a756612fde24e703bc61fedf8ac4e84ae", null ],
    [ "evaluate_node_set", "classpugi_1_1xpath__query.html#ad5e3826c813e90c30db42f1778bc8adc", null ],
    [ "evaluate_number", "classpugi_1_1xpath__query.html#a002919f6c360cc382ce050af37039fd9", null ],
    [ "evaluate_string", "classpugi_1_1xpath__query.html#ad628e189fc4924d67acfbaeeb0f1f21f", null ],
    [ "evaluate_string", "classpugi_1_1xpath__query.html#aa20b2392867d091115cdcd9194bf8ccf", null ],
    [ "operator unspecified_bool_type", "classpugi_1_1xpath__query.html#a3e3410d6f652ada1ac9e059ebe87184c", null ],
    [ "operator!", "classpugi_1_1xpath__query.html#aaf62ebc3aa5dbce405ee1dbdd55e779a", null ],
    [ "result", "classpugi_1_1xpath__query.html#a36d9bd4c41c46ee085e7cb4af8ced7d3", null ],
    [ "return_type", "classpugi_1_1xpath__query.html#a63416a6b472bd8641facac09f3deb997", null ]
];