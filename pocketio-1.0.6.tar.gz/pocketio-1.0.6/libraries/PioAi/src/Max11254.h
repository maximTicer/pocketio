/*******************************************************************************
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated
 * Products, Inc. shall not be used except as stated in the Maxim Integrated
 * Products, Inc. Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products, Inc. retains all
 * ownership rights.
 *******************************************************************************
 */
/*
 * 
 * Created: 15 Feb 2016
 * By: Alex Ticer
 * Modified: 1 May 2016
 * By: Alex Ticer
 * Version: 1.0.6
 * Items: Syscal moved off-chip
 * By: MVS
 *
 ***************************************************************************/

#ifndef MAX11254_H_
#define MAX11254_H_

#include <stdint.h>

// Possible calibration types
//
#define CAL_TYPE_MAXPOS    (11)
#define CAL_TYPE_ZERO      (12)
#define CAL_TYPE_MAXNEG    (13)



class Max11254 {
public:
  Max11254();
  virtual ~Max11254();
	
  void init();

  uint8_t readReg8Bit(uint8_t addr);
  void writeReg8Bit(uint8_t addr, uint8_t data);
  uint16_t readReg16Bit(uint8_t addr);
  void writeReg16Bit(uint8_t addr, uint16_t data);
  uint32_t readReg24Bit(uint8_t addr);
  void writeReg24Bit(uint8_t addr, uint32_t data);

  uint8_t readIntBuffer();
  void writeIntBuffer(uint8_t buf);
	
  uint8_t readPgaGain();
  void writePgaGain(uint8_t gain);

  uint8_t readSamplingRate();

  void swBufGain(uint8_t channel);

  void startSampling(uint8_t rate);
  uint32_t readSampleRaw (uint8_t channel);
  uint32_t readSample(uint8_t channel);

  uint32_t singleConvert(uint8_t channel, uint8_t rate, bool rawFlag);

  void selfCal();
  void resetCal (uint8_t channel);
  void readCalValues();
  bool systemCal (uint8_t channel, uint8_t whichType);
  void storeSystemCalValues(uint8_t channel);
  void restoreSystemCalValues(uint8_t channel);

  void reset();
  void powerDown();

  bool isReady();


private:
  uint8_t SysCalFlagsAI0;
  uint8_t SysCalFlagsAI1;
  uint8_t SysCalFlagsAI2;
  uint8_t SysCalFlagsAI3;

  uint32_t SysCalOffsetAI0;
  uint32_t SysCalPosGainAI0;
  uint32_t SysCalOffsetAI1;
  uint32_t SysCalPosGainAI1;
  uint32_t SysCalOffsetAI2;
  uint32_t SysCalPosGainAI2;
  uint32_t SysCalNegGainAI2;
  uint32_t SysCalOffsetAI3;
  uint32_t SysCalPosGainAI3;
  uint32_t SysCalNegGainAI3;

  uint32_t readEeprom24Bit  (int addr);
  void     writeEeprom24Bit (int addr, uint32_t value);
  void     readCalValuesAI0 ();
  void     readCalValuesAI1 ();
  void     readCalValuesAI2 ();
  void     readCalValuesAI3 ();
  void     storeCalValuesAI0 ();
  void     storeCalValuesAI1 ();
  void     storeCalValuesAI2 ();
  void     storeCalValuesAI3 ();
  uint32_t performSysCal (int sample, uint32_t offset, uint32_t posGain, uint32_t negGain);

};

#endif /* MAX11254_H_ */
