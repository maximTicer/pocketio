var class_d_n_s_client =
[
    [ "begin", "class_d_n_s_client.html#aac123ed1182719dd850b3a05deafcaf0", null ],
    [ "BuildRequest", "class_d_n_s_client.html#aa48bcfd274245e3d456b7ad0d8170463", null ],
    [ "getHostByName", "class_d_n_s_client.html#ac62f5c79f85003f598223eec7fc1c22b", null ],
    [ "inet_aton", "class_d_n_s_client.html#acb77b0143a72500dcc6ec5523bceb734", null ],
    [ "ProcessResponse", "class_d_n_s_client.html#a1a03da561244297f59ae89e65ba1e0ef", null ],
    [ "iDNSServer", "class_d_n_s_client.html#ae1c134ae6c67ff2fc2e0c11e3ba1121a", null ],
    [ "iRequestId", "class_d_n_s_client.html#a20b50f5a6a4101f8b2d388a75146763d", null ],
    [ "iUdp", "class_d_n_s_client.html#a9f59dd100072ee27486be32cce299a54", null ]
];