var class_pio_spi =
[
    [ "PioSpi", "class_pio_spi.html#a5ee056515df1a05c8b3d02a694edaf20", null ],
    [ "~PioSpi", "class_pio_spi.html#af63c31fd61a4f2f9c4e0fa0d299b1ea1", null ],
    [ "configure", "class_pio_spi.html#adfcdd420aa09f0bad81f5de60d953116", null ],
    [ "init", "class_pio_spi.html#a2dd2db257b3902f05865d9529a497dee", null ],
    [ "transfer", "class_pio_spi.html#ad3f3b89fb29807b64b8a2a4311d1a415", null ]
];