var class_port_config_object =
[
    [ "PortConfigObject", "class_port_config_object.html#aecb68006190dcfbc00147d38284d1f00", null ],
    [ "~PortConfigObject", "class_port_config_object.html#a127e26f6ab6eb3ce7d6a8888b90c8f0e", null ],
    [ "cycleMode", "class_port_config_object.html#aefdef8e89f0e3f8567277ce1af0367fe", null ],
    [ "cycleTime", "class_port_config_object.html#a644d7c07e3ee7df9171ec2f6e30e7edb", null ],
    [ "dsActivationState", "class_port_config_object.html#a657b964d5e60bdc8274746a11fa3655b", null ],
    [ "dsDownloadEnable", "class_port_config_object.html#a9e6394aa8755afd9c2d0e62361ca44a6", null ],
    [ "dsUploadEnable", "class_port_config_object.html#a70aa8479d6505c2dc6a02fb7a217b5a6", null ],
    [ "inspectionLevel", "class_port_config_object.html#a4c4c6f36b4da6ca726509ae066ca6224", null ],
    [ "opMode", "class_port_config_object.html#a8010d4433cc98694b7252463f38f976d", null ],
    [ "scanMode", "class_port_config_object.html#a922da807e9af47adfcdb540f3f7f4095", null ]
];