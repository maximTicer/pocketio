var class_variable_t =
[
    [ "VariableT", "class_variable_t.html#ac02258fcea635f6c915997f05d75b214", null ],
    [ "~VariableT", "class_variable_t.html#ae9f09c437c10a337e81a4cf0fd762e7b", null ],
    [ "accessRights", "class_variable_t.html#afc513911d355041bbedb72171eb32a86", null ],
    [ "dataType", "class_variable_t.html#ad8d6389849137952b21981d5e8e71961", null ],
    [ "defaultValue", "class_variable_t.html#a0510d5f05ad47b0b67c807f16642870d", null ],
    [ "descriptionString", "class_variable_t.html#a1b4bdbed1539537b27c2d45b65a94a2c", null ],
    [ "idString", "class_variable_t.html#a7eaae8f508cb43915e6d3166b229f0e5", null ],
    [ "index", "class_variable_t.html#afaa8f1c46816a5a8b8d8a7fe3acd371f", null ],
    [ "isDataType", "class_variable_t.html#a21a4f8a9916bd9ccf44940592fc71b10", null ],
    [ "isDynamic", "class_variable_t.html#a1ae63b7f42384c58f7f496c3257bf901", null ],
    [ "name", "class_variable_t.html#a61becbb0c9678a997458684498a23b72", null ],
    [ "recordItemInfoCollection", "class_variable_t.html#a4e187f4ec0141e6d4ee7cda94fcd81d8", null ]
];