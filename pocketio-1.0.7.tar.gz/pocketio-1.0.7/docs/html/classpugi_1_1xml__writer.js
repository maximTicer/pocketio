var classpugi_1_1xml__writer =
[
    [ "~xml_writer", "classpugi_1_1xml__writer.html#a5c9b1bd029ed10862ffa4c61d24c351f", null ],
    [ "write", "classpugi_1_1xml__writer.html#ab7d3b6a8499ceef7799158370e1c2617", null ]
];