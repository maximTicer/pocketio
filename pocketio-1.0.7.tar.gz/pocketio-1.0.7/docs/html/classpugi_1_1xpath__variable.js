var classpugi_1_1xpath__variable =
[
    [ "xpath_variable", "classpugi_1_1xpath__variable.html#a209a8e2cf18a2fa4e37faddaa216dda2", null ],
    [ "xpath_variable", "classpugi_1_1xpath__variable.html#a2d805ed204c1fec482f859217d1baa4a", null ],
    [ "get_boolean", "classpugi_1_1xpath__variable.html#a2d562014ddb3c9f0a2d6b8f36f3adc36", null ],
    [ "get_node_set", "classpugi_1_1xpath__variable.html#aa82f2112e66c7745066788068a14f8f5", null ],
    [ "get_number", "classpugi_1_1xpath__variable.html#aad1197f1eecb6072794389eb997d539a", null ],
    [ "get_string", "classpugi_1_1xpath__variable.html#ab6c9175201e43003c5abcdd3bc426bbf", null ],
    [ "name", "classpugi_1_1xpath__variable.html#adfee2f69aadd5a9fd36ba67ea9f11c9c", null ],
    [ "operator=", "classpugi_1_1xpath__variable.html#a0cd0e1223e99c0baf46488cfd2079961", null ],
    [ "set", "classpugi_1_1xpath__variable.html#a1e6ee8876fba9f01373df452416e48fb", null ],
    [ "set", "classpugi_1_1xpath__variable.html#ae92b5bdaf24fa6f94f281ae5d046d56a", null ],
    [ "set", "classpugi_1_1xpath__variable.html#acaedec0610338a1165bbcd0658db34f9", null ],
    [ "set", "classpugi_1_1xpath__variable.html#aad7a9022098440aeac16ef90d849aee4", null ],
    [ "type", "classpugi_1_1xpath__variable.html#a33713853d1298ce11fb382258ffe11d4", null ],
    [ "xpath_variable_set", "classpugi_1_1xpath__variable.html#ae065e6f4380a8a530c7352703c09ff80", null ],
    [ "_next", "classpugi_1_1xpath__variable.html#a0979cb72473e77a1b6d213046abfc46e", null ],
    [ "_type", "classpugi_1_1xpath__variable.html#aefb30100ab8bf3cf2ba623dd6ffbbd35", null ]
];