var classxpath__node__set__raw =
[
    [ "xpath_node_set_raw", "classxpath__node__set__raw.html#ae849a23893eef70c01197feaf5c07544", null ],
    [ "append", "classxpath__node__set__raw.html#a0c02728de3d895a2d12df9666d60e414", null ],
    [ "begin", "classxpath__node__set__raw.html#a8d08142ac662315aa23395a44f301b66", null ],
    [ "empty", "classxpath__node__set__raw.html#affb19c256fef52cc4d34e59a9ac0c2b6", null ],
    [ "end", "classxpath__node__set__raw.html#a6be07e8a83744082cf106d4611da0164", null ],
    [ "first", "classxpath__node__set__raw.html#ac6d6a4e637df45137d7cb6c925230830", null ],
    [ "push_back", "classxpath__node__set__raw.html#a676ec123e5be874869c78ff5c43ae9c2", null ],
    [ "push_back_grow", "classxpath__node__set__raw.html#acc913a940e63a136f862e243b4b7495e", null ],
    [ "remove_duplicates", "classxpath__node__set__raw.html#af82da6fa8d42f9dff9c55e7b93d96e26", null ],
    [ "set_type", "classxpath__node__set__raw.html#ae73780271d772967f78ddd7b9376cdab", null ],
    [ "size", "classxpath__node__set__raw.html#a7121a0eb1af207606b9613747834f3bd", null ],
    [ "sort_do", "classxpath__node__set__raw.html#a5e46ee306afc24ea83f6c1181bba3600", null ],
    [ "truncate", "classxpath__node__set__raw.html#aba48d228f554065702f3e6d5059f701d", null ],
    [ "type", "classxpath__node__set__raw.html#a9c1dceb2d9a8e0747380bd12968fc9d8", null ]
];