/*******************************************************************************
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated
 * Products, Inc. shall not be used except as stated in the Maxim Integrated
 * Products, Inc. Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products, Inc. retains all
 * ownership rights.
 *******************************************************************************
 */
/*
 * 
 * Created: 15 Feb 2016
 * By: Alex Ticer
 * Modified: 6 Sep 2016
 * By: Alex Ticer
 * Version: 1.0.7
 * Modified: 7 Dec 2016
 * Items: Syscal moved off-chip
 * By: MVS
 *
 ***************************************************************************/

#include "Max11254.h"
#include <PioSpi.h>
#include "EEPROM.h"

// Available sampling rates as per data sheet
//
#define SP_1_9		0
#define SP_15_6		3
#define SP_31_2		4
#define SP_62_5		5
#define SP_250		7
#define SP_500		8
#define SP_1000		9

// GPIO connecting reset to ADC and ready
// from ADC
//
const int AI_NRST_PIN    = 31;  // Output from Edison
const int ED_AI_NRDY_PIN = 8;   // Input to Edison

// Calibration parameter storage to
// NV memory.  AI0 and AI1 are voltage
// channels, AI2, and AI3 are current channels
//
// Voltage channels have one flag byte and two
// calibration parameters, each 3 bytes long.
// Current channels have one flag byte and three
// calibration parametsrs, each 3 bytes long
//
const int SYS_CAL_FLAGS_LEN = 1;
const int SYS_CAL_PARAM_LEN = 3;

// Memory map of the actual storage
//
const int SYS_CAL_FLAGS_AI0_ADDR  = 0;
const int SYS_CAL_FLAGS_AI1_ADDR  = SYS_CAL_FLAGS_AI0_ADDR + SYS_CAL_FLAGS_LEN;
const int SYS_CAL_FLAGS_AI2_ADDR  = SYS_CAL_FLAGS_AI1_ADDR + SYS_CAL_FLAGS_LEN;
const int SYS_CAL_FLAGS_AI3_ADDR  = SYS_CAL_FLAGS_AI2_ADDR + SYS_CAL_FLAGS_LEN;

const int SYS_CAL_POSG_AI0_ADDR   = SYS_CAL_FLAGS_AI3_ADDR + SYS_CAL_FLAGS_LEN;
const int SYS_CAL_ZERO_AI0_ADDR   = SYS_CAL_POSG_AI0_ADDR  + SYS_CAL_PARAM_LEN;
const int SYS_CAL_POSG_AI1_ADDR   = SYS_CAL_ZERO_AI0_ADDR  + SYS_CAL_PARAM_LEN;
const int SYS_CAL_ZERO_AI1_ADDR   = SYS_CAL_POSG_AI1_ADDR  + SYS_CAL_PARAM_LEN;
const int SYS_CAL_POSG_AI2_ADDR   = SYS_CAL_ZERO_AI1_ADDR  + SYS_CAL_PARAM_LEN;
const int SYS_CAL_ZERO_AI2_ADDR   = SYS_CAL_POSG_AI2_ADDR  + SYS_CAL_PARAM_LEN;
const int SYS_CAL_NEGG_AI2_ADDR   = SYS_CAL_ZERO_AI2_ADDR  + SYS_CAL_PARAM_LEN;
const int SYS_CAL_POSG_AI3_ADDR   = SYS_CAL_NEGG_AI2_ADDR  + SYS_CAL_PARAM_LEN;
const int SYS_CAL_ZERO_AI3_ADDR   = SYS_CAL_POSG_AI3_ADDR  + SYS_CAL_PARAM_LEN;
const int SYS_CAL_NEGG_AI3_ADDR   = SYS_CAL_ZERO_AI3_ADDR  + SYS_CAL_PARAM_LEN;
const int SYS_CAL_END_NEXT_ADDR   = SYS_CAL_NEGG_AI3_ADDR  + SYS_CAL_PARAM_LEN;

// Bit map for the calibration flags
//
#define SYS_CAL_FLAG_MAX_BIT   (1 << 0)
#define SYS_CAL_FLAG_ZERO_BIT  (1 << 1)
#define SYS_CAL_FLAG_MIN_BIT   (1 << 2)

// Standard values in case cal is not done
//
const uint32_t SYS_CAL_VOLT_DEFAULT     = 9118051;  // old = 9115620
const uint32_t SYS_CAL_AMPS_DEFAULT_POS = 4465460;
const uint32_t SYS_CAL_AMPS_DEFAULT_NEG =  509383;

const uint8_t voltFlags = SYS_CAL_FLAG_MAX_BIT | SYS_CAL_FLAG_ZERO_BIT;
const uint8_t ampsFlags = SYS_CAL_FLAG_MAX_BIT | SYS_CAL_FLAG_MIN_BIT;
const uint8_t iExtFlags = SYS_CAL_FLAG_ZERO_BIT;




Max11254::Max11254() {
}

Max11254::~Max11254() {
}

/**
 * Always call before use.
 */
void Max11254::init(){
  pinMode(ED_AI_NRDY_PIN, INPUT);
  pinMode(AI_NRST_PIN, OUTPUT);
  digitalWrite(AI_NRST_PIN, HIGH);

  PioSpi* spi = new PioSpi();
  spi->init();
  delete spi;

  selfCal();
  readCalValues();
}


/**
 * Read 8 bit register.
 * @param addr Address for register to be read.
 * @param addr presumes address is a correct value.
 * @return 8 bit value from register.
 *
 * Format:
 *    b7    b6    b5    b4    b3    b2    b1    b0
 * +-----+-----+-----+-----+-----+-----+-----+-----+
 * |  1  |  1  | RS4 | RS3 | RS2 | RS1 | RS0 | R/W |
 * +-----+-----+-----+-----+-----+-----+-----+-----+
 *
 * RS4-RS0: Register address
 *     R/W: == 1 for read, == 0 for write
 *
 * NB: Registers have different widths, so you need
 *     to know ahead of time which reg access to use
 *
 */
uint8_t Max11254::readReg8Bit(uint8_t addr) {

  PioSpi* spi = new PioSpi();
  uint8_t messageBuffer[2] = { 0x00, 0x00 };
  uint8_t responseBuffer[2] = { 0x00, 0x00 };

  messageBuffer[0] = 0xc1 | ((addr & 0x1f) << 1);

  spi->transfer(messageBuffer, responseBuffer, 2, SPI_AI);

  delete spi;

  return responseBuffer[1];
}

/**
 * Write 8 bit register.
 * @param addr Address for register to be written.
 * @param data 8 bit value to be written to register.
 */
void Max11254::writeReg8Bit(uint8_t addr, uint8_t data) {

  PioSpi* spi = new PioSpi();
  uint8_t messageBuffer[2] = { 0x00, 0x00 };
  uint8_t responseBuffer[2] = { 0x00, 0x00 };

  messageBuffer[0] = 0xc0 | ((addr & 0x1f) << 1);
  messageBuffer[1] = data;

  spi->transfer(messageBuffer, responseBuffer, 2, SPI_AI);

  delete spi;
}

/**
 * Read 16 bit register.
 * @param addr Address for register to be read.
 * @return 16 bit value from register.
 */
uint16_t Max11254::readReg16Bit(uint8_t addr) {

  PioSpi* spi = new PioSpi();
  uint16_t response = 0;
  uint8_t messageBuffer[3] = { 0x00, 0x00, 0x00 };
  uint8_t responseBuffer[3] = { 0x00, 0x00, 0x00 };

  messageBuffer[0] = 0xc1 | ((addr&0x1f) << 1);

  spi->transfer(messageBuffer, responseBuffer, 3, SPI_AI);

  response = ( responseBuffer[1]<<8) | responseBuffer[2];

  delete spi;

  return response;
}

/**
 * Write 16 bit register.
 * @param addr Address for register to be written.
 * @param data 16 bit value to be written to register.
 */
void Max11254::writeReg16Bit(uint8_t addr, uint16_t data) {

  PioSpi* spi = new PioSpi();
  uint8_t messageBuffer[3] = { 0x00, 0x00, 0x00 };
  uint8_t responseBuffer[3] = { 0x00, 0x00, 0x00 };

  messageBuffer[0] = 0xc0 | ((addr&0x1f) << 1);
  messageBuffer[1] = data>>8;
  messageBuffer[2] = data & 0x00FF;

  spi->transfer(messageBuffer, responseBuffer, 3, SPI_AI);

  delete spi;
}

/**
 * Read 24 bit register.
 * @param addr Address for register to be read.
 * @return 24 bit value from register.
 */
uint32_t Max11254::readReg24Bit(uint8_t addr) {

  PioSpi* spi = new PioSpi();
  uint32_t response = 0;
  uint8_t messageBuffer[4] = { 0x00, 0x00, 0x00, 0x00 };
  uint8_t responseBuffer[4] = { 0x00, 0x00, 0x00, 0x00 };

  messageBuffer[0] = 0xc1 | ((addr&0x1f) << 1);

  spi->transfer(messageBuffer, responseBuffer, 4, SPI_AI);

  response = ( responseBuffer[1]<<16) | ( responseBuffer[2]<<8) | responseBuffer[3];

  delete spi;

  return response;
}

/**
 * Write 24 bit register.
 * @param addr Address for register to be written.
 * @param data 24 bit value to be written to register.
 */
void Max11254::writeReg24Bit(uint8_t addr, uint32_t data) {

  PioSpi* spi = new PioSpi();
  uint8_t messageBuffer[4] = { 0x00, 0x00, 0x00, 0x00 };
  uint8_t responseBuffer[4] = { 0x00, 0x00, 0x00, 0x00 };

  messageBuffer[0] = 0xc0 | ((addr&0x1f) << 1);
  messageBuffer[1] = data>>16;
  messageBuffer[2] = (data>>8) & 0x000000FF;
  messageBuffer[3] = data & 0x000000FF;

  spi->transfer(messageBuffer, responseBuffer, 4, SPI_AI);

  delete spi;
}

/**
 * Read internal buffer for MAX11254.
 * @return (0=no buf, 1=PGA buf, 2=PGA buf(low power mode).
 */
uint8_t Max11254::readIntBuffer() {

  uint8_t ctrl2Reg = 0x00;
  ctrl2Reg = readReg8Bit(0x02);//read CTRL2 Reg
  ctrl2Reg &= 0x18;
  ctrl2Reg = ctrl2Reg >>3;

  if( ctrl2Reg==1 ){ return 1; }//PGA buffer
  else if( ctrl2Reg==3 ){ return 2; }//PGA buffer (low power mode)
  else{ return 0; }//no internal buffer
}

/**
 * Write internal buffer for MAX11254.
 * @param (0=no buf, 1=PGA buf, 2=PGA buf(low power mode).
 */
void Max11254::writeIntBuffer(uint8_t buf) {

  uint8_t ctrl2Reg = 0x00;
  ctrl2Reg = readReg8Bit(0x02);//read CTRL2 Reg
  ctrl2Reg &= 0xE7;

  if(buf == 0){ ctrl2Reg |= 0x00; }
  else if( buf == 1){ ctrl2Reg |= 0x08; }
  else{ ctrl2Reg |= 0x18; }

  writeReg8Bit(0x02, ctrl2Reg);
}

/**
 * Read PGA gain for MAX11254.
 * @return (2^gain = x).
 * 0=gain x1,
 * 1=gain x2,
 * 2=gain x4,
 * 3=gain x8,
 * 4=gain x16,
 * 5=gain x32,
 * 6=gain x64,
 * 7=gain x128.
 */
uint8_t Max11254::readPgaGain() {

  uint8_t ctrl2Reg = 0x00;

  ctrl2Reg = readReg8Bit(0x02);
  ctrl2Reg &= 0x07;
  return ctrl2Reg;
}

/**
 * Write PGA gain for MAX11254.
 * @param (2^gain = x).
 * 0=gain x1,
 * 1=gain x2,
 * 2=gain x4,
 * 3=gain x8,
 * 4=gain x16,
 * 5=gain x32,
 * 6=gain x64,
 * 7=gain x128.
 */
void Max11254::writePgaGain(uint8_t gain) {

  uint8_t ctrl2Reg = 0x00;

  ctrl2Reg = readReg8Bit(0x02);
  ctrl2Reg &= 0xF8;
  ctrl2Reg |= gain;

  writeReg8Bit(0x02, ctrl2Reg);
}

/**
 * Read sample rate.
 * @return Byte with sample rate.
 */
uint8_t Max11254::readSamplingRate() {

  uint32_t statReg = 0x00000000;
  uint8_t rate = 0x00;

  statReg = readReg24Bit(0x00);
  statReg &= 0x000000F0;
  rate = statReg>>4;

  return rate;
}

/**
 * Set buffer gain for channel.
 * @param channel Specific channel to determine buffer gain.
 */
void Max11254::swBufGain(uint8_t channel) {

  uint8_t response = 0x00;

  // on-chip self-cal but no sys cal
  //
  response  = readReg8Bit (0x03);
  response &= 0xfc;
  response |= 0x0c;
  writeReg8Bit (0x03, response);

  // sequencer mode 1, select channel
  //
  response  = readReg8Bit (0x08);
  response &= 0x07;
  response |= (channel << 5);
  writeReg8Bit (0x08, response);

  // set to bipolar conversion
  //
  response  = readReg8Bit (0x01);
  response &= 0xf7;
  writeReg8Bit (0x01, response);

  // For voltage channels
  //
  if(channel==0 || channel==1 ){

    // Need no gain or buffering
    //
    writeIntBuffer(0);//no internal buffer
  }
  // For current channels
  //
  else if(channel==2 || channel==3){

    // current, use gain of 4
    //
    writeIntBuffer(2);//select PGA buffers
    writePgaGain(2);//2^2=4
  }
}

/**
 * Start sampling ADC.
 * @param rate Set sampling rate for ADC.
 *
 *    b7    b6    b5    b4    b3    b2    b1    b0
 * +-----+-----+-----+-----+-----+-----+-----+-----+
 * |  1  |  0  | MD1 | MD0 | RT3 | RT2 | RT1 | RT0 |
 * +-----+-----+-----+-----+-----+-----+-----+-----+
 *
 *  MD1-0: command mode
 *  RT3-0: conversion rate
 *
 */
void Max11254::startSampling(uint8_t rate) {

  uint8_t message = 0x00;
  PioSpi* spi = new PioSpi();

  // Mode = 0b11 starts a conversion
  //
  message = 0xB0 | rate;

  spi->transfer(&message, 0, 1, SPI_AI);

  delete spi;
}


// 24-bit ADC, bipolar, using offfset-binary format
//
const uint32_t offsetADC = 8388608;    // 2^23

/**
 * Helper routine for readSample, does actual sys cal correction
 * @param sample the value to correct
 * @param Offset offset value
 * @param Gain gain value
 * @return corrected value
 *
 * Presumes ADC supplies bipolar, offset-binary format
 */
uint32_t
Max11254::performSysCal (int sample, uint32_t offset, uint32_t posGain, uint32_t negGain)
{
  uint32_t noOffset;
  uint64_t corrected64;   // NB - 48-bit arithmetic
  uint32_t corrected;
  uint32_t result;

  if (sample < offset)
  {
    noOffset = offset - sample;
    corrected64 = (uint64_t) negGain * noOffset;
    corrected   = (corrected64 + (1<<22)) >> 23;   // rounding

    // clamp to limits
    //
    if (corrected < offsetADC)
    {
      result = offsetADC - corrected;
    }
    else
    {
      result = 0;
    }
  }
  else      // (sample >= limit)
  {
    noOffset = sample - offset;
    corrected64 = (uint64_t) posGain * noOffset;
    corrected = (corrected64 + (1<<22)) >> 23;
    if (corrected < offsetADC)
    {
      result = offsetADC + corrected;
    }
    else
    {
      result = offsetADC + offsetADC - 1;
    }
  }
  return result;
}

/**
 * Read sample for specific channel without correction
 * @param channel Select ADC channel to read sample
 * @return ADC smaple without correction
 */
uint32_t Max11254::readSampleRaw (uint8_t channel)
{
  switch (channel)
  {
    case 0:
      return readReg24Bit (0x0E);
      break;

    case 1:
      return readReg24Bit (0x0F);
      break;

    case 2:
      return readReg24Bit (0x10);
      break;

    case 3:
      return readReg24Bit (0x11);
      break;
  }
}

/**
 * Read sample for specific channel.
 * @param channel Select ADC channel to read sample.
 * @return ADC sample for selected channel.
 */
uint32_t Max11254::readSample(uint8_t channel)
{
       int sample;
  uint32_t result;

  switch (channel)
  {
    case 0:
      sample  = readReg24Bit (0x0E);
      result = performSysCal (sample, SysCalOffsetAI0, SysCalPosGainAI0, SysCalPosGainAI0);
      break;

    case 1:
      sample = readReg24Bit (0x0F);
      result = performSysCal (sample, SysCalOffsetAI1, SysCalPosGainAI1, SysCalPosGainAI1);
      break;

    case 2:
      sample = readReg24Bit (0x10);
      if ((SysCalFlagsAI2 & iExtFlags) == iExtFlags)
      {
        result = performSysCal (sample, SysCalOffsetAI2, SysCalPosGainAI2, SysCalNegGainAI2);
      }
      else
      {
        result = performSysCal (sample, SysCalNegGainAI2, SysCalPosGainAI2, SysCalPosGainAI2);
        if (result > offsetADC)
        {
          result = (result + result) - offsetADC - offsetADC;
        }
        else
        {
          result = 0;
        }
      }
      break;

    case 3:
      sample = readReg24Bit (0x11);
      if ((SysCalFlagsAI3 & iExtFlags) == iExtFlags)
      {
        result = performSysCal (sample, SysCalOffsetAI3, SysCalPosGainAI3, SysCalNegGainAI3);
      }
      else
      {
        result = performSysCal (sample, SysCalNegGainAI3, SysCalPosGainAI3, SysCalPosGainAI3);
        if (result > offsetADC)
        {
          result = (result + result) - offsetADC - offsetADC;
        }
        else
        {
          result = 0;
        }
      }
      break;

    default:
      sample = offsetADC;   // near zero
      break;
  }
  return result;
}

/**
 * Perform single sample conversion for ADC.
 * @param channel Set ADC channel.
 * @param rate Set rate for selected channel.
 * @return ADC sample for selected channel.
 */
uint32_t Max11254::singleConvert(uint8_t channel, uint8_t rate, bool rawFlag) {

  uint8_t message = 0x00;
  uint8_t response = 0x00;
  uint32_t timeoutCounter = 0;
  uint32_t timeoutLimit = 100000;

  response = readReg8Bit(0x01); // read CTRL1 Reg
  response &= 0xFC;             // single conversion
  response &= 0xF7;             // bipolar input range
  response |= 0x04;             // offset binary
  response |= 0x02;             // single cycle mode
  writeReg8Bit(0x01, response);

  response = readReg8Bit(0x08); // read sequencer Reg
  response &= 0x07;             // SEQ mode 1 (single channel)
  if(channel == 0){ response |= 0x00; }
  else if(channel == 1){ response |= 0x20; }
  else if(channel == 2){ response |= 0x40; }
  else if(channel == 3){ response |= 0x60; }
  writeReg8Bit(0x08, response);

  startSampling(rate);          //start conversion at rate

  // wait for result - note 
  //
  while( !isReady() && timeoutCounter<timeoutLimit)
  {
    timeoutCounter++;
  }

  if(timeoutCounter == timeoutLimit)
  {
    return 0;
  }

  if (rawFlag)
  {
    return readSampleRaw (channel);
  }
  else
  {
    return readSample(channel);
  }
}

/**
 * Perform self calibration.
 */
void Max11254::selfCal() {

  uint8_t message = 0x00;
  uint8_t response = 0x00;

  // Set for self-cal
  //
  response = readReg8Bit(0x01);
  response &= 0x3F;
  writeReg8Bit(0x01, response);

  // Must be SEQ mode 1
  //
  response = readReg8Bit(0x08);
  response &= 0xE7;
  writeReg8Bit(0x08, response);

  // Send start calibration command by
  // setting mode = 0b10
  //
  PioSpi* spi = new PioSpi();
  message = 0xA0;
  spi->transfer(&message, 0, 1, SPI_AI);
  delete spi;

  sleep(0.5);//500ms
}


/*
 * Helper function - read 24-bit values from EEPROM
 * @param addr - EEPROM address of first byte
 * @return the 24-bit value stored there
 */
uint32_t Max11254::readEeprom24Bit (int addr)
{
  uint32_t value;

  value  = EEPROM.read(addr    ) << 16;
  value |= EEPROM.read(addr + 1) <<  8;
  value |= EEPROM.read(addr + 2)      ;

  return value;
}


/*
 * Helper function - write 24-bit values to EEPROM
 * @param addr - EEPROM address of first byte
 * @value the 8 bits to write
 */
void Max11254::writeEeprom24Bit (int addr, uint32_t value)
{
  uint8_t data;

  data = (value >> 16) & 0xff;
  EEPROM.write (addr,     data);
  data = (value >>  8) & 0xff;
  EEPROM.write (addr + 1, data);
  data = (value      ) & 0xff;
  EEPROM.write (addr + 2, data);
}

/*
 * Remove system cal for a given channel
 *
 * @param channel which channel to reset cal on
 *
 * Follow with a call to storeSystemCalValues to
 * make this reset permanent
 */
void Max11254::resetCal (uint8_t channel)
{
  switch (channel)
  {
    case 0:
      SysCalFlagsAI0 = 0b000;
      SysCalPosGainAI0 = SYS_CAL_VOLT_DEFAULT;
      SysCalOffsetAI0  = offsetADC;
      break;

    case 1:
      SysCalFlagsAI1 = 0b000;
      SysCalPosGainAI1 = SYS_CAL_VOLT_DEFAULT;
      SysCalOffsetAI1  = offsetADC;
      break;

    case 2:
      SysCalFlagsAI2 = 0b000;
      SysCalPosGainAI2 = SYS_CAL_AMPS_DEFAULT_POS;
      SysCalNegGainAI2 = SYS_CAL_AMPS_DEFAULT_NEG;
      SysCalOffsetAI2  = offsetADC;
      break;

    case 3:
      SysCalFlagsAI3 = 0b000;
      SysCalPosGainAI3 = SYS_CAL_AMPS_DEFAULT_POS;
      SysCalNegGainAI3 = SYS_CAL_AMPS_DEFAULT_NEG;
      SysCalOffsetAI3  = offsetADC;
      break;
  }
}
/*
 * Helper routines for loading cal values
 */
void Max11254::readCalValuesAI0()
{
  // Convert only if there is both a maximum and a zero
  //
  SysCalFlagsAI0 = EEPROM.read (SYS_CAL_FLAGS_AI0_ADDR);
  if ((SysCalFlagsAI0 & voltFlags) == voltFlags)
  {
    SysCalPosGainAI0 = readEeprom24Bit (SYS_CAL_POSG_AI0_ADDR);
    SysCalOffsetAI0  = readEeprom24Bit (SYS_CAL_ZERO_AI0_ADDR);
  }
  else
  {
    SysCalPosGainAI0 = SYS_CAL_VOLT_DEFAULT;
    SysCalOffsetAI0  = offsetADC;
  }
}

void Max11254::readCalValuesAI1 ()
{
  SysCalFlagsAI1 = EEPROM.read (SYS_CAL_FLAGS_AI1_ADDR);
  if ((SysCalFlagsAI1 & voltFlags) == voltFlags)
  {
    SysCalPosGainAI1 = readEeprom24Bit (SYS_CAL_POSG_AI1_ADDR);
    SysCalOffsetAI1  = readEeprom24Bit (SYS_CAL_ZERO_AI1_ADDR);
  }
  else
  {
    SysCalPosGainAI1 = SYS_CAL_VOLT_DEFAULT;
    SysCalOffsetAI1  = offsetADC;
  }
}

void Max11254::readCalValuesAI2 ()
{
  // Convert if you have a max and a min, and optionally
  // a zero
  //
  SysCalFlagsAI2 = EEPROM.read (SYS_CAL_FLAGS_AI2_ADDR);
  if ((SysCalFlagsAI2 & ampsFlags) == ampsFlags)
  {
    SysCalPosGainAI2 = readEeprom24Bit (SYS_CAL_POSG_AI2_ADDR);
    SysCalNegGainAI2 = readEeprom24Bit (SYS_CAL_NEGG_AI2_ADDR);
  }
  else
  {
    SysCalPosGainAI2 = SYS_CAL_AMPS_DEFAULT_POS;
    SysCalNegGainAI2 = SYS_CAL_AMPS_DEFAULT_NEG;
  }
  if ((SysCalFlagsAI2 & iExtFlags) == iExtFlags)
  {
    SysCalOffsetAI2 = readEeprom24Bit (SYS_CAL_ZERO_AI2_ADDR);
  }
  else
  {
    SysCalOffsetAI2 = offsetADC;
  }
}

void Max11254::readCalValuesAI3 ()
{
  SysCalFlagsAI3 = EEPROM.read (SYS_CAL_FLAGS_AI3_ADDR);
  if ((SysCalFlagsAI3 & ampsFlags) == ampsFlags)
  {
    SysCalPosGainAI3 = readEeprom24Bit (SYS_CAL_POSG_AI3_ADDR);
    SysCalNegGainAI3 = readEeprom24Bit (SYS_CAL_NEGG_AI3_ADDR);
  }
  else
  {
    SysCalPosGainAI3 = SYS_CAL_AMPS_DEFAULT_POS;
    SysCalNegGainAI3 = SYS_CAL_AMPS_DEFAULT_NEG;
  }
  if ((SysCalFlagsAI3 & iExtFlags) == iExtFlags)
  {
    SysCalOffsetAI3 = readEeprom24Bit (SYS_CAL_ZERO_AI3_ADDR);
  }
  else
  {
    SysCalOffsetAI3 = offsetADC;
  }
}


void Max11254::storeCalValuesAI0()
{
  EEPROM.write (SYS_CAL_FLAGS_AI0_ADDR, SysCalFlagsAI0);
  if ((SysCalFlagsAI0 & voltFlags) != voltFlags)
  {
    SysCalPosGainAI0 = SYS_CAL_VOLT_DEFAULT;
    SysCalOffsetAI0  = offsetADC;
  }
  writeEeprom24Bit (SYS_CAL_POSG_AI0_ADDR, SysCalPosGainAI0);
  writeEeprom24Bit (SYS_CAL_ZERO_AI0_ADDR, SysCalOffsetAI0);
}

void Max11254::storeCalValuesAI1 ()
{
  EEPROM.write (SYS_CAL_FLAGS_AI1_ADDR, SysCalFlagsAI1);
  if ((SysCalFlagsAI1 & voltFlags) != voltFlags)
  {
    SysCalPosGainAI1 = SYS_CAL_VOLT_DEFAULT;
    SysCalOffsetAI1  = offsetADC;
  }
  writeEeprom24Bit (SYS_CAL_POSG_AI1_ADDR, SysCalPosGainAI1);
  writeEeprom24Bit (SYS_CAL_ZERO_AI1_ADDR, SysCalOffsetAI1);
}

void Max11254::storeCalValuesAI2 ()
{
  EEPROM.write (SYS_CAL_FLAGS_AI2_ADDR, SysCalFlagsAI2);
  if ((SysCalFlagsAI2 & ampsFlags) != ampsFlags)
  {
    SysCalPosGainAI2 = SYS_CAL_AMPS_DEFAULT_POS;
    SysCalNegGainAI2 = SYS_CAL_AMPS_DEFAULT_NEG;
    SysCalOffsetAI2  = offsetADC;
  }
  writeEeprom24Bit (SYS_CAL_POSG_AI2_ADDR, SysCalPosGainAI2);
  writeEeprom24Bit (SYS_CAL_NEGG_AI2_ADDR, SysCalNegGainAI2);
  writeEeprom24Bit (SYS_CAL_ZERO_AI2_ADDR, SysCalOffsetAI2);
}

void Max11254::storeCalValuesAI3 ()
{
  EEPROM.write (SYS_CAL_FLAGS_AI3_ADDR, SysCalFlagsAI3);
  if ((SysCalFlagsAI3 & ampsFlags) != ampsFlags)
  {
    SysCalPosGainAI3 = SYS_CAL_AMPS_DEFAULT_POS;
    SysCalNegGainAI3 = SYS_CAL_AMPS_DEFAULT_NEG;
    SysCalOffsetAI3  = offsetADC;
  }
  writeEeprom24Bit (SYS_CAL_POSG_AI3_ADDR, SysCalPosGainAI3);
  writeEeprom24Bit (SYS_CAL_NEGG_AI3_ADDR, SysCalNegGainAI3);
  writeEeprom24Bit (SYS_CAL_ZERO_AI3_ADDR, SysCalOffsetAI3);
}



/*
 * Load calibration values into object local storage
 * (avoids EEPROM reads for every conversion)
 *
 * This code presumes MAX11254 bipolar conversion in
 * offset binary format
 *
 * For voltage channels, we measure max positive and
 * zero, converting to a gain and offset
 *
 * For current channels, we measure max positive and
 * max negative, converting to a gain and offset, but
 * if a zero current is alos measured, we then have an
 * offset, a postive gain, and a negative gain
 */
void Max11254::readCalValues ()
{
  readCalValuesAI0 ();
  readCalValuesAI1 ();
  readCalValuesAI2 ();
  readCalValuesAI3 ();
}


/**
 * Perform one system cal and store it
 * @param channel which channel
 * @param whichType max, zero, or min
 * @return false if wrong type for that channel
 *
 * For voltage cal, do the zero cal first, followed
 * by the max positive cal
 *
 * For current cal, if doing extended cal, do the zero cal
 * followed by the max negative cal, finally do the max
 * positive cal; otherwise do the max negative cal first
 * followed by the max positive cal
 *
 * This code presumes bipolar and offset-binary
 */
bool Max11254::systemCal (uint8_t channel, uint8_t whichType)
{
             int i;
        uint32_t value;
  const uint64_t numerator = (uint64_t) 0x7fffff * 0x7fffff * 2;
        uint64_t gain64;

  // parameter checking - voltage has no
  // negative calibration step
  //
  if ((channel == 0) || (channel == 1))
  {
    if (whichType == CAL_TYPE_MAXNEG)
    {
      return false;
    }
  }

  powerDown();
  swBufGain (channel);

  // Prime ADC
  //
  for (i = 0; i < 20; i++)
  {
    singleConvert (channel, SP_1_9, true);
  }

  // Do some averaging
  //
  value = 0;
  for (i = 0; i < 16; i++)
  {
    value += singleConvert (channel, SP_1_9, true);
  }
  value = (value + 0b1000) >> 4;  // for rounding
  powerDown();

  // Now figure out what to do with it
  //
  // NB: This cal should come first
  //
  if (whichType == CAL_TYPE_ZERO)
  {
    switch (channel)
    {
      case 0:
        SysCalOffsetAI0 = value;
        SysCalFlagsAI0 |= SYS_CAL_FLAG_ZERO_BIT;
        break;

      case 1:
        SysCalOffsetAI1 = value;
        SysCalFlagsAI1 |= SYS_CAL_FLAG_ZERO_BIT;
        break;

      case 2:
        SysCalOffsetAI2 = value;
        SysCalFlagsAI2 |= SYS_CAL_FLAG_ZERO_BIT;
        break;

      case 3:
        SysCalOffsetAI3 = value;
        SysCalFlagsAI3 |= SYS_CAL_FLAG_ZERO_BIT;
        break;
    }
  }
  // for current cal only
  // comes first for normal current cal
  // comes second after zero for extended cal
  //
  else if (whichType == CAL_TYPE_MAXNEG)
  {
    switch (channel)
    {
      case 2:
        if ((SysCalFlagsAI2 & SYS_CAL_FLAG_ZERO_BIT) == SYS_CAL_FLAG_ZERO_BIT)
        {
          // extended cal
          //
          value = SysCalOffsetAI2 - value;
          gain64 = numerator / value;
          SysCalNegGainAI2 = gain64 + 1;   // for rounding
          SysCalNegGainAI2 >>= 1;
        }
        else
        {
          // normal cal
          //
          SysCalNegGainAI2 = value;
        }
        SysCalFlagsAI2 |= SYS_CAL_FLAG_MIN_BIT;
        break;

      case 3:
        if ((SysCalFlagsAI3 & SYS_CAL_FLAG_ZERO_BIT) == SYS_CAL_FLAG_ZERO_BIT)
        {
          // extended cal
          //
          value = SysCalOffsetAI3 - value;
          gain64 = numerator / value;
          SysCalNegGainAI3 = gain64 + 1;   // for rounding
          SysCalNegGainAI3 >>= 1;
        }
        else
        {
          // normal cal
          //
          SysCalNegGainAI3 = value;
        }
        SysCalFlagsAI3 |= SYS_CAL_FLAG_MIN_BIT;
        break;
    }
  }
  else if (whichType == CAL_TYPE_MAXPOS)
  {
    switch (channel)
    {
      case 0:
        value -= SysCalOffsetAI0;
        gain64 = numerator / value;
        SysCalPosGainAI0 = gain64 + 1;   // for rounding
        SysCalPosGainAI0 >>= 1;
        SysCalFlagsAI0 |= SYS_CAL_FLAG_MAX_BIT;
        break;

      case 1:
        value -= SysCalOffsetAI1;
        gain64 = numerator / value;
        SysCalPosGainAI1 = gain64 + 1;
        SysCalPosGainAI1 >>= 1;
        SysCalFlagsAI1 |= SYS_CAL_FLAG_MAX_BIT;
        break;

      case 2:
        if ((SysCalFlagsAI2 & SYS_CAL_FLAG_ZERO_BIT) == SYS_CAL_FLAG_ZERO_BIT)
        {
          value -= SysCalOffsetAI2;
        }
        else
        {
          value -= SysCalNegGainAI2;
        }
        gain64 = numerator / value;
        SysCalPosGainAI2 = gain64 + 1;
        SysCalPosGainAI2 >>= 1;
        SysCalFlagsAI2 |= SYS_CAL_FLAG_MAX_BIT;
        break;

      case 3:
        if ((SysCalFlagsAI3 & SYS_CAL_FLAG_ZERO_BIT) == SYS_CAL_FLAG_ZERO_BIT)
        {
          value -= SysCalOffsetAI3;
        }
        else
        {
          value -= SysCalNegGainAI3;
        }
        gain64 = numerator / value;
        SysCalPosGainAI3 = gain64 + 1;
        SysCalPosGainAI3 >>= 1;
        SysCalFlagsAI3 |= SYS_CAL_FLAG_MAX_BIT;
        break;
    }
  }

  return true;
}



/**
 * Store system calibration values for selected channel.
 * @param channel Selected ADC channel.
 */
void Max11254::storeSystemCalValues(uint8_t channel)
{
  switch (channel)
  {
    case 0:
      storeCalValuesAI0 ();
      break;

    case 1:
      storeCalValuesAI1 ();
      break;

    case 2:
      storeCalValuesAI2 ();
      break;

    case 3:
      storeCalValuesAI3 ();
      break;
  }
}

/**
 * Restore system calibration values for selected channel.
 * @param channel Selected ADC channel.
 */
void Max11254::restoreSystemCalValues(uint8_t channel)
{
  switch (channel)
  {
    case 0:
      readCalValuesAI0 ();
      break;

    case 1:
      readCalValuesAI1 ();
      break;

    case 2:
      readCalValuesAI3 ();
      break;

    case 3:
      readCalValuesAI3 ();
      break;
  }

}

/**
 * Reset MAX11254
 */
void Max11254::reset() {
	
  digitalWrite(AI_NRST_PIN, LOW);
  sleep(0.5);
  digitalWrite(AI_NRST_PIN, HIGH);
}

/**
 * Powerdown MAX11254
 */
void Max11254::powerDown() {

  uint8_t response = 0x00;
  uint8_t message = 0x00;

  response = readReg8Bit(0x01);//CTRL 1 Reg
  response &= 0xCF;
  // Modified by Wei
  //
  response |= /*(0x10<<4)*/ 0x20;
  writeReg8Bit(0x01, response);

  PioSpi* spi = new PioSpi();

  message = 0x90;//power down command
  spi->transfer(&message, 0, 1, SPI_AI);
	
  delete spi;
}

/**
 * Check if ADC reading is ready.
 * @return Boolean if ADC NRDY pin is low.
 */
bool Max11254::isReady() {

  if(digitalRead(ED_AI_NRDY_PIN) == 0){ return true; }//active low
  else{ return false; }//not ready
}


