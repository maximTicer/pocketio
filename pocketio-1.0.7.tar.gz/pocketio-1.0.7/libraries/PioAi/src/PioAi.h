/*******************************************************************************
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated
 * Products, Inc. shall not be used except as stated in the Maxim Integrated
 * Products, Inc. Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products, Inc. retains all
 * ownership rights.
 *******************************************************************************
 */
/*
 * 
 * Created: 15 Feb 2016
 * By: Alex Ticer
 * Modified: 14 Sep 2016
 * By: Alex Ticer
 * Version: 1.0.7
 * Modified: 7 Dec 2016
 * Items: Syscal moved off-chip
 * By: MVS
 *
 ***************************************************************************/

#ifndef PIOAI_H_
#define PIOAI_H_

#include <stdint.h>
// Possible calibration types
//
#define CAL_TYPE_MAXPOS    (11)
#define CAL_TYPE_ZERO      (12)
#define CAL_TYPE_MAXNEG    (13)


#define AI0			0
#define AI1			1
#define AI2			2
#define AI3			3

#define AI_RATE_1_9_SPS			0
#define AI_RATE_15_6_SPS		3
#define AI_RSTE_31_2_SPS		4
#define AI_RATE_62_5_SPS		5
#define AI_RATE_250_SPS			7
#define AI_RATE_500_SPS			8
#define AI_RATE_1000_SPS		9


class PioAi {
public:
	PioAi();
	virtual ~PioAi();
	
	void init();
	
	void initCal(uint8_t channel);
	void setFullCal(uint8_t channel);
	void setZeroCal(uint8_t channel);
	void storeCal(uint8_t channel);
	void restoreCal(uint8_t channel);
     void resetCal (uint8_t channel);
     bool systemCal (uint8_t channel, uint8_t whichType);

	uint32_t readCode(uint8_t channel, uint8_t rate);
	
	float readFloat(uint8_t channel, uint8_t rate);
};

#endif /* PIOAI_H_ */
