/*******************************************************************************
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated
 * Products, Inc. shall not be used except as stated in the Maxim Integrated
 * Products, Inc. Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products, Inc. retains all
 * ownership rights.
 *******************************************************************************
 */
/*
 * 
 * Created: 15 Feb 2016
 * By: Alex Ticer
 * Modified: 30 Apr 2016
 * By: Alex Ticer
 * Version: 1.0.7
 *
 ***************************************************************************/
#include "PioEdLed.h"

PioEdLed::PioEdLed(){
}

PioEdLed::~PioEdLed() {
}

/**
 * Always call before use.
 */
void PioEdLed::init()
{
	pinMode(9, OUTPUT);
	pinMode(11, OUTPUT);
}

/**
 * Write value to selected Edison LED.
 * @param led Selected Edison LED (GREEN or RED).
 * @param value Value to set selected Edison LED (0=low, 1=high).
 */
void PioEdLed::writeLed(uint8_t led, uint8_t value)
{
	if(value){ value=1; }
	else{
		value=0;
	}
	
	if(led==GREEN){
		digitalWrite(9, value);
	}
	else if(led==RED){
		digitalWrite(11, value);
	}
}
