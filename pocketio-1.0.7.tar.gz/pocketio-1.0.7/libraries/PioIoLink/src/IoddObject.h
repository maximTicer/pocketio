/*******************************************************************************
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All rights Reserved.
 * * This software is protected by copyright laws of the United States and
 * of foreign countries. This material may also be protected by patent laws
 * and technology transfer regulations of the United States and of foreign
 * countries. This software is furnished under a license agreement and/or a
 * nondisclosure agreement and may only be used or reproduced in accordance
 * with the terms of those agreements. Dissemination of this information to
 * any party or parties not specified in the license agreement and/or
 * nondisclosure agreement is expressly prohibited.
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated
 * Products, Inc. shall not be used except as stated in the Maxim Integrated
 * Products, Inc. Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products, Inc. retains all
 * ownership rights.
 *******************************************************************************
 */
/*
 *
 * Created: 14 Oct 2016
 * By: Alex Ticer
 * Modified: 17 Dec 2016
 * By: Alex Ticer
 * Version: 1.0.7
 *
 ***************************************************************************/

#ifndef IoddObject_H_
#define IoddObject_H_

#include <Arduino.h>
#include "pugixml.h"
#include <map>
#include <vector>
#include <strstream>

#include "DataTypes/DataTypes.h"
#include "DataTypes/StdVariableRef.h"
#include "DataTypes/VariableT.h"
#include "DataTypes/ProcessDataT.h"

struct DeviceVariant{
    String productId;
    String hardwareRevision;
    String firmwareRevision;
    String deviceSymbol;
    String deviceIcon;
    String productName;
    String productText;
};

struct DeviceIdentity{
    String vendorId;
    String vendorName;
    String deviceId;
    String vendorText;
    String vendorUrl;
    String vendorLogo;
    String deviceFamily;
    
    unsigned deviceVarantIndex = 0;
    
    std::vector<DeviceVariant> deviceVariantCollection;
};

struct CommNetwork{
    String bitrate = "0";
    String physics = "0";
    String minCycleTime = "0";
    String isSioSupported = "false";
    String ioLinkRevision = "";
};

class IoddObject{
public:
    IoddObject();
    virtual ~IoddObject();
    
    void init();
    
    bool setIoddFilePath(const char *filePath);
    
    //Document Info
    String docVersion;
    String docReleaseDate;
    String docCopyright;
    
    //Profile Header
    String profileId;
    String profileRevision;
    String profileName;
    String profileSource;
    String profileClassId;
    
    //ISO15745 Reference
    String iso15745Part;
    String iso15745Edition;
    String profileTechnology;
    
    //Text Collections
    String primaryLanguage;
    std::map<String,String> textCollection;
    
    //CRC
    unsigned long crc;
    String crcCheckerName;
    String crcCheckerVersion;
    
    //Device Identity
    DeviceIdentity deviceIdentity;
    
    //Features
    bool isBlockParameter;
    bool isDataStorage;
    
    //Datatype Collections
    std::map<String, DataType> dataTypeCollection;
    
    //Variable Collections
    std::vector<VariableT> stdVariableCollection;
    std::map<String, StdVariableRef> stdVariableRefCollection;
    std::vector<VariableT> stdDirectParameterRefCollection;
    std::vector<VariableT> variableCollection;
    
    //ProcessData Collection
    std::vector<ProcessDataT> processDataCollection;
    
    //Comm Network
    CommNetwork network;
    
    //ISDU Collection
    std::map<int, VariableT> isduVariableCollection;
    
private:
    
    void enableMSRead();
    void disableMSRead();
    
    bool parse();
    SimpleDataType parseSimpleDataType(pugi::xml_node node);
    ArrayT parseArrayT(pugi::xml_node node);
    RecordT parseRecordT(pugi::xml_node node);
    DataType parseDataType(pugi::xml_node node);
    
    pugi::xml_document doc;
    pugi::xml_document stdDef;
    String file;
    bool isSet;
    
    
};

#endif

