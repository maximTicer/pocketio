var classxpath__allocator =
[
    [ "xpath_allocator", "classxpath__allocator.html#a3b8ba1722fba115d05949d8f592080e8", null ],
    [ "allocate", "classxpath__allocator.html#aad95aa445f2fdc7c3d1c19b1f3d67cb1", null ],
    [ "allocate_nothrow", "classxpath__allocator.html#aa66f3703548657eca5316392a2d79d00", null ],
    [ "reallocate", "classxpath__allocator.html#a4dd502389202ec8e7420832112a571e5", null ],
    [ "release", "classxpath__allocator.html#a9436b8bdef3e0e0ff0df28c2af6a430d", null ],
    [ "revert", "classxpath__allocator.html#af1c3ec117935d4488bbd16adf807fbc1", null ],
    [ "error_handler", "classxpath__allocator.html#a84222db6b26b0016e9ce2cdd4a36e7a7", null ]
];