var classxpath__string =
[
    [ "xpath_string", "classxpath__string.html#a6c415f55011c6b816446d7454d1e9d2c", null ],
    [ "append", "classxpath__string.html#aab0d867c56d390213cf0fbe7334e1cc0", null ],
    [ "c_str", "classxpath__string.html#a0c5d08cda063f380e065f87041d20b39", null ],
    [ "data", "classxpath__string.html#ade42a938746bcba171b70bfb88c3c568", null ],
    [ "empty", "classxpath__string.html#a2a4f1988a700e20405c0f2c23d4e08a9", null ],
    [ "length", "classxpath__string.html#a1238d6fdad0766a21965cfeb668f5a5b", null ],
    [ "operator!=", "classxpath__string.html#afca32de44459a6805b90c517d5d5ab75", null ],
    [ "operator==", "classxpath__string.html#a42fc30d8b2434d89e724436f99458abd", null ],
    [ "uses_heap", "classxpath__string.html#ac8cab48475690223df758e5ab2368533", null ]
];