/*******************************************************************************
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated
 * Products, Inc. shall not be used except as stated in the Maxim Integrated
 * Products, Inc. Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products, Inc. retains all
 * ownership rights.
 *******************************************************************************
 */
/*
 * 
 * Created: 24 Aug 2016
 * By: Alex Ticer
 * Modified: 6 Sep 2016
 * By: Alex Ticer
 * Version: 1.0.8
 *
 ***************************************************************************/

#include "Pio.h"
#include <PioSpi.h>
#include <stdio.h>

const uint8_t ENP_CMD = 0x18;

const uint8_t READ_FW = 0x50;
const uint8_t READ_SERIAL = 0x51;
const uint8_t READ_NAME = 0x52;

const uint32_t SPI_MAXBUFFERSIZE = 32;//32

const uint32_t IOL_SPI_SPEED = 1125000;

Pio::Pio() {
}

Pio::~Pio() {
}

/**
 * Always call before use.
 */
void Pio::init(){
    PioSpi* spi = new PioSpi();
    spi->init();
    delete spi;
}

/**
 * Read IO-Link STM firmware version.
 * @param fwBuf[] Char buffer to hold firmware version string (>=6 chars).
 */
void Pio::readIolFW(char fwBuf[]){

	uint8_t txBuf[SPI_MAXBUFFERSIZE];
	uint8_t rxBuf[SPI_MAXBUFFERSIZE];
	uint8_t response = 0;
	
	txBuf[0] = READ_FW;

	PioSpi* pioSpi = new PioSpi();
	
	pioSpi->transfer(txBuf, NULL, SPI_MAXBUFFERSIZE, SPI_IOL);
	
	pioSpi->transfer(txBuf, rxBuf, SPI_MAXBUFFERSIZE, SPI_IOL);
	
	delete pioSpi;
	
	//may want to confirm command byte
	fwBuf[0] = rxBuf[1];
	fwBuf[1] = rxBuf[2];
	fwBuf[2] = rxBuf[3];
	fwBuf[3] = rxBuf[4];
	fwBuf[4] = rxBuf[5];
	fwBuf[5] = rxBuf[6];
	
	return;
}

/**
 * Read motor STM firmware version.
 * @param fwBuf[] Char buffer to hold firmware version string (>=6 chars).
 */
void Pio::readMtrFW(char fwBuf[]){

	uint8_t txBuf[SPI_MAXBUFFERSIZE];
	uint8_t rxBuf[SPI_MAXBUFFERSIZE];
	uint8_t response = 0;
	
	txBuf[0] = ENP_CMD;
	txBuf[1] = READ_FW;

	PioSpi* pioSpi = new PioSpi();
	
	pioSpi->transfer(txBuf, NULL, SPI_MAXBUFFERSIZE, SPI_ENP);
	
	pioSpi->transfer(txBuf, rxBuf, SPI_MAXBUFFERSIZE, SPI_ENP);
	
	delete pioSpi;
	
	//may want to confirm command byte
	fwBuf[0] = rxBuf[1];
	fwBuf[1] = rxBuf[2];
	fwBuf[2] = rxBuf[3];
	fwBuf[3] = rxBuf[4];
	fwBuf[4] = rxBuf[5];
	fwBuf[5] = rxBuf[6];
	
	return;
}
/**
 * Read Pocket IO serial number, 96 bits long.
 * @param serialBuf[] Char buffer to store 24 digit hex string (>=26 chars).
 */
void Pio::readBoardSerial(char serialBuf[]){

	uint8_t txBuf[SPI_MAXBUFFERSIZE];
	uint8_t rxBuf[SPI_MAXBUFFERSIZE];
	uint32_t response = 0;
	
	uint32_t uid[3] = {0,0,0};
	
	txBuf[0] = ENP_CMD;
	txBuf[1] = READ_SERIAL;

	PioSpi* pioSpi = new PioSpi();
	
	pioSpi->transfer(txBuf, NULL, SPI_MAXBUFFERSIZE, SPI_ENP);
	
	pioSpi->transfer(txBuf, rxBuf, SPI_MAXBUFFERSIZE, SPI_ENP);
	
	delete pioSpi;
	
	response = rxBuf[1];
	uid[0] |= response;
	response = rxBuf[2];
	uid[0] |= (response<<8);
	response = rxBuf[3];
	uid[0] |= (response<<16);
	response = rxBuf[4];
	uid[0] |= (response<<24);
	
	response = rxBuf[5];
	uid[1] |= response;
	response = rxBuf[6];
	uid[1] |= (response<<8);
	response = rxBuf[7];
	uid[1] |= (response<<16);
	response = rxBuf[8];
	uid[1] |= (response<<24);
	
	response = rxBuf[9];
	uid[2] |= response;
	response = rxBuf[10];
	uid[2] |= (response<<8);
	response = rxBuf[11];
	uid[2] |= (response<<16);
	response = rxBuf[12];
	uid[2] |= (response<<24);
	
	sprintf(serialBuf, "%08X-%08X-%08X", uid[2], uid[1], uid[0]);
	
	return;
}

/**
 * Read board name.
 * @param nameBuf[] Char buffer to store board name string (>=10 chars).
 */
void Pio::readBoardName(char nameBuf[]){

	uint8_t txBuf[SPI_MAXBUFFERSIZE];
	uint8_t rxBuf[SPI_MAXBUFFERSIZE];
	uint8_t response = 0;
	
	txBuf[0] = ENP_CMD;
	txBuf[1] = READ_NAME;

	PioSpi* pioSpi = new PioSpi();
	
	pioSpi->transfer(txBuf, NULL, SPI_MAXBUFFERSIZE, SPI_ENP);
	
	pioSpi->transfer(txBuf, rxBuf, SPI_MAXBUFFERSIZE, SPI_ENP);
	
	delete pioSpi;
	
	//may want to confirm command byte
	nameBuf[0] = rxBuf[1];
	nameBuf[1] = rxBuf[2];
	nameBuf[2] = rxBuf[3];
	nameBuf[3] = rxBuf[4];
	nameBuf[4] = rxBuf[5];
	nameBuf[5] = rxBuf[6];
	nameBuf[6] = rxBuf[7];
	nameBuf[7] = rxBuf[8];
	nameBuf[8] = rxBuf[9];
	nameBuf[9] = rxBuf[10];
	
	return;
}


