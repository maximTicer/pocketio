/*******************************************************************************
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated
 * Products, Inc. shall not be used except as stated in the Maxim Integrated
 * Products, Inc. Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products, Inc. retains all
 * ownership rights.
 *******************************************************************************
 */
/*
 * 
 * Created: 15 Feb 2016
 * By: Alex Ticer
 * Modified: 14 Sep 2016
 * By: Alex Ticer
 * Version: 1.0.8
 * Modified: 7 Dec 2016
 * Items: Syscal moved off-chip
 * By: MVS
 *
 ***************************************************************************/

#include "PioAi.h"
#include "Max11254.h"
#include "EEPROM.h"

#include <stdio.h>

static Max11254* max11254;

PioAi::PioAi() {
}

PioAi::~PioAi() {
	
  delete max11254;
  max11254 = NULL;
}

/**
 * Always call before use.
 */
void PioAi::init(){
	
  max11254 = new Max11254();
	
  max11254->init();

  // Wei addition - force reset
  max11254->reset();

  //CTRL1 setup
  max11254->writeReg8Bit(0x01, 0x06);
  //CTRL2 setup
  max11254->writeReg8Bit(0x02, 0x20);
  //CTRL3 setup
  max11254->writeReg8Bit(0x03, 0x0C);
  //SEQ setup
  max11254->writeReg8Bit(0x08, 0x01);

  //self cal
  max11254->selfCal();
}

/**
 * Always call before calibration.
 */
void PioAi::initCal(uint8_t channel){
    
  max11254->selfCal();
		
  max11254->swBufGain(channel);
}

/**
 * Set full calibration for selected channel.
 * @param channel Selected AI channel (0-3).
 */
void PioAi::setFullCal(uint8_t channel)
{
  max11254->systemCal(channel, (uint8_t) CAL_TYPE_MAXPOS);
}

/**
 * Set zero calibration for selected channel.
 * @param channel Selected AI channel (0-3).
 */
void PioAi::setZeroCal(uint8_t channel)
{
  switch (channel)
  {
    case 0:
    case 1:
      max11254->systemCal (channel, CAL_TYPE_ZERO);
      break;

    case 2:
    case 3:
      max11254->systemCal (channel, CAL_TYPE_MAXNEG);
      break;
  }
}

/**
 * Store calibration values for selected channel.
 * @param channel Selected AI channel (0-3).
 */
void PioAi::storeCal(uint8_t channel){

  max11254->storeSystemCalValues(channel);
}

/**
 * Restore calibration values for selected channel.
 * @param channel Selected AI channel (0-3).
 */
void PioAi::restoreCal(uint8_t channel){
	
  max11254->restoreSystemCalValues(channel);
}

/**
 * Reset system cal values ot defaults
 * @param channel Selected AI channel (0-3)
 */
void PioAi::resetCal (uint8_t channel)
{
  max11254->resetCal (channel);
}

/**
 * Generalized system cal, allows for use of 
 * extended current cal
 * @param channel selected AI channel (0-3)
 * @param whichType cal type
 * @return true if legal, false if illegal combo
 *
 * whichType can be one of CAL_TYPE_MAXPOS,
 * CAL_TYPE_ZERO, or CAL_TYPE_MAXNEG
 *
 * returns false if asking for MAXNEG cal for
 * a voltage channel
 */
bool PioAi::systemCal (uint8_t channel, uint8_t whichType)
{
  max11254->systemCal (channel, whichType);
}

/**
 * Read code for selected AI channel.
 * @param channel Selected AI channel (0-3).
 * @param rate Rate for ADC conversion.
 * @return ADC code value (0-16777215).
 */
uint32_t PioAi::readCode(uint8_t channel, uint8_t rate) {

  max11254->swBufGain(channel);

  return max11254->singleConvert(channel, rate, false);
}

/**
 * Converts AI code value to float for selected AI channel.
 * @param channel Selected Ai channel (0-3).
 * @param rate Rate for ADC conversion.
 * @return ADC float value (-12.0 to +12.0).
 */
float PioAi::readFloat(uint8_t channel, uint8_t rate){
	
  uint32_t code  = 0;
  float    value = 0.0;
	
  max11254->swBufGain(channel);
	
  code = max11254->singleConvert(channel, rate, false);

  switch (channel)
  {
    case 0:
    case 1:
      value = (float) (code / 16777215.0) * 24.0 - 12.0;
      break;

    case 2:
    case 3:
      value = (float) (code / 16777215.0) * 0.048 - 0.024;
      break;
  }
  return value;
}

