/*******************************************************************************
 * Copyright (C) 2016 Maxim Integrated Products, Inc., All rights Reserved.
 * * This software is protected by copyright laws of the United States and
 * of foreign countries. This material may also be protected by patent laws
 * and technology transfer regulations of the United States and of foreign
 * countries. This software is furnished under a license agreement and/or a
 * nondisclosure agreement and may only be used or reproduced in accordance
 * with the terms of those agreements. Dissemination of this information to
 * any party or parties not specified in the license agreement and/or
 * nondisclosure agreement is expressly prohibited.
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL MAXIM INTEGRATED BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
 * Except as contained in this notice, the name of Maxim Integrated
 * Products, Inc. shall not be used except as stated in the Maxim Integrated
 * Products, Inc. Branding Policy.
 *
 * The mere transfer of this software does not imply any licenses
 * of trade secrets, proprietary technology, copyrights, patents,
 * trademarks, maskwork rights, or any other form of intellectual
 * property whatsoever. Maxim Integrated Products, Inc. retains all
 * ownership rights.
 *******************************************************************************
 */
/*
 *
 * Created: 14 Oct 2016
 * By: Alex Ticer
 * Modified: 17 Dec 2016
 * By: Alex Ticer
 * Version: 1.0.8
 *
 ***************************************************************************/

#include "IoddObject.h"
#include "IoddStdDefs.h"

//Public

IoddObject::IoddObject() {
}

IoddObject::~IoddObject() {
}

void IoddObject::init(){
    
    system("mkdir /flash");
}

bool IoddObject::setIoddFilePath(const char *filePath){
    
    const char *root = "/flash";
    
    size_t rootLen = strlen(root);
    size_t fileLen = strlen(filePath);
    char *tempPath = (char*)malloc(rootLen + fileLen + 1);
    
    memcpy(tempPath, root, rootLen);
    memcpy(tempPath + rootLen, filePath, fileLen );
    tempPath[rootLen+fileLen] = '\0';
    
    const char *newFilePath = tempPath;
    
    enableMSRead();
    
    pugi::xml_parse_result result = doc.load_file(newFilePath);
    
    disableMSRead();
    
    if(result){//no errors
        
        isSet = true;
        
        //store
        file = String(newFilePath);
        
        parse();
        
    }
    else{//error
        isSet = false;
    }
    
    return result;
}

//Private


void IoddObject::enableMSRead(){
    system("mkdir /flash");
    system("mount -o offset=8192 /dev/mmcblk0p9 /flash");
}

void IoddObject::disableMSRead(){
    system("umount /flash");
}

bool IoddObject::parse(){
    
    if(!doc.empty()){
        ////////Document Info
        pugi::xml_node docInfoNode = doc.select_node("//*[local-name() = 'DocumentInfo']").node();
        
        docVersion = docInfoNode.attribute("version").value();
        docReleaseDate = docInfoNode.attribute("releaseDate").value();
        docCopyright = docInfoNode.attribute("copyright").value();
        
        ////////Profile Header
        pugi::xml_node profileheaderNode = doc.select_node("//*[local-name() = 'ProfileHeader']").node();
        
        profileId = profileheaderNode.child_value("ProfileIdentification");
        profileRevision = profileheaderNode.child_value("ProfileRevision");
        profileName = profileheaderNode.child_value("ProfileName");
        profileSource = profileheaderNode.child_value("ProfileSource");
        profileClassId = profileheaderNode.child_value("ProfileClassID");
        
        //ISO15745 Reference
        iso15745Part = profileheaderNode.child("ISO15745Reference").child_value("ISO15745Part");
        iso15745Edition = profileheaderNode.child("ISO15745Reference").child_value("ISO15745Edition");
        
        profileTechnology = profileheaderNode.child("ISO15745Reference").child_value("ProfileTechnology");
        
        if(profileRevision == "1.1"){
            
            size_t size = sizeof(IODD_STD_DEF_SOURCE_1_1);
            pugi::xml_parse_result result = stdDef.load_buffer(IODD_STD_DEF_SOURCE_1_1, size);
            
            if(!result){ return false; }
        }
        else{
            size_t size = sizeof(IODD_STD_DEF_SOURCE_1);
            pugi::xml_parse_result result = stdDef.load_buffer(IODD_STD_DEF_SOURCE_1, size);
            
            if(!result){ return false; }
        }
        
        ////////Text Collections
        //For now only doing primary lang and only if en
        pugi::xml_node primaryLanguageNode = doc.select_node("//*[local-name() = 'PrimaryLanguage']").node();
        
        primaryLanguage = primaryLanguageNode.attribute("lang").value();
        
        //Add text from primary lang only
        for( pugi::xml_node text = primaryLanguageNode.first_child(); text; text = text.next_sibling()){
            
            pugi::xml_attribute val = text.attribute("value");
            pugi::xml_attribute id = text.attribute("id");
            
            textCollection.insert( std::pair<String,String>(id.value(),val.value()));
        }
        
        //Add text from std def
        pugi::xml_node stdPrimaryLanguageNode = stdDef.select_node("//*[local-name() = 'PrimaryLanguage']").node();
        //Add text from primary lang only
        for( pugi::xml_node text = stdPrimaryLanguageNode.first_child(); text; text = text.next_sibling()){
            
            pugi::xml_attribute val = text.attribute("value");
            pugi::xml_attribute id = text.attribute("id");
            
            textCollection.insert( std::pair<String,String>(id.value(),val.value()));
        }
        
        ////////CRC Stamp
        pugi::xml_node stampNode = doc.select_node("//*[local-name() = 'Stamp']").node();
        
        std::strstream ss;
        ss << stampNode.attribute("crc").value();
        ss >> crc;
        crcCheckerName = stampNode.child("Checker").attribute("name").value();
        crcCheckerVersion = stampNode.child("Checker").attribute("version").value();
        
        ////////Device Identity
        pugi::xml_node deviceIdNode = doc.select_node("//*[local-name() = 'DeviceIdentity']").node();
        
        deviceIdentity.vendorId = deviceIdNode.attribute("vendorId").value();
        deviceIdentity.vendorName = deviceIdNode.attribute("vendorName").value();
        deviceIdentity.deviceId = deviceIdNode.attribute("deviceId").value();
        deviceIdentity.vendorText = deviceIdNode.child("VendorText").attribute("textId").value();
        deviceIdentity.vendorUrl = deviceIdNode.child("VendorUrl").attribute("textId").value();
        deviceIdentity.vendorLogo = deviceIdNode.child("VendorLogo").attribute("name").value();
        deviceIdentity.deviceFamily = deviceIdNode.child("DeviceFamily").attribute("textId").value();
        
        //Device Variant Collections
        for( pugi::xml_node variantNode = deviceIdNode.child("DeviceVariantCollection").first_child(); variantNode; variantNode = variantNode.next_sibling()){
            
            DeviceVariant tempVariant;
            
            tempVariant.productId = variantNode.attribute("productId").value();
            tempVariant.hardwareRevision = variantNode.attribute("hardwareRevision").value();
            tempVariant.firmwareRevision = variantNode.attribute("firmwareRevision").value();
            tempVariant.deviceSymbol = variantNode.attribute("deviceSymbol").value();
            tempVariant.deviceIcon = variantNode.attribute("deviceIcon").value();
            
            if(profileRevision == "1.1")
            {
                tempVariant.productName = variantNode.child("Name").attribute("textId").value();
                tempVariant.productText = variantNode.child("Description").attribute("textId").value();
            }
            else
            {
                tempVariant.productName = variantNode.child("ProductName").attribute("textId").value();
                tempVariant.productText = variantNode.child("ProductText").attribute("textId").value();
            }
            
            deviceIdentity.deviceVariantCollection.push_back(tempVariant);
        }
        
        /////Features
        pugi::xml_node featuresNode = doc.select_node("//*[local-name() = 'DeviceFunction']").node().child("Features");
        
        std::strstream ssFeatures;
        ssFeatures << featuresNode.attribute("blockParameter").value();
        ssFeatures >> std::boolalpha >> isBlockParameter;
        ssFeatures << featuresNode.attribute("dataStorage").value();
        ssFeatures >> std::boolalpha >> isDataStorage;
        
        ////////Datatype Collections
        pugi::xml_node dataTypeCollectionNode = doc.select_node("//*[local-name() = 'DatatypeCollection']").node();
        for( pugi::xml_node dataTypeNode = dataTypeCollectionNode.child("DataType"); dataTypeNode; dataTypeNode = dataTypeNode.next_sibling("DataType")){
            
            DataType dataType = parseDataType(dataTypeNode);
            if(dataType.hasType()){
                String key = dataTypeNode.attribute("id").value();
                dataTypeCollection.insert(std::pair<String, DataType>(key, dataType));
            }
        }
        //Now for std def
        pugi::xml_node stdDataTypeCollectionNode = stdDef.select_node("//*[local-name() = 'DatatypeCollection']").node();
        for( pugi::xml_node dataTypeNode = stdDataTypeCollectionNode.child("DataType"); dataTypeNode; dataTypeNode = dataTypeNode.next_sibling("DataType")){
            
            DataType dataType = parseDataType(dataTypeNode);
            if(dataType.hasType()){
                String key = dataTypeNode.attribute("id").value();
                dataTypeCollection.insert(std::pair<String, DataType>(key, dataType));
            }
        }
        
        ////////Variable Collections
        
        ////Std Variable Collection
        
        //Now std variable, from stdDef
        pugi::xml_node stdVariableCollectionNode = stdDef.select_node("//*[local-name() = 'VariableCollection']").node();
        for( pugi::xml_node varNode = stdVariableCollectionNode.child("Variable"); varNode; varNode = varNode.next_sibling("Variable")){
            
            VariableT var;
            var.idString = varNode.attribute("id").value();
            var.index = varNode.attribute("index").value();
            var.accessRights = varNode.attribute("accessRights").value();
            var.defaultValue = varNode.attribute("defaultValue").value();
            var.isDynamic = varNode.attribute("isDynamic").value();
            var.name = varNode.child("Name").attribute("textId").value();
            var.descriptionString = varNode.child("Description").attribute("textId").value();
            
            //Can only be one either Datatype or DatatypeRef
            pugi::xml_node typeNode = varNode.child("Datatype");
            if(typeNode){
                var.isDataType = "true";
                var.dataType = parseDataType(typeNode);
            }
            else{
                pugi::xml_node typeRefNode = varNode.child("DatatypeRef");
                if(typeRefNode){
                    var.isDataType = "true";
                    
                    String idString = typeRefNode.attribute("datatypeId").value();
                    var.dataType = dataTypeCollection[idString];
                }
            }
            
            //now iterate over all RecordItemInfo, can be many
            for( pugi::xml_node infoNode = varNode.child("RecordItemInfo"); infoNode; infoNode = infoNode.next_sibling("RecordItemInfo")){
                
                RecordItemInfoT recordItemInfo;
                recordItemInfo.subindex = infoNode.attribute("subindex").value();
                recordItemInfo.defaultValue = infoNode.attribute("defaultValue").value();
                
                var.recordItemInfoCollection.push_back(recordItemInfo);
            }
            
            stdVariableCollection.push_back(var);
        }
        
        //subset, now std variable ref, from doc
        pugi::xml_node stdVariableRefCollectionNode = doc.select_node("//*[local-name() = 'VariableCollection']").node();
        for( pugi::xml_node varNode = stdVariableRefCollectionNode.child("StdVariableRef"); varNode; varNode = varNode.next_sibling("StdVariableRef")){
            
            StdVariableRef stdVarRef;
            stdVarRef.idString = varNode.attribute("id").value();
            stdVarRef.defaultValue = varNode.attribute("defaultValue").value();
            stdVarRef.fixedLengthRestriction = varNode.attribute("isDynamic").value();
            
            //now iterate over all , can be many
            for( pugi::xml_node node = varNode.child("StdSingleValueRef"); node; node = node.next_sibling("StdSingleValueRef")){
                
                ValueT val;
                val.value = node.attribute("value").value();
                stdVarRef.valueCollection.push_back(val);
            }
            //now iterate over all , can be many
            for( pugi::xml_node node = varNode.child("SingleValue"); node; node = node.next_sibling("SingleValue")){
                
                ValueT val;
                val.value = node.attribute("value").value();
                val.name = node.child("Name").attribute("textId").value();
                stdVarRef.valueCollection.push_back(val);
            }
            //now iterate over all , can be many
            for( pugi::xml_node node = varNode.child("StdValueRangeRef"); node; node = node.next_sibling("StdValueRangeRef")){
                
                ValueRangeT range;
                range.upperValue = node.attribute("upperValue").value();
                range.lowerValue = node.attribute("lowerValue").value();
                stdVarRef.rangeCollection.push_back(range);
            }
            //now iterate over all , can be many
            for( pugi::xml_node node = varNode.child("ValueRange"); node; node = node.next_sibling("ValueRange")){
                
                ValueRangeT range;
                range.upperValue = node.attribute("upperValue").value();
                range.lowerValue = node.attribute("lowerValue").value();
                range.name = node.child("Name").attribute("textId").value();
                stdVarRef.rangeCollection.push_back(range);
            }
            
            //now collect StdRecordItemRef, only one?
            pugi::xml_node recordItemRefNode = varNode.child("StdRecordItemRef");
            
            stdVarRef.stdRecordItemRef.subindex = recordItemRefNode.attribute("subindex").value();
            
            //now collect all StdDataItemRef within each StdRecordItemRef, can be many
            for( pugi::xml_node node = recordItemRefNode.child("StdDataItemRef"); node; node = node.next_sibling("StdDataItemRef")){
                
                StdDataItemRef dataItem;
                dataItem.stdSingleValueRef.value = node.child("StdSingleValueRef").attribute("value").value();
                
                dataItem.stdValueRangeRef.upperValue = node.child("StdValueRangeRef").attribute("upperValue").value();
                dataItem.stdValueRangeRef.lowerValue = node.child("StdValueRangeRef").attribute("lowerValue").value();
                
                dataItem.singleValue.name = node.child("SingleValue").child("Name").attribute("textId").value();
                dataItem.singleValue.value = node.child("SingleValue").attribute("value").value();
                
                dataItem.valueRange.name = node.child("ValueRange").child("Name").attribute("textId").value();
                dataItem.valueRange.upperValue = node.child("ValueRange").attribute("upperValue").value();
                dataItem.valueRange.lowerValue = node.child("ValueRange").attribute("lowerValue").value();
                
                stdVarRef.stdRecordItemRef.stdDataItemRefCollection.push_back(dataItem);
            }
            
            
            stdVariableRefCollection.insert(std::pair<String,StdVariableRef>(stdVarRef.idString, stdVarRef));
        }
        
        ////Std Direct Parameter Ref Collection
        pugi::xml_node stdParameterRefCollectionNode = doc.select_node("//*[local-name() = 'VariableCollection']").node();
        for( pugi::xml_node varNode = stdParameterRefCollectionNode.child("StdDirectParameterRef"); varNode; varNode = varNode.next_sibling("StdDirectParameterRef")){
            
            VariableT var;
            var.idString = varNode.attribute("id").value();
            var.accessRights = varNode.attribute("accessRights").value();
            var.defaultValue = varNode.attribute("defaultValue").value();
            var.isDynamic = varNode.attribute("dynamic").value();
            var.name = varNode.child("Name").attribute("textId").value();
            var.descriptionString = varNode.child("Description").attribute("textId").value();
            
            pugi::xml_node typeNode = varNode.child("Datatype");
            if(typeNode){
                //means a data type
                DataType d = parseDataType(typeNode);
                if(d.hasType()){
                    var.isDataType = "true";
                    var.dataType = d;
                }
            }
            else{
                //means no data type, then must be datatype ref
                pugi::xml_node typeRefNode = varNode.child("DatatypeRef");
                if(typeRefNode){
                    var.isDataType = "true";
                    String idString = typeRefNode.attribute("datatypeId").value();
                    var.dataType = dataTypeCollection[idString];
                }
            }
            
            //now iterate to collect all RecordItemInfoT, there can be many
            //dont have an example of this yet
            for( pugi::xml_node node = varNode.child("RecordItemInfo"); node; node = node.next_sibling("RecordItemInfo")){
                
                RecordItemInfoT info;
                info.subindex = node.attribute("subindex").value();
                info.defaultValue = node.attribute("defaultValue").value();
                
                var.recordItemInfoCollection.push_back(info);
            }
            
            stdDirectParameterRefCollection.push_back(var);
        }
        
        ////Varible Collection
        
        //Now variable, from doc
        pugi::xml_node variableCollectionNode = doc.select_node("//*[local-name() = 'VariableCollection']").node();
        for( pugi::xml_node varNode = variableCollectionNode.child("Variable"); varNode; varNode = varNode.next_sibling("Variable")){
            
            VariableT var;
            var.idString = varNode.attribute("id").value();
            var.index = varNode.attribute("index").value();
            var.accessRights = varNode.attribute("accessRights").value();
            var.defaultValue = varNode.attribute("defaultValue").value();
            var.isDynamic = varNode.attribute("isDynamic").value();
            var.name = varNode.child("Name").attribute("textId").value();
            var.descriptionString = varNode.child("Description").attribute("textId").value();
            
            //Can only be one either Datatype or DatatypeRef
            pugi::xml_node typeNode = varNode.child("Datatype");
            if(typeNode){
                var.isDataType = "true";
                var.dataType = parseDataType(typeNode);
            }
            else{
                pugi::xml_node typeRefNode = varNode.child("DatatypeRef");
                if(typeRefNode){
                    var.isDataType = "true";
                    
                    String idString = typeRefNode.attribute("datatypeId").value();
                    var.dataType = dataTypeCollection[idString];
                }
            }
            
            //now iterate over all RecordItemInfo, can be many
            for( pugi::xml_node infoNode = varNode.child("RecordItemInfo"); infoNode; infoNode = infoNode.next_sibling("RecordItemInfo")){
                
                RecordItemInfoT recordItemInfo;
                recordItemInfo.subindex = infoNode.attribute("subindex").value();
                recordItemInfo.defaultValue = infoNode.attribute("defaultValue").value();
                
                var.recordItemInfoCollection.push_back(recordItemInfo);
            }
            
            variableCollection.push_back(var);
        }
        
        ////////Process Data Collection
        pugi::xml_node processDataCollectionNode = doc.select_node("//*[local-name() = 'ProcessDataCollection']").node();
        for( pugi::xml_node pDataNode = processDataCollectionNode.child("ProcessData"); pDataNode; pDataNode = pDataNode.next_sibling("ProcessData")){
            
            ProcessDataT pData;
            pData.idString = pDataNode.attribute("id").value();
            
            
            
            //Can only be one condition
            pugi::xml_node cNode = pDataNode.child("Condition");
            if(cNode){
                pData.condition.variableId = cNode.attribute("variableId").value();
                pData.condition.value = cNode.attribute("value").value();
                pData.condition.subindex = cNode.attribute("subindex").value();
            }
            
            //Now get Process Data In, only one
            pugi::xml_node pInNode = pDataNode.child("ProcessDataIn");
            if(pInNode){
                pData.processDataIn.idString = pInNode.attribute("id").value();
                pData.processDataIn.bitLength = pInNode.attribute("bitLength").value();
                pData.processDataIn.name = pInNode.child("Name").attribute("textId").value();
                
                //Get Data type or reg, only one
                pugi::xml_node typeNode = pInNode.child("Datatype");
                if(typeNode){
                    //means a data type
                    DataType d = parseDataType(typeNode);
                    if(d.hasType()){
                        
                        pData.processDataIn.isDataType = "true";
                        pData.processDataIn.dataType = d;
                    }
                }
                else{
                    //means no data type, then must be datatype ref
                    pugi::xml_node typeRefNode = pInNode.child("DatatypeRef");
                    if(typeRefNode){
                        pData.processDataIn.isDataType = "true";
                        String idString = typeRefNode.attribute("datatypeId").value();
                        pData.processDataIn.dataType = dataTypeCollection[idString];
                    }
                }
            }
            
            //Now get Process Data Out, only one
            pugi::xml_node pOutNode = pDataNode.child("ProcessDataOut");
            if(pOutNode){
                pData.processDataOut.idString = pOutNode.attribute("id").value();
                pData.processDataOut.bitLength = pOutNode.attribute("bitLength").value();
                pData.processDataOut.name = pOutNode.child("Name").attribute("textId").value();
                
                //Get Data type or reg, only one
                pugi::xml_node typeNode = pOutNode.child("Datatype");
                if(typeNode){
                    //means a data type
                    DataType d = parseDataType(typeNode);
                    if(d.hasType()){
                        pData.processDataOut.isDataType = "true";
                        pData.processDataOut.dataType = d;
                    }
                }
                else{
                    //means no data type, then must be datatype ref
                    pugi::xml_node typeRefNode = pOutNode.child("DatatypeRef");
                    if(typeRefNode){
                        pData.processDataOut.isDataType = "true";
                        String idString = typeRefNode.attribute("datatypeId").value();
                        pData.processDataOut.dataType = dataTypeCollection[idString];
                    }
                }
            }
            
            //Now add to collection
            processDataCollection.push_back(pData);
        }
        
        ////////Comm Network
        pugi::xml_node networkNode = doc.select_node("//*[local-name() = 'CommNetworkProfile']").node();
        
        network.ioLinkRevision = networkNode.attribute("iolinkRevision").value();
        pugi::xml_node phyNode = networkNode.child("TransportLayers");
        if(phyNode){
            if(profileRevision == "1.1"){
                network.bitrate = phyNode.attribute("bitrate").value();
            }
            else{
                network.bitrate = phyNode.attribute("baudrate").value();
            }
            
            network.minCycleTime = phyNode.attribute("minCycleTime").value();
            network.isSioSupported = phyNode.attribute("sioSupported").value();
            network.physics = phyNode.attribute("physics").value();
        }
        
        ////////Construct isduVariable Collection
        
        for(int x=0; x < stdVariableCollection.size(); x++){//16
            VariableT tempVarT = stdVariableCollection[x];
            String keyString = tempVarT.idString;
            
            //Check if keyString exists in std variable ref collection
            std::map<String, StdVariableRef>::iterator stdVarRefIt;
            stdVarRefIt = stdVariableRefCollection.find(keyString);
            if( stdVarRefIt != stdVariableRefCollection.end()){
                //It exists, so ok
                StdVariableRef tempStdVarRef = stdVariableRefCollection[keyString];
                
                if(tempStdVarRef.valueCollection.size() == 0){
                    //no value collection, take copy, BUT add defautValue
                    tempVarT.defaultValue = tempStdVarRef.defaultValue;//ok if not set
                    
                    isduVariableCollection.insert(std::pair<int,VariableT>(tempVarT.index.toInt(), tempVarT));
                }
                else{
                    //very much hardcoded for now
                    //probably system command
                    //TODO
                    
                    //First remove those that should not be included
                    if(tempVarT.dataType.isSimple){//check if simple
                        if(tempVarT.dataType.simpleDataType.dataTypeString == "UIntegerT"){
                            
                            SimpleDataType tempSimple = tempVarT.dataType.simpleDataType;
                            
                            //Again very specific to system command
                            for(int y=tempSimple.values.size()-1; y >=0; y--){
                                
                                ValueT tempValue = tempSimple.values[y];
                                
                                bool isMatchFound = false;
                                
                                for(int z=0; z < tempStdVarRef.valueCollection.size(); z++){
                                    ValueT tempStdValue = tempStdVarRef.valueCollection[z];
                                    if(tempStdValue.value == tempValue.value){
                                        isMatchFound = true;
                                    }
                                }
                                
                                if(!isMatchFound){
                                    stdVariableCollection[x].dataType.simpleDataType.values.erase(stdVariableCollection[x].dataType.simpleDataType.values.begin()+y);
                                }
                            }
                            
                            for(int a=0; a< tempStdVarRef.valueCollection.size(); a++){
                                stdVariableCollection[x].dataType.simpleDataType.values.push_back(tempStdVarRef.valueCollection[a]);
                            }
                            
                            isduVariableCollection.insert(std::pair<int,VariableT>(stdVariableCollection[x].index.toInt(), stdVariableCollection[x]));
                        }
                    }
                }
            }
        }
        
        //At this point the stdVariableRef collection has been processed
        //now time to include the rest of the variables
        for(int x=0; x < variableCollection.size(); x++){
            isduVariableCollection.insert(std::pair<int,VariableT>(variableCollection[x].index.toInt(), variableCollection[x]));
        }
        //isduVariableCollection should be complete
        
    }
}

DataType IoddObject::parseDataType(pugi::xml_node node)
{
    DataType dataType;
    if(!node){ return dataType; }
    
    SimpleDataType simpleDataType = parseSimpleDataType(node);
    //first check if simple data type
    if(simpleDataType.dataTypeString != "")
    {
        dataType.isSimple = true;
        dataType.simpleDataType = simpleDataType;
        return dataType;
    }
    //if not,
    //now check for complex data type
    ArrayT arrayT = parseArrayT(node);
    if(arrayT.dataTypeString != "")
    {
        dataType.isArray = true;
        dataType.arrayT = arrayT;
        return dataType;
    }
    
    RecordT recordT = parseRecordT(node);
    if(recordT.dataTypeString != "")
    {
        dataType.isRecord = true;
        dataType.recordT = recordT;
        return dataType;
    }
    
    return dataType;
}

SimpleDataType IoddObject::parseSimpleDataType(pugi::xml_node node){
    SimpleDataType simpleDataType = SimpleDataType();
    
    if(!node){ return simpleDataType; }
    
    String dataTypeString = node.attribute("xsi:type").value();
    
    //common
    simpleDataType.dataTypeString = dataTypeString;
    simpleDataType.name = node.child("Name").attribute("textId").value();
    simpleDataType.idString = node.attribute("id").value();
    
    
    if(dataTypeString == "OctetStringT"){
        simpleDataType.fixedLength = node.attribute("fixedLength").value();
    }
    else if( dataTypeString == "StringT"){
        simpleDataType.fixedLength = node.attribute("fixedLength").value();
        simpleDataType.encoding = node.attribute("encoding").value();
    }
    else if( dataTypeString == "TimeT"){
        //nothing to add
    }
    else if( dataTypeString == "TimeSpanT"){
        //nothing to add
    }
    else if( dataTypeString == "BooleanT"){
        for( pugi::xml_node singleValue = node.child("SingleValue"); singleValue; singleValue = singleValue.next_sibling("SingleValue")){
            
            ValueT value;
            value.name = singleValue.child("Name").attribute("textId").value();
            value.value = singleValue.attribute("value").value();
            
            simpleDataType.values.push_back(value);
        }
    }
    else if( dataTypeString == "UIntegerT" || dataTypeString == "IntegerT" || dataTypeString == "Float32T"){
        simpleDataType.bitLength = node.attribute("bitLength").value();
        
        for( pugi::xml_node singleValue = node.child("SingleValue"); singleValue; singleValue = singleValue.next_sibling("SingleValue")){
            
            ValueT value;
            value.name = singleValue.child("Name").attribute("textId").value();
            value.value = singleValue.attribute("value").value();
            
            simpleDataType.values.push_back(value);
        }
        
        for( pugi::xml_node valueRange = node.child("ValueRange"); valueRange; valueRange = valueRange.next_sibling("ValueRange")){
            
            ValueRangeT range;
            range.name = valueRange.child("Name").attribute("textId").value();
            range.upperValue = valueRange.attribute("upperValue").value();
            range.lowerValue = valueRange.attribute("lowerValue").value();
            
            simpleDataType.ranges.push_back(range);
        }
    }
    else{
        //otherwise unknown, send back blank
        simpleDataType.dataTypeString = "";
    }
    
    return simpleDataType;
}

ArrayT IoddObject::parseArrayT(pugi::xml_node node){
    ArrayT arrayT = ArrayT();
    
    if(!node){ return arrayT; }
    
    String dataTypeString = node.attribute("xsi:type").value();
    if(dataTypeString == "ArrayT"){
        arrayT.dataTypeString = dataTypeString;
        arrayT.name = node.child("Name").attribute("textId").value();
        arrayT.idString = node.attribute("id").value();
        arrayT.isSubindexAccessSupported = node.attribute("subindexAccessSupported").value();
        arrayT.count = node.attribute("count").value();
    }
    
    //No need to iterate, can only be one
    pugi::xml_node tempNode = node.child("SimpleDataType");
    if(tempNode){
        arrayT.isSimpleDataType = "true";
        arrayT.simpleDataType = parseSimpleDataType(tempNode);
    }
    else{
        //must be data type ref
        pugi::xml_node typeRefNode = node.child("DatatypeRef");
        if(typeRefNode){
            String idString = typeRefNode.attribute("datatypeId").value();
            DataType temp = dataTypeCollection[idString];
            
            if(temp.isSimple){
                arrayT.isSimpleDataType = "true";
                arrayT.simpleDataType = temp.simpleDataType;
            }
        }
    }
    
    return arrayT;
}

RecordT IoddObject::parseRecordT(pugi::xml_node node){
    RecordT recordT = RecordT();
    
    if(!node){ return recordT; }
    
    String dataTypeString = node.attribute("xsi:type").value();
    if(dataTypeString == "RecordT"){
        recordT.dataTypeString = dataTypeString;
        recordT.name = node.child("Name").attribute("textId").value();
        recordT.idString = node.attribute("id").value();
        recordT.isSubindexAccessSupported = node.attribute("subindexAccessSupported").value();
        recordT.bitLength = node.attribute("bitLength").value();
        
        //Can have multiple types of recordItems so need to iterate
        for( pugi::xml_node recordItemNode = node.child("RecordItem"); recordItemNode; recordItemNode = recordItemNode.next_sibling("RecordItem")){
            RecordItemT recordItemT = RecordItemT();
            recordItemT.name = recordItemNode.child("Name").attribute("textId").value();
            recordItemT.subindex = recordItemNode.attribute("subindex").value();
            recordItemT.bitOffset = recordItemNode.attribute("bitOffset").value();
            recordItemT.accessRightsRestriction = recordItemNode.attribute("accessRightsRestriction").value();
            
            //Can only be one datatype for each record item
            pugi::xml_node tempNode = recordItemNode.child("SimpleDatatype");
            if(tempNode){
                recordItemT.isSimpleDataType = "true";
                recordItemT.simpleDataType = parseSimpleDataType(tempNode);
            }
            else{
                //must be data type ref
                pugi::xml_node typeRefNode = recordItemNode.child("DatatypeRef");
                if(typeRefNode){
                    String idString = typeRefNode.attribute("datatypeId").value();
                    DataType temp = dataTypeCollection[idString];
                    
                    if(temp.isSimple){
                        recordItemT.isSimpleDataType = "true";
                        recordItemT.simpleDataType = temp.simpleDataType;
                    }
                }
            }
            
            recordT.recordItemCollection.push_back(recordItemT);
        }
    }
    return recordT;
}

